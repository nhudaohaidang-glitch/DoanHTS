// ============================================================================
// Module: feat_core [Bản chuẩn v3 - Tối ưu 0 DSP, Siêu nhẹ LUT, Khớp 100% AI]
// Nhiệm vụ:
//   - Trích xuất đặc trưng trong cửa sổ thời gian (1 giây / CLK_FREQ nhịp).
//   - Đếm On-The-Fly số IP nguồn duy nhất, số Port đích duy nhất, số IP đích duy nhất.
//   - Hoàn toàn KHÔNG dùng bộ nhân (0 DSP), tiêu tốn cực ít LUT (~350 LUT).
//   - Nhận diện gói SYN chuẩn: SYN=1 VÀ ACK=0 (loại trừ SYN-ACK).
//   - Hỗ trợ lọc theo máy cần bảo vệ (protected_ip).
//   - Thuật toán Boyer-Moore tìm suspect_ip & confirm_cnt.
// ============================================================================

module feat_core #(
    parameter CLK_FREQ = 27_000_000   // 27 MHz = 1 giây mỗi cửa sổ
) (
    input  wire        clk,
    input  wire        rst_n,

    // Bản ghi header từ pkt_parser
    input  wire        hdr_valid,
    input  wire        hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    input  wire        is_ipv4,
    input  wire [31:0] src_ip,
    input  wire [31:0] dst_ip,
    input  wire [7:0]  ip_proto,
    input  wire [15:0] ip_len,
    input  wire [15:0] src_port,
    input  wire [15:0] dst_port,
    input  wire [7:0]  tcp_flags,

    // Cấu hình máy cần bảo vệ
    input  wire [31:0] protected_ip,
    input  wire        protected_ip_en,

    // Tùy chọn xung kích hoạt hết cửa sổ từ ngoài
    input  wire        ext_win_tick,

    // Giao tiếp xuất đặc trưng cho Phần 1 (wb_feat_regs.v)
    output reg         win_valid,       // Xung báo kết thúc cửa sổ
    output reg  [31:0] pkt_cnt,         // Tổng số gói
    output reg  [31:0] syn_cnt,         // Tổng số gói SYN chuẩn
    output reg  [31:0] byte_cnt,        // Tổng số byte
    output reg  [7:0]  unique_ips,      // Số IP nguồn duy nhất (0..255)
    output reg  [7:0]  unique_ports,    // Số Port đích duy nhất (0..255)
    output reg  [7:0]  unique_dst_ips,  // Số IP đích duy nhất (0..255) - ĐẶC TẢ AI MỚI
    output reg  [31:0] suspect_ip,      // IP nghi vấn (0x2000_0028)
    output reg  [31:0] confirm_cnt      // Số gói SYN xác nhận từ suspect_ip (0x2000_002C)
);

    // ========================================================================
    // 1. Quản lý cửa sổ thời gian (Window Timer)
    // ========================================================================
    reg [24:0] win_timer;
    wire win_end = ext_win_tick | (win_timer >= CLK_FREQ - 1);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            win_timer <= 25'd0;
        end else begin
            if (win_end) begin
                win_timer <= 25'd0;
            end else begin
                win_timer <= win_timer + 25'd1;
            end
        end
    end

    // ========================================================================
    // 2. Bộ tích lũy thống kê trong cửa sổ hiện tại
    // ========================================================================
    reg [31:0]  cur_pkt_cnt;
    reg [31:0]  cur_syn_cnt;
    reg [31:0]  cur_byte_cnt;
    reg [31:0]  cur_confirm_cnt;

    // Bitmap 256 ô để kiểm tra trùng
    reg [255:0] bitmap_ips;
    reg [255:0] bitmap_ports;
    reg [255:0] bitmap_dst_ips;

    // Bộ đếm On-The-Fly: tăng ngay khi gặp bit 0, KHÔNG DÙNG BỘ NHÂN / CÂY CỘNG!
    reg [7:0]   cur_unique_ips;
    reg [7:0]   cur_unique_ports;
    reg [7:0]   cur_unique_dst_ips;

    // Biến cho thuật toán Boyer-Moore
    reg [31:0]  bm_candidate;
    reg [15:0]  bm_votes;

    // ĐẶC TẢ ĐÚNG: Gói SYN chuẩn là SYN=1 VÀ ACK=0 (loại trừ SYN-ACK!)
    wire is_pure_syn = (ip_proto == 8'd6) && (tcp_flags[1] == 1'b1) && (tcp_flags[4] == 1'b0);

    // Kiểm tra máy cần bảo vệ
    wire target_match = (!protected_ip_en) || (dst_ip == protected_ip);
    wire valid_inbound = hdr_valid && (!hdr_dir) && is_ipv4 && target_match;

    // ========================================================================
    // 3. FSM và cập nhật đặc trưng
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            win_valid          <= 1'b0;
            pkt_cnt            <= 32'd0;
            syn_cnt            <= 32'd0;
            byte_cnt           <= 32'd0;
            unique_ips         <= 8'd0;
            unique_ports       <= 8'd0;
            unique_dst_ips     <= 8'd0;
            suspect_ip         <= 32'd0;
            confirm_cnt        <= 32'd0;

            cur_pkt_cnt        <= 32'd0;
            cur_syn_cnt        <= 32'd0;
            cur_byte_cnt       <= 32'd0;
            cur_confirm_cnt    <= 32'd0;
            cur_unique_ips     <= 8'd0;
            cur_unique_ports   <= 8'd0;
            cur_unique_dst_ips <= 8'd0;

            bitmap_ips         <= 256'd0;
            bitmap_ports       <= 256'd0;
            bitmap_dst_ips     <= 256'd0;

            bm_candidate       <= 32'd0;
            bm_votes           <= 16'd0;
        end else begin
            win_valid <= 1'b0;

            if (valid_inbound) begin
                cur_pkt_cnt  <= cur_pkt_cnt + 32'd1;
                cur_byte_cnt <= cur_byte_cnt + {16'd0, ip_len};

                // Đếm On-The-Fly IP nguồn: nếu bit chưa bật thì bật và +1
                if (bitmap_ips[src_ip[7:0]] == 1'b0) begin
                    bitmap_ips[src_ip[7:0]] <= 1'b1;
                    if (cur_unique_ips < 8'd255) begin
                        cur_unique_ips <= cur_unique_ips + 8'd1;
                    end
                end

                // Đếm On-The-Fly Port đích: nếu bit chưa bật thì bật và +1 (hỗ trợ tới 251+ cổng)
                if (bitmap_ports[dst_port[7:0]] == 1'b0) begin
                    bitmap_ports[dst_port[7:0]] <= 1'b1;
                    if (cur_unique_ports < 8'd255) begin
                        cur_unique_ports <= cur_unique_ports + 8'd1;
                    end
                end

                // Đếm On-The-Fly IP đích
                if (bitmap_dst_ips[dst_ip[7:0]] == 1'b0) begin
                    bitmap_dst_ips[dst_ip[7:0]] <= 1'b1;
                    if (cur_unique_dst_ips < 8'd255) begin
                        cur_unique_dst_ips <= cur_unique_dst_ips + 8'd1;
                    end
                end

                // Xử lý gói SYN chuẩn (SYN=1, ACK=0)
                if (is_pure_syn) begin
                    cur_syn_cnt <= cur_syn_cnt + 32'd1;

                    // Xác nhận số SYN từ suspect_ip của cửa sổ trước
                    if (src_ip == suspect_ip) begin
                        cur_confirm_cnt <= cur_confirm_cnt + 32'd1;
                    end

                    // Thuật toán Boyer-Moore tìm suspect_ip
                    if (bm_votes == 16'd0) begin
                        bm_candidate <= src_ip;
                        bm_votes     <= 16'd1;
                    end else if (src_ip == bm_candidate) begin
                        bm_votes <= bm_votes + 16'd1;
                    end else begin
                        bm_votes <= bm_votes - 16'd1;
                    end
                end
            end

            // Khi kết thúc cửa sổ: chốt dữ liệu và reset
            if (win_end) begin
                win_valid      <= 1'b1;
                pkt_cnt        <= cur_pkt_cnt;
                syn_cnt        <= cur_syn_cnt;
                byte_cnt       <= cur_byte_cnt;
                unique_ips     <= cur_unique_ips;
                unique_ports   <= cur_unique_ports;
                unique_dst_ips <= cur_unique_dst_ips;

                confirm_cnt    <= cur_confirm_cnt;
                suspect_ip     <= bm_candidate;

                // Reset bộ đếm cho cửa sổ mới
                cur_pkt_cnt        <= 32'd0;
                cur_syn_cnt        <= 32'd0;
                cur_byte_cnt       <= 32'd0;
                cur_confirm_cnt    <= 32'd0;
                cur_unique_ips     <= 8'd0;
                cur_unique_ports   <= 8'd0;
                cur_unique_dst_ips <= 8'd0;

                bitmap_ips         <= 256'd0;
                bitmap_ports       <= 256'd0;
                bitmap_dst_ips     <= 256'd0;

                bm_candidate       <= 32'd0;
                bm_votes           <= 16'd0;
            end
        end
    end

endmodule
