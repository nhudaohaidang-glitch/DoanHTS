// ============================================================================
// Module: pkt_parser [Bản chuẩn v3 - Tối ưu tài nguyên & Khớp 100% đặc tả AI]
// Nhiệm vụ:
//   - Bóc tách dòng byte từ RMII/FIFO (miền clock 27 MHz).
//   - Nhận diện Ethernet type: IPv4 (0x0800), ARP (0x0806).
//   - Bóc tách IPv4: IP nguồn (src_ip), IP đích (dst_ip), Protocol, Độ dài gói.
//   - Phát hiện gói phân mảnh (Fragmented packet: MF=1 hoặc Offset != 0).
//   - Bóc tách TCP/UDP: Cổng nguồn, cổng đích, cờ TCP (SYN, ACK...).
//   - Nhận diện ICMP (ping).
// ============================================================================

module pkt_parser (
    input  wire        clk,
    input  wire        rst_n,

    // Giao tiếp nhận dòng byte từ Phần 4 (MAC/FIFO)
    input  wire        frm_valid,
    input  wire [7:0]  frm_data,
    input  wire        frm_sof,
    input  wire        frm_eof,
    input  wire        frm_dir,
    input  wire        frm_crc_ok,

    // Bản ghi header xuất ra cho pkt_filter và feat_core
    output reg         hdr_valid,     // Xung 1 nhịp khi bóc xong header
    output reg         hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    output reg         is_ipv4,       // 1 = IPv4, 0 = ARP/loại khác
    output reg         is_fragment,   // 1 = Gói IP phân mảnh (cần bỏ)
    output reg  [31:0] src_ip,        // Byte đầu ở bit cao [31:24]
    output reg  [31:0] dst_ip,        // Byte đầu ở bit cao [31:24]
    output reg  [7:0]  ip_proto,      // 6=TCP, 17=UDP, 1=ICMP
    output reg  [15:0] ip_len,        // Total length IPv4
    output reg  [15:0] src_port,      // Cổng nguồn TCP/UDP
    output reg  [15:0] dst_port,      // Cổng đích TCP/UDP
    output reg  [7:0]  tcp_flags      // Cờ TCP (bit1=SYN, bit4=ACK)
);

    reg [10:0] byte_cnt;
    reg [7:0]  ether_hi;
    reg [3:0]  ip_ihl;
    reg [10:0] l4_offset;
    reg [7:0]  frag_hi;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            byte_cnt    <= 11'd0;
            hdr_valid   <= 1'b0;
            hdr_dir     <= 1'b0;
            is_ipv4     <= 1'b0;
            is_fragment <= 1'b0;
            src_ip      <= 32'd0;
            dst_ip      <= 32'd0;
            ip_proto    <= 8'd0;
            ip_len      <= 16'd0;
            src_port    <= 16'd0;
            dst_port    <= 16'd0;
            tcp_flags   <= 8'd0;
            ether_hi    <= 8'd0;
            ip_ihl      <= 4'd5;
            l4_offset   <= 11'd34;
            frag_hi     <= 8'd0;
        end else begin
            hdr_valid <= 1'b0;

            if (frm_valid) begin
                if (frm_sof) begin
                    byte_cnt    <= 11'd1; // Byte hiện tại là 0, nhịp sau là 1
                    hdr_dir     <= frm_dir;
                    is_ipv4     <= 1'b0;
                    is_fragment <= 1'b0;
                    ip_proto    <= 8'd0;
                    tcp_flags   <= 8'd0;
                    src_port    <= 16'd0;
                    dst_port    <= 16'd0;
                end else begin
                    byte_cnt <= byte_cnt + 11'd1;
                end

                case (byte_cnt)
                    // Byte 12..13: EtherType
                    11'd12: ether_hi <= frm_data;
                    11'd13: begin
                        if ({ether_hi, frm_data} == 16'h0800) begin
                            is_ipv4 <= 1'b1;
                        end else begin
                            is_ipv4   <= 1'b0;
                            hdr_valid <= 1'b1; // ARP hoặc loại khác -> báo valid ngay
                        end
                    end

                    // Byte 14: Version + IHL
                    11'd14: if (is_ipv4) begin
                        ip_ihl    <= frm_data[3:0];
                        l4_offset <= 11'd14 + {5'd0, frm_data[3:0], 2'b00};
                    end

                    // Byte 16..17: Total Length
                    11'd16: if (is_ipv4) ip_len[15:8] <= frm_data;
                    11'd17: if (is_ipv4) ip_len[7:0]  <= frm_data;

                    // Byte 20..21: Flags & Fragment Offset (Phát hiện gói phân mảnh)
                    11'd20: if (is_ipv4) frag_hi <= frm_data;
                    11'd21: if (is_ipv4) begin
                        // Bit More Fragments (MF = bit 13) hoặc Fragment Offset != 0
                        if ((frag_hi[5:0] != 6'd0) || (frm_data != 8'd0)) begin
                            is_fragment <= 1'b1;
                        end else begin
                            is_fragment <= 1'b0;
                        end
                    end

                    // Byte 23: Protocol (6=TCP, 17=UDP, 1=ICMP)
                    11'd23: if (is_ipv4) ip_proto <= frm_data;

                    // Byte 26..29: Source IP
                    11'd26: if (is_ipv4) src_ip[31:24] <= frm_data;
                    11'd27: if (is_ipv4) src_ip[23:16] <= frm_data;
                    11'd28: if (is_ipv4) src_ip[15:8]  <= frm_data;
                    11'd29: if (is_ipv4) src_ip[7:0]   <= frm_data;

                    // Byte 30..33: Destination IP
                    11'd30: if (is_ipv4) dst_ip[31:24] <= frm_data;
                    11'd31: if (is_ipv4) dst_ip[23:16] <= frm_data;
                    11'd32: if (is_ipv4) dst_ip[15:8]  <= frm_data;
                    11'd33: if (is_ipv4) dst_ip[7:0]   <= frm_data;

                    default: ;
                endcase

                // Tầng L4 (TCP / UDP / ICMP)
                if (is_ipv4 && (byte_cnt >= l4_offset)) begin
                    // Nếu là gói phân mảnh, báo valid ngay khi đọc xong IP
                    if (is_fragment && (byte_cnt == l4_offset)) begin
                        hdr_valid <= 1'b1;
                    end else begin
                        case (ip_proto)
                            8'd6: begin // TCP
                                if (byte_cnt == l4_offset)       src_port[15:8] <= frm_data;
                                if (byte_cnt == l4_offset + 1)   src_port[7:0]  <= frm_data;
                                if (byte_cnt == l4_offset + 2)   dst_port[15:8] <= frm_data;
                                if (byte_cnt == l4_offset + 3)   dst_port[7:0]  <= frm_data;
                                if (byte_cnt == l4_offset + 13) begin
                                    tcp_flags <= frm_data;
                                    hdr_valid <= 1'b1;
                                end
                            end

                            8'd17: begin // UDP
                                if (byte_cnt == l4_offset)       src_port[15:8] <= frm_data;
                                if (byte_cnt == l4_offset + 1)   src_port[7:0]  <= frm_data;
                                if (byte_cnt == l4_offset + 2)   dst_port[15:8] <= frm_data;
                                if (byte_cnt == l4_offset + 3) begin
                                    dst_port[7:0] <= frm_data;
                                    tcp_flags     <= 8'd0;
                                    hdr_valid     <= 1'b1;
                                end
                            end

                            8'd1: begin // ICMP (ping)
                                if (byte_cnt == l4_offset) begin
                                    src_port  <= 16'd0;
                                    dst_port  <= 16'd0;
                                    tcp_flags <= 8'd0;
                                    hdr_valid <= 1'b1;
                                end
                            end

                            default: begin
                                if (byte_cnt == l4_offset) begin
                                    hdr_valid <= 1'b1;
                                end
                            end
                        endcase
                    end
                end
            end

            if (frm_eof) begin
                byte_cnt <= 11'd0;
            end
        end
    end

endmodule
