// ============================================================================
// Module: pkt_filter [Bản chuẩn v3 - Sửa triệt để Token Bucket & Lọc phân mảnh]
// Nhiệm vụ:
//   - Lớp 0: Bỏ gói IP phân mảnh (is_fragment=1).
//   - Lớp 1: So khớp IP nguồn với danh sách chặn 8 ô (bl_ip0..7).
//   - Lớp 2: Giới hạn gói SYN bằng cơ chế Xô Token (Token Bucket).
//     + Đếm gói SYN chuẩn: SYN=1 VÀ ACK=0 (loại trừ gói SYN-ACK).
//     + Gói bị Lớp 1 chặn KHÔNG tiêu hao token.
//   - Hỗ trợ parameter CLK_FREQ để mô phỏng rút ngắn thời gian.
// ============================================================================

module pkt_filter #(
    parameter CLK_FREQ = 27_000_000   // Tần số clock hệ thống (27 MHz)
) (
    input  wire        clk,
    input  wire        rst_n,

    // Giao tiếp với pkt_parser
    input  wire        hdr_valid,
    input  wire        hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    input  wire        is_ipv4,
    input  wire        is_fragment,   // 1 = Gói IP phân mảnh
    input  wire [31:0] src_ip,
    input  wire [31:0] dst_ip,
    input  wire [7:0]  ip_proto,
    input  wire [15:0] ip_len,
    input  wire [15:0] src_port,
    input  wire [15:0] dst_port,
    input  wire [7:0]  tcp_flags,

    // Tín hiệu kết thúc khung từ Phần 4
    input  wire        frm_eof,

    // Cấu hình từ Phần 1 (0x5000_0000)
    input  wire        ctrl_block_en,     // CTRL bit 0
    input  wire        ctrl_syn_limit_en, // CTRL bit 1
    input  wire [15:0] syn_limit,         // Số gói SYN tối đa/giây
    input  wire [7:0]  bl_valid,          // Bit i = 1: ô i hợp lệ
    input  wire [31:0] bl_ip0,
    input  wire [31:0] bl_ip1,
    input  wire [31:0] bl_ip2,
    input  wire [31:0] bl_ip3,
    input  wire [31:0] bl_ip4,
    input  wire [31:0] bl_ip5,
    input  wire [31:0] bl_ip6,
    input  wire [31:0] bl_ip7,
    input  wire        clear_counters,

    // Cấu hình máy cần bảo vệ (tùy chọn)
    input  wire [31:0] protected_ip,
    input  wire        protected_ip_en,

    // Quyết định gửi sang Phần 4
    output reg         verdict_valid,
    output reg         verdict_drop,

    // Các bộ đếm gửi sang Phần 1
    output reg  [31:0] cnt_fwd,
    output reg  [31:0] cnt_drop_bl,
    output reg  [31:0] cnt_drop_syn
);

    // ========================================================================
    // Khai báo biến nội bộ ở đầu module (chuẩn Verilog-2001)
    // ========================================================================
    reg current_drop_bl;
    reg current_drop_syn;
    reg current_drop_frag;
    reg consume_token;

    reg [24:0] sec_timer;
    reg [15:0] token_bucket;

    // So sánh IP nguồn với 8 ô Blocklist
    wire match_bl = ctrl_block_en && (
        (bl_valid[0] && (src_ip == bl_ip0)) ||
        (bl_valid[1] && (src_ip == bl_ip1)) ||
        (bl_valid[2] && (src_ip == bl_ip2)) ||
        (bl_valid[3] && (src_ip == bl_ip3)) ||
        (bl_valid[4] && (src_ip == bl_ip4)) ||
        (bl_valid[5] && (src_ip == bl_ip5)) ||
        (bl_valid[6] && (src_ip == bl_ip6)) ||
        (bl_valid[7] && (src_ip == bl_ip7))
    );

    // ĐẶC TẢ ĐÚNG: Gói SYN chuẩn là SYN=1 VÀ ACK=0 (loại trừ gói SYN-ACK!)
    wire is_pure_syn = (ip_proto == 8'd6) && (tcp_flags[1] == 1'b1) && (tcp_flags[4] == 1'b0);

    // Kiểm tra máy cần bảo vệ (nếu bật)
    wire target_match = (!protected_ip_en) || (dst_ip == protected_ip);

    // ========================================================================
    // 1. Quản lý Xô Token (Token Bucket) cho Giới hạn SYN (Lớp 2)
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sec_timer    <= 25'd0;
            token_bucket <= syn_limit; // SỬA: Lấy ngay syn_limit khi reset, không lấy 100!
        end else begin
            if (sec_timer >= CLK_FREQ - 1) begin
                sec_timer    <= 25'd0;
                token_bucket <= syn_limit; // Mỗi giây làm đầy lại xô token
            end else begin
                sec_timer <= sec_timer + 25'd1;

                if (consume_token && (token_bucket > 16'd0)) begin
                    token_bucket <= token_bucket - 16'd1;
                end
            end
        end
    end

    // ========================================================================
    // 2. Xét duyệt gói khi nhận được hdr_valid
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_drop_bl   <= 1'b0;
            current_drop_syn  <= 1'b0;
            current_drop_frag <= 1'b0;
            consume_token     <= 1'b0;
        end else begin
            consume_token <= 1'b0;

            if (hdr_valid) begin
                // Khung không phải IPv4 hoặc khung từ trong ra ngoài (hdr_dir == 1) -> Luôn cho qua!
                if (!is_ipv4 || (hdr_dir == 1'b1)) begin
                    current_drop_bl   <= 1'b0;
                    current_drop_syn  <= 1'b0;
                    current_drop_frag <= 1'b0;
                end else if (is_fragment) begin
                    // ĐẶC TẢ MỚI: BỎ GÓI PHÂN MẢNH
                    current_drop_frag <= 1'b1;
                    current_drop_bl   <= 1'b0;
                    current_drop_syn  <= 1'b0;
                end else begin
                    current_drop_frag <= 1'b0;
                    // Lớp 1: Danh sách chặn
                    if (match_bl) begin
                        current_drop_bl  <= 1'b1;
                        current_drop_syn <= 1'b0;
                        // Gói bị Lớp 1 bỏ thì KHÔNG trừ token của gói khác!
                    end else begin
                        current_drop_bl <= 1'b0;
                        // Lớp 2: Giới hạn SYN (chỉ với gói pure SYN nhắm vào target)
                        if (ctrl_syn_limit_en && is_pure_syn && target_match) begin
                            if (token_bucket > 16'd0) begin
                                consume_token    <= 1'b1; // Lấy 1 token, cho qua
                                current_drop_syn <= 1'b0;
                            end else begin
                                current_drop_syn <= 1'b1; // Hết token -> Bỏ gói!
                            end
                        end else begin
                            // Gói ACK, UDP, ICMP,... hợp lệ -> Cho qua
                            current_drop_syn <= 1'b0;
                        end
                    end
                end
            end
        end
    end

    // ========================================================================
    // 3. Xuất phán quyết tại frm_eof và cập nhật bộ đếm
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            verdict_valid <= 1'b0;
            verdict_drop  <= 1'b0;
            cnt_fwd       <= 32'd0;
            cnt_drop_bl   <= 32'd0;
            cnt_drop_syn  <= 32'd0;
        end else begin
            if (clear_counters) begin
                cnt_fwd      <= 32'd0;
                cnt_drop_bl  <= 32'd0;
                cnt_drop_syn <= 32'd0;
            end

            if (frm_eof) begin
                verdict_valid <= 1'b1;
                if (current_drop_bl) begin
                    verdict_drop <= 1'b1;
                    cnt_drop_bl  <= cnt_drop_bl + 32'd1;
                end else if (current_drop_syn || current_drop_frag) begin
                    verdict_drop <= 1'b1;
                    if (current_drop_syn) cnt_drop_syn <= cnt_drop_syn + 32'd1;
                end else begin
                    verdict_drop <= 1'b0;
                    if (is_ipv4 && (hdr_dir == 1'b0)) begin
                        cnt_fwd <= cnt_fwd + 32'd1;
                    end
                end
            end else begin
                verdict_valid <= 1'b0;
            end
        end
    end

endmodule
