// ============================================================
// Module: feature_extractor
// Mô tả: Trích xuất đặc trưng từ luồng gói tin mạng nhận qua SPI.
//
// Chức năng chính:
//   1. Nhận từng byte dữ liệu từ SPI Slave theo đúng thứ tự giao thức
//   2. Mỗi "gói tin" gồm 4 byte: [flags, src_ip, dst_port, ctrl]
//   3. Tích lũy thống kê trong cửa sổ thời gian (time window)
//   4. Khi nhận byte ctrl = 0xFF → kết thúc cửa sổ → tính đặc trưng
//   5. Xuất vector đặc trưng qua giao diện ready/valid
//
// Đặc trưng trích xuất:
//   - pkt_count   : Tổng số gói tin trong cửa sổ
//   - syn_ratio   : Tỉ lệ gói SYN (dạng fixed-point 8-bit: ratio * 255)
//   - unique_ips  : Số IP nguồn duy nhất (dùng bitmap 8-bit đơn giản)
//   - unique_ports: Số cổng đích duy nhất (dùng bitmap 8-bit đơn giản)
//
// Định dạng bitmap: 8 bit, mỗi bit đại diện cho 1 nhóm địa chỉ/cổng
//   ví dụ src_ip[7:0] = 0b00001010 → đặt bit (src_ip % 8) trong bitmap
//   unique_ips = số bit '1' trong bitmap (popcount)
//
// FSM States: IDLE → RECV_FLAGS → RECV_SRC_IP → RECV_DST_PORT → RECV_CTRL
//             → COMPUTE → OUTPUT → (quay về IDLE)
//
// Tác giả: Nhóm đồ án FPGA – Tang Nano 9K
// ============================================================

module feature_extractor #(
    parameter WINDOW_SIZE = 16   // Số gói tối đa trong một cửa sổ thời gian
) (
    input  wire        clk,          // Clock hệ thống
    input  wire        rst_n,        // Reset tích cực thấp

    // -- Giao diện nhận dữ liệu từ SPI Slave --
    input  wire [7:0]  rx_byte,      // Byte nhận từ SPI
    input  wire        rx_valid,     // Xung valid khi rx_byte hợp lệ

    // -- Giao diện xuất đặc trưng (ready/valid handshake) --
    output reg         feat_valid,   // 1 = vector đặc trưng đã sẵn sàng
    input  wire        feat_ready,   // 1 = bên nhận (AI) sẵn sàng đọc
    output reg  [7:0]  pkt_count,    // Tổng số gói tin trong cửa sổ
    output reg  [7:0]  syn_ratio,    // Tỉ lệ SYN (0-255), 255 = 100% SYN
    output reg  [7:0]  unique_ips,   // Số IP nguồn duy nhất (0-8)
    output reg  [7:0]  unique_ports  // Số cổng đích duy nhất (0-8)
);

    // ============================================================
    // Định nghĩa các trạng thái FSM
    // ============================================================
    localparam ST_IDLE         = 3'd0;  // Chờ gói tin mới
    localparam ST_RECV_FLAGS   = 3'd1;  // Đang nhận byte flags
    localparam ST_RECV_SRC_IP  = 3'd2;  // Đang nhận byte src_ip
    localparam ST_RECV_DST_PORT= 3'd3;  // Đang nhận byte dst_port
    localparam ST_RECV_CTRL    = 3'd4;  // Đang nhận byte điều khiển
    localparam ST_COMPUTE      = 3'd5;  // Tính toán đặc trưng
    localparam ST_OUTPUT       = 3'd6;  // Xuất kết quả, chờ AI đọc

    reg [2:0] state;    // Thanh ghi trạng thái hiện tại

    // ============================================================
    // Thanh ghi tạm lưu từng byte của gói tin hiện tại
    // ============================================================
    reg [7:0] reg_flags;    // Byte 0: flags (bit0 = is_SYN)
    reg [7:0] reg_src_ip;   // Byte 1: src_ip[7:0]
    reg [7:0] reg_dst_port; // Byte 2: dst_port[7:0]

    // ============================================================
    // Bộ tích lũy thống kê trong cửa sổ
    // ============================================================
    reg [7:0]  cnt_pkts;        // Đếm tổng số gói trong cửa sổ
    reg [7:0]  cnt_syn;         // Đếm số gói có cờ SYN
    reg [7:0]  bitmap_ips;      // Bitmap 8-bit theo dõi IP nguồn
    reg [7:0]  bitmap_ports;    // Bitmap 8-bit theo dõi cổng đích

    // ============================================================
    // Hàm đếm số bit '1' trong vector 8-bit (popcount)
    // Dùng để tính số lượng duy nhất từ bitmap
    // ============================================================
    function [3:0] popcount8;
        input [7:0] v;
        begin
            popcount8 = v[0] + v[1] + v[2] + v[3]
                      + v[4] + v[5] + v[6] + v[7];
        end
    endfunction

    // ============================================================
    // Thanh ghi giữ kết quả tính toán (dùng trong COMPUTE)
    // ============================================================
    reg [7:0] calc_syn_ratio;
    reg [7:0] calc_unique_ips;
    reg [7:0] calc_unique_ports;

    // ============================================================
    // FSM chính: điều khiển luồng nhận & xử lý
    // ============================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // --- Reset toàn bộ trạng thái ---
            state          <= ST_IDLE;
            reg_flags      <= 8'd0;
            reg_src_ip     <= 8'd0;
            reg_dst_port   <= 8'd0;
            cnt_pkts       <= 8'd0;
            cnt_syn        <= 8'd0;
            bitmap_ips     <= 8'd0;
            bitmap_ports   <= 8'd0;
            feat_valid     <= 1'b0;
            pkt_count      <= 8'd0;
            syn_ratio      <= 8'd0;
            unique_ips     <= 8'd0;
            unique_ports   <= 8'd0;
            calc_syn_ratio    <= 8'd0;
            calc_unique_ips   <= 8'd0;
            calc_unique_ports <= 8'd0;
        end else begin
            case (state)
                // ------------------------------------------------
                // IDLE: Chờ byte đầu tiên của gói tin (flags byte)
                // ------------------------------------------------
                ST_IDLE: begin
                    feat_valid <= 1'b0;
                    if (rx_valid) begin
                        // Byte đầu tiên đến: đây là byte flags
                        reg_flags <= rx_byte;
                        state     <= ST_RECV_FLAGS;
                    end
                end

                // ------------------------------------------------
                // RECV_FLAGS: Đã lưu byte flags, chờ byte src_ip
                // ------------------------------------------------
                ST_RECV_FLAGS: begin
                    if (rx_valid) begin
                        reg_src_ip <= rx_byte;
                        state      <= ST_RECV_SRC_IP;
                    end
                end

                // ------------------------------------------------
                // RECV_SRC_IP: Đã lưu src_ip, chờ byte dst_port
                // ------------------------------------------------
                ST_RECV_SRC_IP: begin
                    if (rx_valid) begin
                        reg_dst_port <= rx_byte;
                        state        <= ST_RECV_DST_PORT;
                    end
                end

                // ------------------------------------------------
                // RECV_DST_PORT: Đã lưu dst_port, chờ byte điều khiển
                // ------------------------------------------------
                ST_RECV_DST_PORT: begin
                    if (rx_valid) begin
                        state <= ST_RECV_CTRL;

                        // Tích lũy thống kê ngay khi nhận đủ 1 gói
                        cnt_pkts <= cnt_pkts + 8'd1;

                        // Nếu cờ SYN = 1 (bit 0 của flags)
                        if (reg_flags[0] == 1'b1)
                            cnt_syn <= cnt_syn + 8'd1;

                        // Cập nhật bitmap IP: đặt bit tương ứng với (src_ip % 8)
                        bitmap_ips <= bitmap_ips | (8'b1 << reg_src_ip[2:0]);

                        // Cập nhật bitmap port: đặt bit tương ứng với (dst_port % 8)
                        bitmap_ports <= bitmap_ports | (8'b1 << reg_dst_port[2:0]);

                        // Lưu byte điều khiển để kiểm tra ở trạng thái tiếp theo
                        reg_flags <= rx_byte; // tái dùng reg_flags để lưu ctrl byte
                    end
                end

                // ------------------------------------------------
                // RECV_CTRL: Kiểm tra byte điều khiển
                //   0xFF = kết thúc cửa sổ → chuyển sang COMPUTE
                //   khác = còn gói nữa    → quay về IDLE nhận tiếp
                // ------------------------------------------------
                ST_RECV_CTRL: begin
                    if (reg_flags == 8'hFF) begin
                        // Byte 0xFF: kết thúc cửa sổ thời gian
                        state <= ST_COMPUTE;
                    end else begin
                        // Còn gói tin khác trong cửa sổ → quay về IDLE
                        state <= ST_IDLE;
                    end
                end

                // ------------------------------------------------
                // COMPUTE: Tính toán các đặc trưng từ dữ liệu tích lũy
                // ------------------------------------------------
                ST_COMPUTE: begin
                    // syn_ratio = (cnt_syn * 255) / cnt_pkts
                    // Để đơn giản (tránh chia), dùng shift: ratio ≈ cnt_syn << 4
                    // nếu cnt_pkts == 0 thì ratio = 0
                    if (cnt_pkts == 8'd0) begin
                        calc_syn_ratio <= 8'd0;
                    end else begin
                        // Xấp xỉ: syn_ratio = (cnt_syn * 255) / cnt_pkts
                        // Dùng phép nhân đơn giản và chia cho cnt_pkts
                        // Để tránh module chia phức tạp, dùng công thức:
                        // ratio = cnt_syn * 8'd255 / cnt_pkts
                        // Vì cnt_pkts <= 255, kết quả [15:0], lấy [7:0]
                        calc_syn_ratio <= (cnt_syn * 8'd255) / cnt_pkts;
                    end

                    // unique_ips = số bit '1' trong bitmap_ips (0..8)
                    calc_unique_ips <= {4'd0, popcount8(bitmap_ips)};

                    // unique_ports = số bit '1' trong bitmap_ports (0..8)
                    calc_unique_ports <= {4'd0, popcount8(bitmap_ports)};

                    state <= ST_OUTPUT;
                end

                // ------------------------------------------------
                // OUTPUT: Xuất đặc trưng và chờ bên AI đọc xong
                // ------------------------------------------------
                ST_OUTPUT: begin
                    // Đặt giá trị đầu ra
                    pkt_count    <= cnt_pkts;
                    syn_ratio    <= calc_syn_ratio;
                    unique_ips   <= calc_unique_ips;
                    unique_ports <= calc_unique_ports;
                    feat_valid   <= 1'b1;

                    // Chờ bên nhận (AI accelerator) xác nhận ready
                    if (feat_ready) begin
                        // AI đã đọc xong → reset cửa sổ, quay lại IDLE
                        feat_valid   <= 1'b0;
                        cnt_pkts     <= 8'd0;
                        cnt_syn      <= 8'd0;
                        bitmap_ips   <= 8'd0;
                        bitmap_ports <= 8'd0;
                        state        <= ST_IDLE;
                    end
                end

                // Trạng thái không xác định → về IDLE (an toàn)
                default: state <= ST_IDLE;
            endcase
        end
    end

endmodule
