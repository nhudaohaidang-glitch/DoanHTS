// ============================================================================
// Module: feat_core  [SỬA LỖI v2: 08/11/2026]
// Nhiệm vụ:
//   - Trích xuất đặc trưng mạng trong cửa sổ thời gian (1 giây / 27M clock).
//   - Chạy thuật toán đa số Boyer-Moore trên các gói SYN để tìm suspect_ip.
//   - Cửa sổ kế tiếp đếm số gói SYN từ đúng suspect_ip -> xuất confirm_cnt.
//
// SỬA LỖI 4: Bitmap 8-bit chỉ đếm được tối đa 8 cổng/IP khác nhau
//   - Trước: bitmap_ips[7:0] và bitmap_ports[7:0] → tối đa 8 unique
//            → Port Scan 251 cổng bị nhầm là DoS vì unique_ports luôn = 8!
//   - Sau:   Dùng bitmap_ips[255:0] và bitmap_ports[255:0]
//            → Dựa trên 8-bit thấp nhất của IP/port để lập chỉ mục bit
//            → unique có thể đếm tới 256 → AI phân biệt đúng DoS vs Port Scan
//
// SỬA LỖI bonus: popcount8 → popcount256 đếm đúng số bit 1 trong 256 bit
// ============================================================================

module feat_core #(
    parameter CLK_FREQ = 27_000_000   // 27 MHz = 1 giây mỗi cửa sổ
) (
    input  wire        clk,
    input  wire        rst_n,

    // Bản ghi header từ pkt_parser
    input  wire        hdr_valid,
    input  wire        hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    input  wire        is_ipv4,
    input  wire [31:0] src_ip,
    input  wire [31:0] dst_ip,
    input  wire [7:0]  ip_proto,
    input  wire [15:0] ip_len,
    input  wire [15:0] src_port,
    input  wire [15:0] dst_port,
    input  wire [7:0]  tcp_flags,

    // Tùy chọn xung kích hoạt hết cửa sổ từ ngoài (nếu không dùng thì nối 0)
    input  wire        ext_win_tick,

    // Giao tiếp với Phần 1 (wb_feat_regs.v)
    output reg         win_valid,     // Xung báo kết thúc cửa sổ
    output reg  [31:0] pkt_cnt,       // Tổng gói ngoài->trong trong cửa sổ
    output reg  [31:0] syn_cnt,       // Tổng gói SYN trong cửa sổ
    output reg  [31:0] byte_cnt,      // Tổng byte dữ liệu trong cửa sổ
    output reg  [7:0]  unique_ips,    // Popcount bitmap IP nguồn
    output reg  [7:0]  unique_ports,  // Popcount bitmap Port đích
    output reg  [31:0] suspect_ip,    // IP nghi vấn (0x2000_0028)
    output reg  [31:0] confirm_cnt    // Số gói SYN xác nhận từ suspect_ip (0x2000_002C)
);

    // ========================================================================
    // 1. Quản lý cửa sổ thời gian (Window Timer)
    // ========================================================================
    reg [24:0] win_timer;
    wire win_end = ext_win_tick | (win_timer >= CLK_FREQ - 1);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            win_timer <= 25'd0;
        end else begin
            if (win_end) begin
                win_timer <= 25'd0;
            end else begin
                win_timer <= win_timer + 25'd1;
            end
        end
    end

    // ========================================================================
    // 2. Bộ tích lũy thống kê trong cửa sổ hiện tại
    // ========================================================================
    reg [31:0]  cur_pkt_cnt;
    reg [31:0]  cur_syn_cnt;
    reg [31:0]  cur_byte_cnt;

    // SỬA LỖI 4: Nâng bitmap từ 8-bit lên 256-bit
    // - bitmap_ips[255:0]:   bit i = 1 nếu đã thấy IP có byte thấp nhất = i
    // - bitmap_ports[255:0]: bit i = 1 nếu đã thấy port đích = i (đủ 0..255)
    // Như vậy unique_ips/ports tối đa = 256 thay vì 8 → phân biệt DoS vs Port Scan!
    reg [255:0] bitmap_ips;
    reg [255:0] bitmap_ports;

    reg [31:0]  cur_confirm_cnt;

    // Biến cho thuật toán Boyer-Moore Majority Vote
    reg [31:0] bm_candidate;
    reg [15:0] bm_votes;

    // ---- Hàm đếm bit 1 trong bitmap 256-bit (popcount256) ----
    // Chia thành 8 nhóm 32-bit, dùng hàm popcount32 cho từng nhóm
    function [5:0] popcount32;
        input [31:0] v;
        reg [31:0] tmp;
        begin
            // Thuật toán Hamming weight tối ưu cho phần cứng:
            tmp = v - ((v >> 1) & 32'h55555555);
            tmp = (tmp & 32'h33333333) + ((tmp >> 2) & 32'h33333333);
            tmp = (tmp + (tmp >> 4)) & 32'h0F0F0F0F;
            popcount32 = (tmp * 32'h01010101) >> 24;
        end
    endfunction

    function [8:0] popcount256;
        input [255:0] v;
        begin
            popcount256 = popcount32(v[31:0])   + popcount32(v[63:32])  +
                          popcount32(v[95:64])  + popcount32(v[127:96]) +
                          popcount32(v[159:128])+ popcount32(v[191:160])+
                          popcount32(v[223:192])+ popcount32(v[255:224]);
        end
    endfunction

    wire is_syn = (ip_proto == 8'd6) && (tcp_flags[1] == 1'b1);
    wire valid_inbound = hdr_valid && (!hdr_dir) && is_ipv4;
    // ========================================================================
    // 3. FSM / Tiến trình tính toán đặc trưng
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            win_valid       <= 1'b0;
            pkt_cnt         <= 32'd0;
            syn_cnt         <= 32'd0;
            byte_cnt        <= 32'd0;
            unique_ips      <= 8'd0;
            unique_ports    <= 8'd0;
            suspect_ip      <= 32'd0;
            confirm_cnt     <= 32'd0;

            cur_pkt_cnt     <= 32'd0;
            cur_syn_cnt     <= 32'd0;
            cur_byte_cnt    <= 32'd0;
            bitmap_ips      <= 256'd0;    // SỬA: 256-bit
            bitmap_ports    <= 256'd0;    // SỬA: 256-bit
            cur_confirm_cnt <= 32'd0;

            bm_candidate    <= 32'd0;
            bm_votes        <= 16'd0;
        end else begin
            win_valid <= 1'b0; // Xung 1 nhịp

            // Thu thập gói ngoài -> trong hợp lệ
            if (valid_inbound) begin
                cur_pkt_cnt  <= cur_pkt_cnt + 32'd1;
                cur_byte_cnt <= cur_byte_cnt + {16'd0, ip_len};

                // Cập nhật bitmap - SỬA LỖI 4: dùng bitmap 256-bit
                // src_ip[7:0]  = byte thấp nhất của IP nguồn (0..255) → đánh dấu bit đó
                // dst_port[7:0]= byte thấp nhất của port đích (0..255) → đánh dấu bit đó
                bitmap_ips   <= bitmap_ips   | (256'd1 << src_ip[7:0]);
                bitmap_ports <= bitmap_ports | (256'd1 << dst_port[7:0]);

                // Xử lý gói SYN
                if (is_syn) begin
                    cur_syn_cnt <= cur_syn_cnt + 32'd1;

                    // Xác nhận số SYN từ suspect_ip của cửa sổ trước
                    if (src_ip == suspect_ip) begin
                        cur_confirm_cnt <= cur_confirm_cnt + 32'd1;
                    end

                    // Thuật toán Boyer-Moore tìm IP gửi SYN nhiều nhất cho cửa sổ sau
                    if (bm_votes == 16'd0) begin
                        bm_candidate <= src_ip;
                        bm_votes     <= 16'd1;
                    end else if (src_ip == bm_candidate) begin
                        bm_votes <= bm_votes + 16'd1;
                    end else begin
                        bm_votes <= bm_votes - 16'd1;
                    end
                end
            end

            // Khi kết thúc cửa sổ: chốt dữ liệu và reset
            if (win_end) begin
                win_valid    <= 1'b1;
                pkt_cnt      <= cur_pkt_cnt;
                syn_cnt      <= cur_syn_cnt;
                byte_cnt     <= cur_byte_cnt;
                // SỬA: dùng popcount256 kèm bão hòa 255 (tránh tràn 8-bit nếu có đủ 256 IP/port)
                unique_ips   <= (popcount256(bitmap_ips) > 9'd255) ? 8'd255 : popcount256(bitmap_ips)[7:0];
                unique_ports <= (popcount256(bitmap_ports) > 9'd255) ? 8'd255 : popcount256(bitmap_ports)[7:0];

                // Kết quả xác nhận cửa sổ vừa xong
                confirm_cnt  <= cur_confirm_cnt;

                // Cập nhật IP nghi vấn cho cửa sổ kế tiếp
                suspect_ip   <= bm_candidate;

                // Reset bộ đếm cho cửa sổ mới
                cur_pkt_cnt     <= 32'd0;
                cur_syn_cnt     <= 32'd0;
                cur_byte_cnt    <= 32'd0;
                // Reset bitmap 256-bit cho cửa sổ mới
                bitmap_ips      <= 256'd0;
                bitmap_ports    <= 256'd0;
                cur_confirm_cnt <= 32'd0;
                bm_candidate    <= 32'd0;
                bm_votes        <= 16'd0;
            end
        end
    end

endmodule
