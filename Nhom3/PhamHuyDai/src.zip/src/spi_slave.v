// ============================================================
// Module: spi_slave
// Mô tả: Module SPI Slave nhận dữ liệu 8-bit theo chuẩn SPI Mode 0
//        (CPOL=0, CPHA=0) – dữ liệu lấy mẫu ở cạnh lên của SCK
//        Được dùng để nhận dữ liệu gói tin từ MCU/máy tính mô phỏng
//
// Giao thức SPI Mode 0:
//   - SCK mặc định ở mức thấp (CPOL = 0)
//   - Dữ liệu được lấy mẫu ở cạnh lên SCK (CPHA = 0)
//   - MSB được truyền trước
//   - CS_N (chip select) tích cực thấp
//
// Tác giả: Nhóm đồ án FPGA – Tang Nano 9K
// ============================================================

module spi_slave (
    input  wire       clk,        // Clock hệ thống (system clock)
    input  wire       rst_n,      // Reset không đồng bộ, tích cực thấp

    // -- Giao diện SPI vật lý --
    input  wire       sck,        // SPI Clock từ Master
    input  wire       cs_n,       // Chip Select (tích cực thấp)
    input  wire       mosi,       // Master Out Slave In

    // -- Giao diện đầu ra nội bộ --
    output reg  [7:0] rx_byte,    // Byte vừa nhận được (8-bit)
    output reg        rx_valid    // Xung báo hiệu rx_byte hợp lệ (1 chu kỳ clock)
);

    // --------------------------------------------------------
    // Đồng bộ hóa tín hiệu SCK và CS_N vào clock hệ thống
    // Tránh hiện tượng metastability khi tín hiệu từ domain clock khác
    // --------------------------------------------------------
    reg sck_r0, sck_r1;     // Thanh ghi đồng bộ 2 tầng cho SCK
    reg cs_r0,  cs_r1;      // Thanh ghi đồng bộ 2 tầng cho CS_N
    reg mosi_r;             // Thanh ghi đồng bộ cho MOSI

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sck_r0 <= 1'b0;
            sck_r1 <= 1'b0;
            cs_r0  <= 1'b1;
            cs_r1  <= 1'b1;
            mosi_r <= 1'b0;
        end else begin
            // Dịch thanh ghi để phát hiện cạnh
            sck_r0 <= sck;
            sck_r1 <= sck_r0;
            cs_r0  <= cs_n;
            cs_r1  <= cs_r0;
            mosi_r <= mosi;
        end
    end

    // Phát hiện cạnh lên của SCK (rising edge) để lấy mẫu MOSI
    wire sck_rising  = (sck_r0 == 1'b1) && (sck_r1 == 1'b0);

    // CS đang tích cực khi cs_r1 = 0
    wire cs_active   = !cs_r1;

    // --------------------------------------------------------
    // Shift register và bộ đếm bit để ghép 8 bit thành 1 byte
    // --------------------------------------------------------
    reg [2:0] bit_cnt;      // Đếm số bit đã nhận (0..7)
    reg [7:0] shift_reg;    // Thanh ghi dịch nhận dữ liệu MOSI

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bit_cnt   <= 3'd0;
            shift_reg <= 8'd0;
            rx_byte   <= 8'd0;
            rx_valid  <= 1'b0;
        end else begin
            // Mặc định rx_valid = 0, chỉ lên 1 đúng 1 chu kỳ
            rx_valid <= 1'b0;

            if (!cs_active) begin
                // CS không tích cực → reset bộ đếm, chờ transaction mới
                bit_cnt   <= 3'd0;
                shift_reg <= 8'd0;
            end else if (sck_rising) begin
                // Cạnh lên SCK trong khi CS đang tích cực
                // Dịch dữ liệu vào: MSB trước (shift left, MOSI vào bit 0)
                shift_reg <= {shift_reg[6:0], mosi_r};
                bit_cnt   <= bit_cnt + 3'd1;

                if (bit_cnt == 3'd7) begin
                    // Đã nhận đủ 8 bit → lưu byte và phát tín hiệu valid
                    rx_byte  <= {shift_reg[6:0], mosi_r};
                    rx_valid <= 1'b1;
                    bit_cnt  <= 3'd0;   // Reset bộ đếm cho byte tiếp theo
                end
            end
        end
    end

endmodule
