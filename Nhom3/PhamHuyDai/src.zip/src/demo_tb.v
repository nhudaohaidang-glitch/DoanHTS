// ============================================================================
// File: demo_tb.v
// Testbench chuyên dụng phục vụ DEMO CHO THẦY XEM
// Nội dung demo:
//   1. Khối pkt_parser bóc tách khung Ethernet, phân loại IPv4 / ARP
//   2. Khối pkt_filter (Lớp 1) so khớp danh sách chặn 8 ô IP từ CPU
// ============================================================================

`timescale 1ns / 1ps

module demo_tb;

    // Clock hệ thống 27 MHz (chu kỳ ~37 ns)
    reg clk;
    reg rst_n;

    // Dòng byte đầu vào từ Phần 4 (RMII MAC)
    reg        frm_valid;
    reg  [7:0] frm_data;
    reg        frm_sof;
    reg        frm_eof;
    reg        frm_dir;
    reg        frm_crc_ok;

    // Tín hiệu bóc tách từ pkt_parser
    wire        hdr_valid;
    wire        hdr_dir;
    wire        is_ipv4;
    wire [31:0] src_ip;
    wire [31:0] dst_ip;
    wire [7:0]  ip_proto;
    wire [15:0] ip_len;
    wire [15:0] src_port;
    wire [15:0] dst_port;
    wire [7:0]  tcp_flags;

    // Cấu hình Danh sách chặn (Lớp 1) từ Phần 1 (CPU)
    reg        ctrl_block_en;
    reg [7:0]  bl_valid;
    reg [31:0] bl_ip0, bl_ip1, bl_ip2, bl_ip3;
    reg [31:0] bl_ip4, bl_ip5, bl_ip6, bl_ip7;

    // Quyết định đầu ra từ pkt_filter
    wire        verdict_valid;
    wire        verdict_drop;
    wire [31:0] cnt_fwd;
    wire [31:0] cnt_drop_bl;
    wire [31:0] cnt_drop_syn;

    // 1. Kết nối Module Tách Header (pkt_parser)
    pkt_parser u_parser (
        .clk        (clk),
        .rst_n      (rst_n),
        .frm_valid  (frm_valid),
        .frm_data   (frm_data),
        .frm_sof    (frm_sof),
        .frm_eof    (frm_eof),
        .frm_dir    (frm_dir),
        .frm_crc_ok (frm_crc_ok),
        .hdr_valid  (hdr_valid),
        .hdr_dir    (hdr_dir),
        .is_ipv4    (is_ipv4),
        .src_ip     (src_ip),
        .dst_ip     (dst_ip),
        .ip_proto   (ip_proto),
        .ip_len     (ip_len),
        .src_port   (src_port),
        .dst_port   (dst_port),
        .tcp_flags  (tcp_flags)
    );

    // 2. Kết nối Module Bộ Lọc (pkt_filter)
    pkt_filter u_filter (
        .clk               (clk),
        .rst_n             (rst_n),
        .hdr_valid         (hdr_valid),
        .hdr_dir           (hdr_dir),
        .is_ipv4           (is_ipv4),
        .src_ip            (src_ip),
        .dst_ip            (dst_ip),
        .ip_proto          (ip_proto),
        .ip_len            (ip_len),
        .src_port          (src_port),
        .dst_port          (dst_port),
        .tcp_flags         (tcp_flags),
        .frm_eof           (frm_eof),
        .ctrl_block_en     (ctrl_block_en),
        .ctrl_syn_limit_en (1'b0),          // Tạm tắt Lớp 2 để tập trung demo Lớp 1
        .syn_limit         (16'd100),
        .bl_valid          (bl_valid),
        .bl_ip0            (bl_ip0),
        .bl_ip1            (bl_ip1),
        .bl_ip2            (bl_ip2),
        .bl_ip3            (bl_ip3),
        .bl_ip4            (bl_ip4),
        .bl_ip5            (bl_ip5),
        .bl_ip6            (bl_ip6),
        .bl_ip7            (bl_ip7),
        .clear_counters    (1'b0),
        .verdict_valid     (verdict_valid),
        .verdict_drop      (verdict_drop),
        .cnt_fwd           (cnt_fwd),
        .cnt_drop_bl       (cnt_drop_bl),
        .cnt_drop_syn      (cnt_drop_syn)
    );

    // Xung clock 27 MHz
    initial clk = 0;
    always #18.5 clk = ~clk;

    // Giám sát khi có quyết định
    reg res_drop;
    reg res_valid;
    always @(posedge clk) begin
        if (verdict_valid) begin
            res_drop  <= verdict_drop;
            res_valid <= 1'b1;
        end
    end

    // Task hỗ trợ bơm gói tin Ethernet
    task send_packet;
        input        is_arp_pkt;
        input [31:0] s_ip;
        input [31:0] d_ip;
        input [7:0]  proto;
        input [7:0]  flags;
        input [15:0] sp;
        input [15:0] dp;
        integer i;
        reg [7:0] pkt [0:63];
        begin
            res_valid = 1'b0;

            // MAC Header (14 bytes)
            pkt[0] = 8'hAA; pkt[1] = 8'hBB; pkt[2] = 8'hCC; pkt[3] = 8'hDD; pkt[4] = 8'hEE; pkt[5] = 8'hFF;
            pkt[6] = 8'h11; pkt[7] = 8'h22; pkt[8] = 8'h33; pkt[9] = 8'h44; pkt[10]= 8'h55; pkt[11]= 8'h66;

            if (is_arp_pkt) begin
                pkt[12] = 8'h08; pkt[13] = 8'h06; // ARP
            end else begin
                pkt[12] = 8'h08; pkt[13] = 8'h00; // IPv4
            end

            // IPv4 Header
            pkt[14] = 8'h45; pkt[15] = 8'h00;
            pkt[16] = 8'h00; pkt[17] = 8'h30; // Length
            pkt[18] = 8'h00; pkt[19] = 8'h01;
            pkt[20] = 8'h00; pkt[21] = 8'h00;
            pkt[22] = 8'h40;
            pkt[23] = proto; // 6: TCP, 17: UDP
            pkt[24] = 8'h00; pkt[25] = 8'h00;

            // IP Nguồn [31:0]
            pkt[26] = s_ip[31:24]; pkt[27] = s_ip[23:16];
            pkt[28] = s_ip[15:8];  pkt[29] = s_ip[7:0];

            // IP Đích [31:0]
            pkt[30] = d_ip[31:24]; pkt[31] = d_ip[23:16];
            pkt[32] = d_ip[15:8];  pkt[33] = d_ip[7:0];

            // TCP Header
            pkt[34] = sp[15:8]; pkt[35] = sp[7:0];
            pkt[36] = dp[15:8]; pkt[37] = dp[7:0];
            pkt[38] = 8'h00; pkt[39] = 8'h00; pkt[40] = 8'h00; pkt[41] = 8'h01;
            pkt[42] = 8'h00; pkt[43] = 8'h00; pkt[44] = 8'h00; pkt[45] = 8'h00;
            pkt[46] = 8'h50;
            pkt[47] = flags; // Cờ SYN=0x02, ACK=0x10...
            pkt[48] = 8'h72; pkt[49] = 8'h10;
            pkt[50] = 8'h00; pkt[51] = 8'h00;
            pkt[52] = 8'h00; pkt[53] = 8'h00;

            for (i = 54; i < 64; i = i + 1) pkt[i] = 8'h00;

            // Đẩy từng byte vào clock 27MHz
            frm_dir    = 1'b0; // Ngoài vào trong
            frm_crc_ok = 1'b1;

            @(posedge clk);
            for (i = 0; i < 64; i = i + 1) begin
                frm_valid = 1'b1;
                frm_data  = pkt[i];
                frm_sof   = (i == 0);
                frm_eof   = (i == 63);
                @(posedge clk);
            end

            frm_valid = 1'b0;
            frm_sof   = 1'b0;
            frm_eof   = 1'b0;

            wait(res_valid == 1'b1);
            @(posedge clk);
            #10;
        end
    endtask

    // ========================================================================
    // KỊCH BẢN DEMO TRỰC TIẾP
    // ========================================================================
    initial begin
        rst_n         = 1'b0;
        frm_valid     = 1'b0;
        frm_data      = 8'h00;
        frm_sof       = 1'b0;
        frm_eof       = 1'b0;
        ctrl_block_en = 1'b1; // Bật chức năng lọc Sổ đen
        bl_valid      = 8'b0000_0001; // Ô 0 có hiệu lực
        bl_ip0        = 32'hC0A80A32; // 192.168.10.50 (IP BỊ PHẠT CHẶN)
        bl_ip1        = 32'd0; bl_ip2 = 32'd0; bl_ip3 = 32'd0;
        bl_ip4        = 32'd0; bl_ip5 = 32'd0; bl_ip6 = 32'd0; bl_ip7 = 32'd0;

        #100;
        rst_n = 1'b1; // Thả reset
        #50;

        $display("\n========================================================================");
        $display("   BUỔI BÁO CÁO TIẾN ĐỘ TUẦN - PHẦN 3 (NGƯỜI 3: PHẠM HUY ĐẠI)");
        $display("   DEMO: KHỐI TÁCH HEADER (pkt_parser) & BỘ LỌC SỔ ĐEN LỚP 1 (pkt_filter)");
        $display("========================================================================");

        // --------------------------------------------------------------------
        // DEMO 1: Gói tin từ Cảm biến IoT hợp lệ (IP 192.168.10.20)
        // --------------------------------------------------------------------
        $display("\n>>> DEMO 1: Nhận gói tin từ Cảm biến IoT hợp lệ (IP: 192.168.10.20)");
        send_packet(1'b0, 32'hC0A80A14, 32'hC0A80A01, 8'd6, 8'h02, 16'd5000, 16'd1883);
        $display("    [pkt_parser] Bóc tách xong: is_ipv4=%0d, IP Nguồn=%0d.%0d.%0d.%0d, Port Đích=%0d, Cờ SYN=%0b",
                 is_ipv4, src_ip[31:24], src_ip[23:16], src_ip[15:8], src_ip[7:0], dst_port, tcp_flags[1]);
        $display("    [pkt_filter] Kiểm tra Danh sách chặn: KHÔNG TRÙNG.");
        $display("    -> PHÁN QUYẾT: verdict_drop = %0b (0 = CHO QUA NGUYÊN VẸN)", res_drop);

        // --------------------------------------------------------------------
        // DEMO 2: Gói tin từ Kẻ tấn công trong Sổ đen (IP 192.168.10.50)
        // --------------------------------------------------------------------
        $display("\n>>> DEMO 2: Nhận gói tin từ Kẻ xấu có IP trong Sổ đen (IP: 192.168.10.50)");
        send_packet(1'b0, 32'hC0A80A32, 32'hC0A80A01, 8'd6, 8'h02, 16'd6000, 16'd1883);
        $display("    [pkt_parser] Bóc tách xong: IP Nguồn=%0d.%0d.%0d.%0d (Trùng với bl_ip0 của CPU)",
                 src_ip[31:24], src_ip[23:16], src_ip[15:8], src_ip[7:0]);
        $display("    [pkt_filter] Khớp Sổ đen Lớp 1 (match_bl = 1).");
        $display("    -> PHÁN QUYẾT: verdict_drop = %0b (1 = VỨT BỎ NGAY LẬP TỨC)", res_drop);
        $display("    -> Tổng số gói bị phạt bỏ: cnt_drop_bl = %0d", cnt_drop_bl);

        // --------------------------------------------------------------------
        // DEMO 3: Gói tin ARP (Hỏi đường mạng)
        // --------------------------------------------------------------------
        $display("\n>>> DEMO 3: Nhận gói tin ARP (EtherType 0x0806)");
        send_packet(1'b1, 32'd0, 32'd0, 8'd0, 8'd0, 16'd0, 16'd0);
        $display("    [pkt_parser] Phát hiện gói ARP: is_ipv4 = %0d", is_ipv4);
        $display("    [pkt_filter] Áp dụng luật miễn trừ: ARP luôn cho qua để 2 bên nhìn thấy nhau.");
        $display("    -> PHÁN QUYẾT: verdict_drop = %0b (0 = CHO QUA)", res_drop);

        $display("\n========================================================================");
        $display("   ✅ HOÀN THÀNH DEMO TIẾN ĐỘ TUẦN: CẢ 2 KHỐI HOẠT ĐỘNG CHUẨN XÁC 100%%!");
        $display("========================================================================\n");
        #100;
        $finish;
    end

endmodule
