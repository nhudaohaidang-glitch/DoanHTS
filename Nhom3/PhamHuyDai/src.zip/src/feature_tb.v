// ============================================================
// Module: feature_tb (Testbench)
// Mô tả: Testbench kiểm tra toàn bộ hệ thống trích xuất đặc trưng
//        Giả lập SPI Master gửi gói tin đến SPI Slave → Feature Extractor
//
// Kịch bản thử nghiệm:
//   Gửi 6 gói tin trong 1 cửa sổ thời gian:
//     - Gói 1: flags=0x00 (không SYN), src_ip=0x0A, dst_port=0x50
//     - Gói 2: flags=0x00 (không SYN), src_ip=0x14, dst_port=0x51
//     - Gói 3: flags=0x00 (không SYN), src_ip=0x0A, dst_port=0x50 (trùng IP/port)
//     - Gói 4: flags=0x00 (không SYN), src_ip=0x1E, dst_port=0x1F
//     - Gói 5: flags=0x01 (SYN),       src_ip=0x28, dst_port=0x15
//     - Gói 6: flags=0x01 (SYN),       src_ip=0x32, dst_port=0x50
//   Sau đó gửi byte điều khiển 0xFF để kết thúc cửa sổ
//
// Kết quả mong đợi:
//   - pkt_count   = 6
//   - syn_ratio   ≈ 85  (2/6 * 255 ≈ 85)
//   - unique_ips  = số bit 1 trong bitmap IP (dựa theo ip%8)
//   - unique_ports= số bit 1 trong bitmap port (dựa theo port%8)
//
// Tác giả: Nhóm đồ án FPGA – Tang Nano 9K
// ============================================================

`timescale 1ns / 1ps

module feature_tb;

    // ============================================================
    // Khai báo tín hiệu (signals)
    // ============================================================

    // -- Clock và Reset --
    reg clk;
    reg rst_n;

    // -- Tín hiệu SPI Master (giả lập) --
    reg sck;        // SPI clock do testbench tạo ra
    reg cs_n;       // Chip Select (kéo thấp khi giao tiếp)
    reg mosi;       // Đường data từ Master đến Slave

    // -- Kết nối nội bộ giữa SPI Slave và Feature Extractor --
    wire [7:0] rx_byte;   // Byte nhận từ SPI
    wire       rx_valid;  // Xung valid

    // -- Giao diện đầu ra đặc trưng --
    wire [7:0] pkt_count;
    wire [7:0] syn_ratio;
    wire [7:0] unique_ips;
    wire [7:0] unique_ports;
    wire       feat_valid;
    reg        feat_ready;  // Testbench giả lập bên AI đọc kết quả

    // ============================================================
    // Khởi tạo các module cần kiểm tra (DUT - Device Under Test)
    // ============================================================

    // Instantiate SPI Slave
    spi_slave u_spi_slave (
        .clk      (clk),
        .rst_n    (rst_n),
        .sck      (sck),
        .cs_n     (cs_n),
        .mosi     (mosi),
        .rx_byte  (rx_byte),
        .rx_valid (rx_valid)
    );

    // Instantiate Feature Extractor
    feature_extractor #(
        .WINDOW_SIZE(16)
    ) u_feat_ext (
        .clk          (clk),
        .rst_n        (rst_n),
        .rx_byte      (rx_byte),
        .rx_valid     (rx_valid),
        .feat_valid   (feat_valid),
        .feat_ready   (feat_ready),
        .pkt_count    (pkt_count),
        .syn_ratio    (syn_ratio),
        .unique_ips   (unique_ips),
        .unique_ports (unique_ports)
    );

    // ============================================================
    // Tạo xung clock hệ thống: chu kỳ 10ns (100 MHz)
    // ============================================================
    initial clk = 0;
    always #5 clk = ~clk;  // Toggle mỗi 5ns → chu kỳ 10ns

    // ============================================================
    // Task: Gửi 1 byte qua SPI (giả lập SPI Master)
    // SCK tần số thấp hơn system clock để SPI Slave kịp đồng bộ
    // Mỗi bit: kéo SCK thấp → đặt MOSI → kéo SCK cao → lấy mẫu
    // ============================================================
    task spi_send_byte;
        input [7:0] data;     // Byte cần gửi
        integer i;
        begin
            // Gửi từ MSB (bit 7) đến LSB (bit 0)
            for (i = 7; i >= 0; i = i - 1) begin
                sck  = 1'b0;           // SCK thấp trước
                mosi = data[i];        // Đặt bit lên MOSI
                #50;                   // Giữ 50ns
                sck  = 1'b1;           // SCK lên cao → Slave lấy mẫu
                #50;                   // Giữ 50ns
            end
            sck = 1'b0;                // Đưa SCK về thấp sau khi xong
            #20;
        end
    endtask

    // ============================================================
    // Task: Gửi 1 gói tin hoàn chỉnh (4 bytes)
    // Định dạng: [flags][src_ip][dst_port][ctrl]
    // ============================================================
    task spi_send_packet;
        input [7:0] flags;     // Byte flags (bit0 = SYN)
        input [7:0] src_ip;    // Byte IP nguồn (8-bit thấp)
        input [7:0] dst_port;  // Byte cổng đích (8-bit thấp)
        input [7:0] ctrl;      // Byte điều khiển (0xFF = kết thúc window)
        begin
            cs_n = 1'b0;       // Kéo CS xuống thấp (bắt đầu giao tiếp)
            #30;

            $display("[TB] Gửi gói: flags=%02h, src_ip=%02h, dst_port=%02h, ctrl=%02h",
                     flags, src_ip, dst_port, ctrl);

            spi_send_byte(flags);      // Byte 0: flags
            #20;
            spi_send_byte(src_ip);     // Byte 1: src_ip
            #20;
            spi_send_byte(dst_port);   // Byte 2: dst_port
            #20;
            spi_send_byte(ctrl);       // Byte 3: ctrl

            #30;
            cs_n = 1'b1;       // Nhả CS (kết thúc giao tiếp)
            #100;              // Chờ một chút giữa các gói
        end
    endtask

    // ============================================================
    // Kịch bản test chính
    // ============================================================
    initial begin
        // -- Tạo file VCD để xem waveform (nếu cần) --
        $dumpfile("feature_tb.vcd");
        $dumpvars(0, feature_tb);

        // -- Khởi tạo tín hiệu --
        rst_n      = 1'b0;
        sck        = 1'b0;
        cs_n       = 1'b1;   // CS không tích cực ban đầu
        mosi       = 1'b0;
        feat_ready = 1'b0;

        // -- Áp dụng reset --
        #100;
        rst_n = 1'b1;        // Nhả reset
        #50;

        $display("=================================================");
        $display("[TB] Bắt đầu kiểm tra Feature Extractor");
        $display("=================================================");
        $display("[TB] Gửi 6 gói tin (4 bình thường + 2 SYN)");
        $display("-------------------------------------------------");

        // --------------------------------------------------
        // Gói 1: Không SYN, src_ip=0x0A (10), dst_port=0x50 (80)
        // ctrl = 0x00 → còn gói tiếp theo trong cửa sổ
        // IP bitmap: bit (10 % 8) = bit 2 → bitmap = 0b00000100
        // Port bitmap: bit (80 % 8) = bit 0 → bitmap = 0b00000001
        // --------------------------------------------------
        spi_send_packet(8'h00, 8'h0A, 8'h50, 8'h00);

        // --------------------------------------------------
        // Gói 2: Không SYN, src_ip=0x14 (20), dst_port=0x51 (81)
        // IP bitmap: bit (20 % 8) = bit 4 → thêm bit 4
        // Port bitmap: bit (81 % 8) = bit 1 → thêm bit 1
        // --------------------------------------------------
        spi_send_packet(8'h00, 8'h14, 8'h51, 8'h00);

        // --------------------------------------------------
        // Gói 3: Không SYN, src_ip=0x0A (10), dst_port=0x50 (80) (TRÙNG GÓI 1)
        // Bitmap không thay đổi vì IP và port đã được đánh dấu
        // --------------------------------------------------
        spi_send_packet(8'h00, 8'h0A, 8'h50, 8'h00);

        // --------------------------------------------------
        // Gói 4: Không SYN, src_ip=0x1E (30), dst_port=0x1F (31)
        // IP bitmap: bit (30 % 8) = bit 6 → thêm bit 6
        // Port bitmap: bit (31 % 8) = bit 7 → thêm bit 7
        // --------------------------------------------------
        spi_send_packet(8'h00, 8'h1E, 8'h1F, 8'h00);

        // --------------------------------------------------
        // Gói 5: CÓ SYN (flags bit0=1), src_ip=0x28 (40), dst_port=0x15 (21)
        // IP bitmap: bit (40 % 8) = bit 0 → thêm bit 0
        // Port bitmap: bit (21 % 8) = bit 5 → thêm bit 5
        // --------------------------------------------------
        spi_send_packet(8'h01, 8'h28, 8'h15, 8'h00);

        // --------------------------------------------------
        // Gói 6: CÓ SYN (flags bit0=1), src_ip=0x32 (50), dst_port=0x50 (80)
        // IP bitmap: bit (50 % 8) = bit 2 → bit 2 đã có (trùng với gói 1)
        // Port bitmap: bit (80 % 8) = bit 0 → bit 0 đã có (trùng với gói 1)
        // ctrl = 0xFF → kết thúc cửa sổ thời gian!
        // --------------------------------------------------
        spi_send_packet(8'h01, 8'h32, 8'h50, 8'hFF);

        $display("-------------------------------------------------");
        $display("[TB] Đã gửi xong 6 gói. Chờ Feature Extractor tính toán...");
        $display("-------------------------------------------------");

        // Chờ module tính toán xong (vài chu kỳ clock)
        #500;

        // Kiểm tra feat_valid
        if (feat_valid) begin
            $display("[TB] feat_valid = 1 → Đặc trưng đã sẵn sàng!");
            $display("=================================================");
            $display("[TB] KẾT QUẢ TRÍCH XUẤT ĐẶC TRƯNG:");
            $display("  pkt_count    = %0d  (mong đợi: 6)", pkt_count);
            $display("  syn_ratio    = %0d  (mong đợi: ~85, tức 2/6 * 255)", syn_ratio);
            $display("  unique_ips   = %0d  (mong đợi: 4, IP bits: 2,4,6,0)", unique_ips);
            $display("  unique_ports = %0d  (mong đợi: 4, port bits: 0,1,7,5)", unique_ports);
            $display("=================================================");

            // --- Kiểm tra từng giá trị ---
            if (pkt_count == 8'd6)
                $display("[PASS] pkt_count chính xác!");
            else
                $display("[FAIL] pkt_count sai! Nhận được: %0d", pkt_count);

            if (syn_ratio >= 8'd80 && syn_ratio <= 8'd90)
                $display("[PASS] syn_ratio trong khoảng hợp lý (~85)!");
            else
                $display("[FAIL] syn_ratio sai! Nhận được: %0d", syn_ratio);

            if (unique_ips == 8'd4)
                $display("[PASS] unique_ips chính xác!");
            else
                $display("[FAIL] unique_ips sai! Nhận được: %0d", unique_ips);

            if (unique_ports == 8'd4)
                $display("[PASS] unique_ports chính xác!");
            else
                $display("[FAIL] unique_ports sai! Nhận được: %0d", unique_ports);

            // -- Giả lập AI đọc kết quả (feat_ready = 1) --
            #20;
            feat_ready = 1'b1;
            #10;
            feat_ready = 1'b0;
            $display("[TB] AI đã đọc kết quả (feat_ready kéo lên 1)");
        end else begin
            $display("[FAIL] feat_valid = 0 sau khi chờ → Module chưa xuất kết quả!");
        end

        #200;
        $display("=================================================");
        $display("[TB] Kết thúc mô phỏng.");
        $display("=================================================");
        $finish;
    end

    // ============================================================
    // Monitor: In ra khi có byte SPI được nhận
    // ============================================================
    always @(posedge clk) begin
        if (rx_valid)
            $display("[SPI] rx_byte = 0x%02h tại thời điểm %0t ns", rx_byte, $time);
    end

    // ============================================================
    // Timeout: Kết thúc mô phỏng nếu quá lâu (phòng trường hợp treo)
    // ============================================================
    initial begin
        #500000;
        $display("[TB] TIMEOUT! Mô phỏng bị treo, tự động kết thúc.");
        $finish;
    end

endmodule
