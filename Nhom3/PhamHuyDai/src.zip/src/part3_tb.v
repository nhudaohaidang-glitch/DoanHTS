// ============================================================================
// Testbench: part3_tb
// Kiểm tra 5 trường hợp bắt buộc theo yêu cầu Đề cương phương án mới (trang 8):
//   1. IP bị chặn -> Bỏ (Drop)
//   2. SYN vượt ngưỡng Token Bucket -> Bỏ (Drop)
//   3. Gói của kết nối đang có (TCP ACK) -> Qua (Pass)
//   4. Gói ARP -> Luôn qua (Pass)
//   5. Gói từ IP bị chặn KHÔNG làm giảm suất SYN (token) của IP khác
// Đồng thời kiểm tra thuật toán Boyer-Moore tìm suspect_ip & confirm_cnt.
// ============================================================================

`timescale 1ns / 1ps

module part3_tb;

    // Clock & Reset
    reg clk;
    reg rst_n;

    // Tín hiệu khung từ Phần 4 (giả lập)
    reg        frm_valid;
    reg  [7:0] frm_data;
    reg        frm_sof;
    reg        frm_eof;
    reg        frm_dir;
    reg        frm_crc_ok;

    // Đầu ra quyết định
    wire       verdict_valid;
    wire       verdict_drop;

    // Cấu hình từ Phần 1
    reg        ctrl_block_en;
    reg        ctrl_syn_limit_en;
    reg [15:0] syn_limit;
    reg [7:0]  bl_valid;
    reg [31:0] bl_ip0, bl_ip1, bl_ip2, bl_ip3;
    reg [31:0] bl_ip4, bl_ip5, bl_ip6, bl_ip7;
    reg        clear_counters;
    wire [31:0] cnt_fwd;
    wire [31:0] cnt_drop_bl;
    wire [31:0] cnt_drop_syn;

    // Đặc trưng cho AI / CPU
    reg        ext_win_tick;
    wire       win_valid;
    wire [31:0] pkt_cnt;
    wire [31:0] syn_cnt;
    wire [31:0] byte_cnt;
    wire [7:0]  unique_ips;
    wire [7:0]  unique_ports;
    wire [31:0] suspect_ip;
    wire [31:0] confirm_cnt;

    // Kết nối với module đỉnh Phần 3
    part3_top u_dut (
        .clk               (clk),
        .rst_n             (rst_n),
        .frm_valid         (frm_valid),
        .frm_data          (frm_data),
        .frm_sof           (frm_sof),
        .frm_eof           (frm_eof),
        .frm_dir           (frm_dir),
        .frm_crc_ok        (frm_crc_ok),
        .verdict_valid     (verdict_valid),
        .verdict_drop      (verdict_drop),
        .ctrl_block_en     (ctrl_block_en),
        .ctrl_syn_limit_en (ctrl_syn_limit_en),
        .syn_limit         (syn_limit),
        .bl_valid          (bl_valid),
        .bl_ip0            (bl_ip0),
        .bl_ip1            (bl_ip1),
        .bl_ip2            (bl_ip2),
        .bl_ip3            (bl_ip3),
        .bl_ip4            (bl_ip4),
        .bl_ip5            (bl_ip5),
        .bl_ip6            (bl_ip6),
        .bl_ip7            (bl_ip7),
        .clear_counters    (clear_counters),
        .cnt_fwd           (cnt_fwd),
        .cnt_drop_bl       (cnt_drop_bl),
        .cnt_drop_syn      (cnt_drop_syn),
        .ext_win_tick      (ext_win_tick),
        .win_valid         (win_valid),
        .pkt_cnt           (pkt_cnt),
        .syn_cnt           (syn_cnt),
        .byte_cnt          (byte_cnt),
        .unique_ips        (unique_ips),
        .unique_ports      (unique_ports),
        .suspect_ip        (suspect_ip),
        .confirm_cnt       (confirm_cnt)
    );

    // Tạo xung clock 27 MHz (chu kỳ ~37.037 ns -> nửa chu kỳ ~18.5 ns)
    initial clk = 0;
    always #18.5 clk = ~clk;

    // Biến giám sát kết quả
    reg last_verdict_drop;
    reg verdict_received;

    always @(posedge clk) begin
        if (verdict_valid) begin
            last_verdict_drop <= verdict_drop;
            verdict_received  <= 1'b1;
        end
    end

    // ========================================================================
    // Task: Gửi 1 khung mạng Ethernet giả lập
    // ========================================================================
    task send_frame;
        input        is_arp;       // 1 = ARP, 0 = IPv4
        input [31:0] sip;          // IP nguồn (ví dụ 0xC0A80A32)
        input [31:0] dip;          // IP đích
        input [7:0]  proto;        // 6 = TCP, 17 = UDP
        input [7:0]  flags;        // Cờ TCP (bit 1=SYN, bit 4=ACK)
        input [15:0] sport;
        input [15:0] dport;
        input        dir;          // 0: ngoài->trong, 1: trong->ngoài
        integer i;
        reg [7:0] dummy_frame [0:63];
        begin
            verdict_received = 1'b0;

            // Xây dựng khung mẫu 64 bytes
            // 0..5: MAC đích
            dummy_frame[0] = 8'h00; dummy_frame[1] = 8'h11; dummy_frame[2] = 8'h22;
            dummy_frame[3] = 8'h33; dummy_frame[4] = 8'h44; dummy_frame[5] = 8'h55;
            // 6..11: MAC nguồn
            dummy_frame[6] = 8'h66; dummy_frame[7] = 8'h77; dummy_frame[8] = 8'h88;
            dummy_frame[9] = 8'h99; dummy_frame[10]= 8'hAA; dummy_frame[11]= 8'hBB;

            // 12..13: EtherType
            if (is_arp) begin
                dummy_frame[12] = 8'h08; dummy_frame[13] = 8'h06; // ARP
            end else begin
                dummy_frame[12] = 8'h08; dummy_frame[13] = 8'h00; // IPv4
            end

            // 14..33: IPv4 Header (20 bytes)
            dummy_frame[14] = 8'h45; // Version 4, IHL 5
            dummy_frame[15] = 8'h00; // DSCP/ECN
            dummy_frame[16] = 8'h00; dummy_frame[17] = 8'h30; // Length = 48
            dummy_frame[18] = 8'h12; dummy_frame[19] = 8'h34; // ID
            dummy_frame[20] = 8'h40; dummy_frame[21] = 8'h00; // Flags/Frag
            dummy_frame[22] = 8'h40; // TTL
            dummy_frame[23] = proto; // Protocol
            dummy_frame[24] = 8'h00; dummy_frame[25] = 8'h00; // Checksum

            // Source IP [31:0]
            dummy_frame[26] = sip[31:24]; dummy_frame[27] = sip[23:16];
            dummy_frame[28] = sip[15:8];  dummy_frame[29] = sip[7:0];

            // Destination IP [31:0]
            dummy_frame[30] = dip[31:24]; dummy_frame[31] = dip[23:16];
            dummy_frame[32] = dip[15:8];  dummy_frame[33] = dip[7:0];

            // 34..53: TCP Header (bắt đầu từ byte 34)
            dummy_frame[34] = sport[15:8]; dummy_frame[35] = sport[7:0];
            dummy_frame[36] = dport[15:8]; dummy_frame[37] = dport[7:0];
            dummy_frame[38] = 8'h00; dummy_frame[39] = 8'h00;
            dummy_frame[40] = 8'h00; dummy_frame[41] = 8'h01; // Seq num
            dummy_frame[42] = 8'h00; dummy_frame[43] = 8'h00;
            dummy_frame[44] = 8'h00; dummy_frame[45] = 8'h00; // Ack num
            dummy_frame[46] = 8'h50; // Data offset 5 (20 bytes header)
            dummy_frame[47] = flags; // Cờ TCP (SYN/ACK)
            dummy_frame[48] = 8'h72; dummy_frame[49] = 8'h10; // Window size
            dummy_frame[50] = 8'h00; dummy_frame[51] = 8'h00; // Checksum
            dummy_frame[52] = 8'h00; dummy_frame[53] = 8'h00; // Urgent ptr

            // 54..63: Dữ liệu đệm
            for (i = 54; i < 64; i = i + 1) dummy_frame[i] = 8'hAA;

            // Bắt đầu bơm từng byte vào qua clock
            frm_dir    = dir;
            frm_crc_ok = 1'b1;

            @(posedge clk);
            for (i = 0; i < 64; i = i + 1) begin
                frm_valid = 1'b1;
                frm_data  = dummy_frame[i];
                frm_sof   = (i == 0);
                frm_eof   = (i == 63);
                @(posedge clk);
            end

            frm_valid = 1'b0;
            frm_sof   = 1'b0;
            frm_eof   = 1'b0;

            // Chờ nhận verdict
            wait(verdict_received == 1'b1);
            @(posedge clk);
            #10;
        end
    endtask

    // ========================================================================
    // Kịch bản kiểm thử 5 trường hợp
    // ========================================================================
    integer pass_count = 0;

    initial begin
        // Khởi tạo
        rst_n             = 1'b0;
        frm_valid         = 1'b0;
        frm_data          = 8'd0;
        frm_sof           = 1'b0;
        frm_eof           = 1'b0;
        frm_dir           = 1'b0;
        frm_crc_ok        = 1'b1;
        ctrl_block_en     = 1'b1; // Bật danh sách chặn
        ctrl_syn_limit_en = 1'b1; // Bật giới hạn SYN
        syn_limit         = 16'd2; // Giới hạn chỉ cho 2 gói SYN/giây để dễ test
        bl_valid          = 8'b0000_0001; // Ô 0 có hiệu lực
        bl_ip0            = 32'hC0A80A32; // 192.168.10.50 bị chặn!
        bl_ip1            = 32'd0; bl_ip2 = 32'd0; bl_ip3 = 32'd0;
        bl_ip4            = 32'd0; bl_ip5 = 32'd0; bl_ip6 = 32'd0; bl_ip7 = 32'd0;
        clear_counters    = 1'b0;
        ext_win_tick      = 1'b0;

        #100;
        rst_n = 1'b1; // Thả reset
        #50;

        $display("====================================================================");
        $display("[TESTBENCH PHẦN 3] BẮT ĐẦU KIỂM THỬ 5 TRƯỜNG HỢP THEO ĐỀ CƯƠNG MỚI");
        $display("====================================================================");

        // --------------------------------------------------------------------
        // TRƯỜNG HỢP 1: IP bị chặn -> Bỏ (Drop)
        // Gửi gói từ IP 192.168.10.50 (nằm trong bl_ip0)
        // --------------------------------------------------------------------
        $display("\n[TC 1] Kiểm tra: Gói tin từ IP trong Blocklist (192.168.10.50)");
        send_frame(1'b0, 32'hC0A80A32, 32'hC0A80A01, 8'd6, 8'h02, 16'd1234, 16'd1883, 1'b0);
        if (last_verdict_drop == 1'b1) begin
            $display("-> [PASS] Đã BỎ gói tin từ IP bị chặn (verdict_drop = 1).");
            pass_count = pass_count + 1;
        end else begin
            $display("-> [FAIL] Gói từ IP bị chặn không bị bỏ!");
        end

        // --------------------------------------------------------------------
        // TRƯỜNG HỢP 2: Giới hạn SYN vượt ngưỡng -> Bỏ (Drop)
        // syn_limit = 2. Gửi 3 gói SYN từ IP sạch 192.168.10.60
        // Gói 1: Qua. Gói 2: Qua. Gói 3: VƯỢT NGƯỠNG -> BỎ!
        // --------------------------------------------------------------------
        $display("\n[TC 2] Kiểm tra: Giới hạn SYN Token Bucket (ngưỡng = 2 gói)");
        send_frame(1'b0, 32'hC0A80A3C, 32'hC0A80A01, 8'd6, 8'h02, 16'd2001, 16'd1883, 1'b0); // Gói 1
        send_frame(1'b0, 32'hC0A80A3C, 32'hC0A80A01, 8'd6, 8'h02, 16'd2002, 16'd1883, 1'b0); // Gói 2
        send_frame(1'b0, 32'hC0A80A3C, 32'hC0A80A01, 8'd6, 8'h02, 16'd2003, 16'd1883, 1'b0); // Gói 3 (vượt)
        if (last_verdict_drop == 1'b1) begin
            $display("-> [PASS] Gói SYN thứ 3 vượt ngưỡng đã bị BỎ (verdict_drop = 1).");
            pass_count = pass_count + 1;
        end else begin
            $display("-> [FAIL] Gói SYN vượt ngưỡng không bị bỏ!");
        end

        // --------------------------------------------------------------------
        // TRƯỜNG HỢP 3: Gói của kết nối đang có (TCP ACK) -> Qua
        // Cờ ACK = 1, SYN = 0 (flags = 8'h10), không bị giới hạn bởi Token Bucket
        // --------------------------------------------------------------------
        $display("\n[TC 3] Kiểm tra: Gói TCP của kết nối đang có (TCP ACK)");
        send_frame(1'b0, 32'hC0A80A3C, 32'hC0A80A01, 8'd6, 8'h10, 16'd2001, 16'd1883, 1'b0);
        if (last_verdict_drop == 1'b0) begin
            $display("-> [PASS] Gói TCP ACK hợp lệ ĐƯỢC CHO QUA (verdict_drop = 0).");
            pass_count = pass_count + 1;
        end else begin
            $display("-> [FAIL] Gói TCP ACK bị chặn nhầm!");
        end

        // --------------------------------------------------------------------
        // TRƯỜNG HỢP 4: Gói ARP -> Luôn qua
        // is_arp = 1 (EtherType 0x0806)
        // --------------------------------------------------------------------
        $display("\n[TC 4] Kiểm tra: Gói tin ARP (để 2 bên tìm thấy nhau)");
        send_frame(1'b1, 32'h00000000, 32'h00000000, 8'd0, 8'h00, 16'd0, 16'd0, 1'b0);
        if (last_verdict_drop == 1'b0) begin
            $display("-> [PASS] Gói ARP ĐƯỢC CHO QUA lập tức (verdict_drop = 0).");
            pass_count = pass_count + 1;
        end else begin
            $display("-> [FAIL] Gói ARP bị chặn nhầm!");
        end

        // --------------------------------------------------------------------
        // BỔ SUNG SỬA LỖI: Kiểm tra gói ICMP (ping) - Phải có kết quả xét
        // proto = 1 (ICMP), IP sạch -> phải cho qua!
        // --------------------------------------------------------------------
        $display("\n[TC ICMP] Kiểm tra: Gói tin ICMP (ping từ IP sạch)");
        send_frame(1'b0, 32'hC0A80A1E, 32'hC0A80A01, 8'd1, 8'h00, 16'd0, 16'd0, 1'b0);
        if (last_verdict_drop == 1'b0) begin
            $display("-> [PASS] Gói ICMP (ping) ĐÃ CÓ KẾT QUẢ XÉT và ĐƯỢC CHO QUA (verdict_drop = 0).");
        end else begin
            $display("-> [FAIL] Gói ICMP không có kết quả hoặc bị chặn nhầm!");
        end

        // --------------------------------------------------------------------
        // TRƯỜNG HỢP 5: Gói từ IP bị chặn KHÔNG làm giảm token của IP khác
        // Reset lại token bằng cách mô phỏng qua 1 giây hoặc nạp trực tiếp
        // Ở đây gửi 1 gói từ IP bị chặn (192.168.10.50 có cờ SYN)
        // Sau đó gửi tiếp 1 gói SYN từ IP sạch (192.168.10.70)
        // --------------------------------------------------------------------
        $display("\n[TC 5] Kiểm tra: Gói từ IP bị chặn KHÔNG tiêu hao token của IP khác");
        // Giả lập nạp lại xô token đầy đủ
        u_dut.u_filter.token_bucket = 16'd1; // Cho đúng 1 token
        // Gửi gói bị Blocklist chặn
        send_frame(1'b0, 32'hC0A80A32, 32'hC0A80A01, 8'd6, 8'h02, 16'd3001, 16'd1883, 1'b0);
        // Gửi gói từ IP sạch: nó PHẢI lấy được token duy nhất còn lại này và ĐƯỢC QUA!
        send_frame(1'b0, 32'hC0A80A46, 32'hC0A80A01, 8'd6, 8'h02, 16'd4001, 16'd1883, 1'b0);
        if (last_verdict_drop == 1'b0) begin
            $display("-> [PASS] Token vẫn còn nguyên cho IP sạch (verdict_drop = 0).");
            pass_count = pass_count + 1;
        end else begin
            $display("-> [FAIL] Token bị trừ nhầm bởi IP trong danh sách chặn!");
        end

        // --------------------------------------------------------------------
        // KIỂM TRA THUẬT TOÁN BOYER-MOORE & XÁC NHẬN IP NGHI VẤN
        // --------------------------------------------------------------------
        $display("\n[BỔ SUNG] Kiểm tra thuật toán Boyer-Moore tìm suspect_ip & confirm_cnt");
        // Cửa sổ 1: IP 192.168.10.99 gửi liên tục 4 gói SYN
        send_frame(1'b0, 32'hC0A80A63, 32'hC0A80A01, 8'd6, 8'h02, 16'd5001, 16'd1883, 1'b0);
        send_frame(1'b0, 32'hC0A80A63, 32'hC0A80A01, 8'd6, 8'h02, 16'd5002, 16'd1883, 1'b0);
        send_frame(1'b0, 32'hC0A80A63, 32'hC0A80A01, 8'd6, 8'h02, 16'd5003, 16'd1883, 1'b0);

        // Hết Cửa sổ 1 -> Phát xung ext_win_tick
        @(posedge clk);
        ext_win_tick = 1'b1;
        @(posedge clk);
        ext_win_tick = 1'b0;
        @(posedge clk);

        $display("  -> Kết thúc Cửa sổ 1: suspect_ip = %h (Kỳ vọng: C0A80A63)", suspect_ip);

        // Cửa sổ 2: Gửi tiếp 2 gói SYN từ đúng suspect_ip này
        send_frame(1'b0, 32'hC0A80A63, 32'hC0A80A01, 8'd6, 8'h02, 16'd5004, 16'd1883, 1'b0);
        send_frame(1'b0, 32'hC0A80A63, 32'hC0A80A01, 8'd6, 8'h02, 16'd5005, 16'd1883, 1'b0);

        // Hết Cửa sổ 2 -> Phát xung ext_win_tick
        @(posedge clk);
        ext_win_tick = 1'b1;
        @(posedge clk);
        ext_win_tick = 1'b0;
        @(posedge clk);

        $display("  -> Kết thúc Cửa sổ 2: confirm_cnt = %0d (Kỳ vọng: 2)", confirm_cnt);

        $display("\n====================================================================");
        if (pass_count == 5 && suspect_ip == 32'hC0A80A63 && confirm_cnt == 32'd2) begin
            $display("🏆 KẾT QUẢ: TOÀN BỘ CÁC TRƯỜNG HỢP ĐỀU [PASS] 5/5!");
            $display("Phần 3 (Người 3) hoàn thành xuất sắc yêu cầu của đề cương.");
        end else begin
            $display("⚠️ KẾT QUẢ: %0d/5 PASS", pass_count);
        end
        $display("====================================================================");

        #100;
        $finish;
    end

endmodule
