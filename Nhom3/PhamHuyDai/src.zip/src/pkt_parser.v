// ============================================================================
// Module: pkt_parser  [SỬA LỖI v2: 08/11/2026]
// Nhiệm vụ: Bóc tách header Ethernet, IPv4, TCP/UDP từ dòng byte của khung.
//
// SỬA LỖI 1: Lệch 1 byte - byte_cnt phải tăng NGAY CẢ KHI frm_sof=1
//   Trước: khi frm_sof=1, byte_cnt reset về 0 nhưng KHÔNG tăng
//          → byte đầu tiên (index 0) và byte thứ 2 (index 1) đều có byte_cnt=0
//          → Toàn bộ byte số bị lệch 1 → EtherType đọc sai → IPv4 không nhận ra!
//   Sau:  dùng biến next_cnt để tính đúng: frm_sof → next=1 (byte tiếp theo là 1)
//
// SỬA LỖI 2: ICMP (ip_proto=1) không có hdr_valid
//   Thêm nhánh ICMP: sau khi đọc được ip_proto=1, phát hdr_valid sau vài byte
//
// Miền clock: 27 MHz hệ thống, reset rst_n tích cực thấp.
// ============================================================================

module pkt_parser (
    input  wire        clk,
    input  wire        rst_n,

    // Giao tiếp nhận dòng byte từ Phần 4 (MAC/FIFO)
    input  wire        frm_valid,
    input  wire [7:0]  frm_data,
    input  wire        frm_sof,
    input  wire        frm_eof,
    input  wire        frm_dir,
    input  wire        frm_crc_ok,

    // Bản ghi header xuất ra cho pkt_filter và feat_core
    output reg         hdr_valid,     // Xung 1 nhịp khi bóc xong header
    output reg         hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    output reg         is_ipv4,       // 1 = IPv4, 0 = ARP/loại khác
    output reg  [31:0] src_ip,        // Byte đầu ở bit cao [31:24]
    output reg  [31:0] dst_ip,        // Byte đầu ở bit cao [31:24]
    output reg  [7:0]  ip_proto,      // 6=TCP, 17=UDP, 1=ICMP
    output reg  [15:0] ip_len,        // Total length IPv4
    output reg  [15:0] src_port,      // Cổng nguồn TCP/UDP (ICMP = 0)
    output reg  [15:0] dst_port,      // Cổng đích TCP/UDP  (ICMP = 0)
    output reg  [7:0]  tcp_flags      // Cờ TCP (bit1=SYN, bit4=ACK); ICMP=0
);

    // -------------------------------------------------------------------------
    // Bộ đếm byte: đếm vị trí BYTE HIỆN TẠI ĐANG XỬ LÝ trong khung Ethernet
    // ĐÃ SỬA: sử dụng logic tăng ngay cả khi frm_sof để tránh lệch 1 byte
    // -------------------------------------------------------------------------
    reg [10:0] byte_cnt;      // Vị trí byte hiện tại (0 = byte MAC đích đầu tiên)

    // Wire tính giá trị byte_cnt cho nhịp TIẾP THEO (combinational)
    wire [10:0] next_cnt = frm_sof ? 11'd1       // Sau SOF: byte tiếp theo là byte 1
                                   : byte_cnt + 11'd1;

    // Lưu tạm EtherType byte cao
    reg [7:0]  ether_hi;
    reg [3:0]  ip_ihl;         // IHL của IPv4 header (đơn vị từ 32-bit)
    reg [10:0] l4_offset;      // Vị trí byte đầu tiên của TCP/UDP header

    // Thanh ghi lưu ip_proto ở nhịp trước (để dùng khi byte_cnt >= l4_offset)
    // vì ip_proto được lấy ở byte 23, l4_offset bắt đầu từ byte 34+
    // => ip_proto đã ổn định trước khi vào vùng L4

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            byte_cnt    <= 11'd0;
            hdr_valid   <= 1'b0;
            hdr_dir     <= 1'b0;
            is_ipv4     <= 1'b0;
            src_ip      <= 32'd0;
            dst_ip      <= 32'd0;
            ip_proto    <= 8'd0;
            ip_len      <= 16'd0;
            src_port    <= 16'd0;
            dst_port    <= 16'd0;
            tcp_flags   <= 8'd0;
            ether_hi    <= 8'd0;
            ip_ihl      <= 4'd5;
            l4_offset   <= 11'd34;
        end else begin
            hdr_valid <= 1'b0; // Xung 1 nhịp: mặc định tắt

            if (frm_valid) begin
                // ---- BƯỚC 1: Cập nhật bộ đếm byte ----
                // SỬA LỖI CHÍNH: byte_cnt luôn được tăng đúng,
                // kể cả byte đầu tiên khi frm_sof=1
                if (frm_sof) begin
                    // Đây là Byte số 0, nhịp TIẾP THEO sẽ là Byte số 1
                    byte_cnt <= 11'd1;
                    hdr_dir  <= frm_dir;
                    is_ipv4  <= 1'b0;
                    ip_proto <= 8'd0;
                    tcp_flags<= 8'd0;
                    src_port <= 16'd0;
                    dst_port <= 16'd0;
                end else begin
                    byte_cnt <= byte_cnt + 11'd1;
                end

                // ---- BƯỚC 2: Bóc tách theo vị trí byte ----
                // Lưu ý: byte_cnt là vị trí của byte ĐANG ĐI VÀO nhịp clock này
                case (byte_cnt)
                    // --- Ethernet Header ---
                    // Byte 0..5:  MAC đích  (bỏ qua)
                    // Byte 6..11: MAC nguồn (bỏ qua)

                    // EtherType byte cao (Byte 12)
                    11'd12: ether_hi <= frm_data;

                    // EtherType byte thấp (Byte 13) → phân loại gói
                    11'd13: begin
                        case ({ether_hi, frm_data})
                            16'h0800: is_ipv4 <= 1'b1;  // IPv4
                            default: begin
                                is_ipv4   <= 1'b0;
                                // ARP (0x0806) hay loại khác: cho qua ngay
                                hdr_valid <= 1'b1;
                            end
                        endcase
                    end

                    // --- IPv4 Header (bắt đầu Byte 14) ---
                    // Byte 14: Version + IHL
                    11'd14: if (is_ipv4) begin
                        ip_ihl    <= frm_data[3:0];
                        // l4_offset = 14 (Ethernet không có VLAN) + IHL*4
                        // IHL chuẩn = 5 → 14 + 20 = 34
                        l4_offset <= 11'd14 + {5'd0, frm_data[3:0], 2'b00};
                    end

                    // Byte 16..17: Total Length
                    11'd16: if (is_ipv4) ip_len[15:8] <= frm_data;
                    11'd17: if (is_ipv4) ip_len[7:0]  <= frm_data;

                    // Byte 23: Protocol (6=TCP, 17=UDP, 1=ICMP)
                    11'd23: if (is_ipv4) ip_proto <= frm_data;

                    // Byte 26..29: Source IP
                    11'd26: if (is_ipv4) src_ip[31:24] <= frm_data;
                    11'd27: if (is_ipv4) src_ip[23:16] <= frm_data;
                    11'd28: if (is_ipv4) src_ip[15:8]  <= frm_data;
                    11'd29: if (is_ipv4) src_ip[7:0]   <= frm_data;

                    // Byte 30..33: Destination IP
                    11'd30: if (is_ipv4) dst_ip[31:24] <= frm_data;
                    11'd31: if (is_ipv4) dst_ip[23:16] <= frm_data;
                    11'd32: if (is_ipv4) dst_ip[15:8]  <= frm_data;
                    11'd33: if (is_ipv4) dst_ip[7:0]   <= frm_data;

                    default: ;
                endcase

                // ---- BƯỚC 3: Bóc tách tầng L4 (TCP / UDP / ICMP) ----
                // Chỉ xử lý khi đã xác nhận IPv4 và đã vào vùng header L4
                if (is_ipv4 && (byte_cnt >= l4_offset)) begin
                    case (ip_proto)
                        // ---- TCP (Protocol = 6) ----
                        8'd6: begin
                            // Source Port: l4_offset + 0,1
                            if (byte_cnt == l4_offset)       src_port[15:8] <= frm_data;
                            if (byte_cnt == l4_offset + 1)   src_port[7:0]  <= frm_data;
                            // Dest Port: l4_offset + 2,3
                            if (byte_cnt == l4_offset + 2)   dst_port[15:8] <= frm_data;
                            if (byte_cnt == l4_offset + 3)   dst_port[7:0]  <= frm_data;
                            // TCP Flags: l4_offset + 13
                            if (byte_cnt == l4_offset + 13) begin
                                tcp_flags <= frm_data;
                                hdr_valid <= 1'b1; // Đọc xong header TCP quan trọng!
                            end
                        end

                        // ---- UDP (Protocol = 17) ----
                        8'd17: begin
                            if (byte_cnt == l4_offset)       src_port[15:8] <= frm_data;
                            if (byte_cnt == l4_offset + 1)   src_port[7:0]  <= frm_data;
                            if (byte_cnt == l4_offset + 2)   dst_port[15:8] <= frm_data;
                            if (byte_cnt == l4_offset + 3) begin
                                dst_port[7:0]  <= frm_data;
                                tcp_flags      <= 8'd0; // UDP không có cờ SYN
                                hdr_valid      <= 1'b1; // Đọc xong header UDP!
                            end
                        end

                        // ---- ICMP (Protocol = 1) - SỬA LỖI 2 ----
                        // ICMP không có port, hdr_valid sau khi đọc byte ip_proto
                        // Ta phát hdr_valid ngay sau khi vào vùng L4 (byte l4_offset)
                        8'd1: begin
                            if (byte_cnt == l4_offset) begin
                                src_port  <= 16'd0; // ICMP không có port
                                dst_port  <= 16'd0;
                                tcp_flags <= 8'd0;
                                hdr_valid <= 1'b1;  // Cho phép bộ lọc xét ICMP
                            end
                        end

                        default: begin
                            // Giao thức khác không nhận ra: cho qua, không phân tích thêm
                            if (byte_cnt == l4_offset) begin
                                hdr_valid <= 1'b1;
                            end
                        end
                    endcase
                end
            end // if (frm_valid)

            // Reset bộ đếm khi kết thúc khung (eof có thể đến cùng lúc valid)
            if (frm_eof) begin
                byte_cnt <= 11'd0;
            end
        end
    end

endmodule
