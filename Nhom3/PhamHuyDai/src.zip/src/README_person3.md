# README – Người 3: Trích xuất đặc trưng (Module 2.3)

> **Dự án:** IoT Gateway RISC-V tích hợp AI phát hiện tấn công DoS/Port Scan  
> **Board:** Tang Nano 9K (FPGA Gowin GW1NR-9)  
> **Phần:** Người 3 – SPI Slave, Bộ đệm, Bitmap, Trích xuất đặc trưng

---

## 1. Tổng quan hệ thống

Module này đóng vai trò **cầu nối** giữa luồng dữ liệu mạng (đến qua SPI) và AI accelerator.  
Luồng hoạt động tổng quát:

```
MCU/Máy tính mô phỏng
      │
      │ (SPI – Mode 0, 8-bit)
      ▼
┌─────────────┐
│  SPI Slave  │  ← Nhận từng byte, đồng bộ vào clock hệ thống
└──────┬──────┘
       │ rx_byte + rx_valid
       ▼
┌──────────────────┐
│ Feature Extractor│  ← FSM tích lũy thống kê, tính đặc trưng
└──────┬───────────┘
       │ pkt_count, syn_ratio, unique_ips, unique_ports
       │ (ready/valid handshake)
       ▼
  AI Accelerator
```

---

## 2. Mô tả từng file

### `spi_slave.v`
- **Chức năng:** Nhận dữ liệu 8-bit từ SPI Master theo chuẩn **SPI Mode 0** (CPOL=0, CPHA=0)
- **Nguyên lý:** Dùng 2 tầng flip-flop để đồng bộ hóa `SCK`, `CS_N`, `MOSI` vào clock hệ thống (tránh metastability)
- **Đầu ra:** `rx_byte[7:0]` và `rx_valid` (xung 1 chu kỳ khi nhận đủ 8 bit)
- **Giao thức SPI:**
  - MSB được gửi trước
  - Dữ liệu được lấy mẫu tại **cạnh lên** của `SCK`
  - `CS_N = 0` (tích cực thấp) khi đang giao tiếp

### `feature_extractor.v`
- **Chức năng:** FSM trích xuất 4 đặc trưng từ luồng gói tin trong một cửa sổ thời gian
- **Đầu vào:** `rx_byte`, `rx_valid` từ SPI Slave
- **Đầu ra:** `pkt_count`, `syn_ratio`, `unique_ips`, `unique_ports` (qua ready/valid)
- **Định dạng gói tin (4 bytes):**

  | Byte | Nội dung |
  |------|----------|
  | 0    | `flags` (bit0 = cờ SYN) |
  | 1    | `src_ip[7:0]` (8 bit thấp của IP nguồn) |
  | 2    | `dst_port[7:0]` (8 bit thấp của cổng đích) |
  | 3    | `ctrl` (`0xFF` = kết thúc cửa sổ, khác = tiếp tục) |

### `feature_tb.v`
- **Chức năng:** Testbench kiểm tra toàn bộ hệ thống
- **Kịch bản:** Gửi 6 gói (4 bình thường + 2 SYN) rồi kết thúc cửa sổ bằng `0xFF`
- **Kiểm tra:** In kết quả và so sánh với giá trị mong đợi

---

## 3. Sơ đồ trạng thái FSM (ASCII Art)

```
                     rst_n = 0
                         │
                         ▼
                    ┌─────────┐
              ┌────►│  IDLE   │◄─────────────────────────────┐
              │    └────┬────┘                                │
              │         │ rx_valid (nhận byte flags)          │
              │         ▼                                     │
              │   ┌───────────┐                               │
              │   │RECV_FLAGS │  (đợi byte src_ip)            │
              │   └─────┬─────┘                               │
              │         │ rx_valid                            │
              │         ▼                                     │
              │  ┌─────────────┐                              │
              │  │RECV_SRC_IP  │  (đợi byte dst_port)         │
              │  └──────┬──────┘                              │
              │         │ rx_valid                            │
              │         ▼                                     │
              │  ┌──────────────┐                             │
              │  │RECV_DST_PORT │  (tích lũy thống kê,        │
              │  └──────┬───────┘   đợi byte ctrl)            │
              │         │ rx_valid                            │
              │         ▼                                     │
              │   ┌───────────┐                               │
              │   │ RECV_CTRL │                               │
              │   └──┬─────┬──┘                               │
              │      │     │                                  │
              │   ctrl    ctrl                                │
              │   ≠0xFF   =0xFF                               │
              │      │     │                                  │
              └──────┘     ▼                                  │
                     ┌───────────┐                            │
                     │  COMPUTE  │  (tính syn_ratio,          │
                     └─────┬─────┘   popcount bitmap)         │
                           │                                  │
                           ▼                                  │
                     ┌───────────┐                            │
                     │  OUTPUT   │  feat_valid = 1            │
                     └─────┬─────┘                            │
                           │ feat_ready = 1                   │
                           └──────────────────────────────────┘
                             (reset cửa sổ, về IDLE)
```

---

## 4. Cách Bitmap hoạt động

**Vấn đề:** Làm sao đếm số IP nguồn *duy nhất* mà không tốn nhiều bộ nhớ?

**Giải pháp đơn giản: Bitmap 8-bit**

Mỗi bit trong byte 8-bit đại diện cho **một nhóm** địa chỉ IP hoặc cổng.

```
Ví dụ: src_ip = 0x0A (10 trong hệ thập phân)
  10 % 8 = 2  →  đặt bit số 2

  bitmap_ips ban đầu:  0 0 0 0 0 0 0 0
  Sau gói 1 (ip=10):   0 0 0 0 0 1 0 0  (bit 2 = 1)
                                 ↑
                               bit 2

  Sau gói 2 (ip=20):   0 0 0 1 0 1 0 0  (thêm bit 4, vì 20%8=4)
  Sau gói 3 (ip=10):   0 0 0 1 0 1 0 0  (không đổi, bit 2 đã = 1)
  Sau gói 4 (ip=30):   0 1 0 1 0 1 0 0  (thêm bit 6, vì 30%8=6)
  Sau gói 5 (ip=40):   0 1 0 1 0 1 0 1  (thêm bit 0, vì 40%8=0)
```

**Đếm số bit '1' (popcount):**
```
bitmap = 0b01010101 → 4 bit '1' → unique_ips = 4
```

> **Lưu ý:** Đây là xấp xỉ, không hoàn toàn chính xác (do hash collision),  
> nhưng đủ đơn giản và hiệu quả cho FPGA với tài nguyên hạn chế.

---

## 5. Hướng dẫn mô phỏng với Icarus Verilog

### Cài đặt Icarus Verilog

```bash
# Ubuntu/Debian
sudo apt-get install iverilog gtkwave

# Windows: Tải từ http://bleyer.org/icarus/
```

### Biên dịch và chạy mô phỏng

```bash
# Di chuyển vào thư mục src
cd "e:\Đề cương đồ án\src"

# Bước 1: Biên dịch tất cả file Verilog
iverilog -o feature_sim.vvp spi_slave.v feature_extractor.v feature_tb.v

# Bước 2: Chạy mô phỏng
vvp feature_sim.vvp

# Bước 3: Xem waveform (tùy chọn - cần GTKWave)
gtkwave feature_tb.vcd
```

### Kết quả mong đợi trên terminal

```
=================================================
[TB] Bắt đầu kiểm tra Feature Extractor
=================================================
[TB] Gửi 6 gói tin (4 bình thường + 2 SYN)
-------------------------------------------------
[TB] Gửi gói: flags=00, src_ip=0a, dst_port=50, ctrl=00
[SPI] rx_byte = 0x00 tại thời điểm ...
...
[TB] Gửi gói: flags=01, src_ip=32, dst_port=50, ctrl=ff
...
[TB] feat_valid = 1 → Đặc trưng đã sẵn sàng!
=================================================
[TB] KẾT QUẢ TRÍCH XUẤT ĐẶC TRƯNG:
  pkt_count    = 6   (mong đợi: 6)
  syn_ratio    = 85  (mong đợi: ~85, tức 2/6 * 255)
  unique_ips   = 4   (mong đợi: 4)
  unique_ports = 4   (mong đợi: 4)
=================================================
[PASS] pkt_count chính xác!
[PASS] syn_ratio trong khoảng hợp lý (~85)!
[PASS] unique_ips chính xác!
[PASS] unique_ports chính xác!
[TB] AI đã đọc kết quả (feat_ready kéo lên 1)
=================================================
[TB] Kết thúc mô phỏng.
=================================================
```

---

## 6. Tích hợp với các module khác

| Giao diện | Tín hiệu | Kết nối với |
|-----------|----------|-------------|
| SPI vật lý | `sck`, `cs_n`, `mosi` | MCU / Người 2 |
| Đặc trưng đầu ra | `pkt_count`, `syn_ratio`, `unique_ips`, `unique_ports` | AI Accelerator / Người 4 |
| Handshake | `feat_valid`, `feat_ready` | AI Accelerator / Người 4 |

---

## 7. Thông số module

| Tham số | Giá trị mặc định | Mô tả |
|---------|-----------------|-------|
| `WINDOW_SIZE` | 16 | Số gói tối đa trong một cửa sổ thời gian |

> Có thể thay đổi khi instantiate:  
> `feature_extractor #(.WINDOW_SIZE(32)) u_feat (...);`
