# 🛡️ HƯỚNG DẪN CHI TIẾT PHẦN 2.3: TÁCH HEADER, ĐẶC TRƯNG & BỘ LỌC TƯỜNG LỬA
*(Dành riêng cho Người 3 - Đồ án Tường lửa Ethernet Tang Nano 9K - Cập nhật 28/10/2026)*

---

## 📌 1. BỨC TRANH TỔNG THỂ (PHƯƠNG ÁN MỚI)

Trong phương án mới, hệ thống **không còn dùng SPI và ESP32** nữa. Tang Nano 9K đóng vai trò là một **Cầu nối trong suốt (Transparent Bridge) 100 Mbps** đứng giữa 2 cổng mạng Ethernet:
- **Cổng A (Vùng ngoài):** Nhận lưu lượng từ máy Laptop ngoài (chứa cả máy ảo cảm biến IoT và lưu lượng tấn công DoS/Port Scan).
- **Cổng B (Vùng trong):** Nối vào Laptop trong (chạy MQTT Broker Mosquitto cần bảo vệ).

### Vị trí và nhiệm vụ của Người 3:
Người 3 phụ trách phần **"não bộ phân tích và ra luật lọc từng gói"** ở miền clock 27 MHz:
```
                [Dòng byte khung Ethernet từ Phần 4]
                                 │
                                 ▼
                     ┌───────────────────────┐
                     │     pkt_parser.v      │ ── Bóc tách MAC, IPv4, TCP/UDP
                     └───────────┬───────────┘
                                 │ Bản ghi header (hdr_valid)
            ┌────────────────────┴────────────────────┐
            ▼                                         ▼
┌───────────────────────┐                 ┌───────────────────────┐
│     pkt_filter.v      │                 │      feat_core.v      │
│  - Lớp 1: Blocklist   │                 │  - Boyer-Moore:       │
│  - Lớp 2: Token Bucket│                 │    Tìm suspect_ip     │
└───────────┬───────────┘                 │  - confirm_cnt        │
            │                             │  - Thống kê cửa sổ    │
            ▼                             └───────────┬───────────┘
   [verdict_valid/drop]                               │
    Gửi trả Phần 4                        [Giao tiếp Phần 1]
    (Cho qua hay Bỏ)                    (Thanh ghi 0x2000_0000)
```

---

## 📁 2. DANH SÁCH FILE ĐÃ HOÀN THIỆN TRONG THƯ MỤC `src/`

1. [`pkt_parser.v`](file:///e:/Đề%20cương%20đồ%20án/src/pkt_parser.v): Module giải mã dòng byte của khung Ethernet, trích xuất IP nguồn/đích, cổng, cờ TCP (SYN/ACK).
2. [`pkt_filter.v`](file:///e:/Đề%20cương%20đồ%20án/src/pkt_filter.v): Module lọc 2 lớp:
   - Lớp 1: Danh sách chặn 8 ô IP (`bl_ip0`..`bl_ip7`).
   - Lớp 2: Giới hạn SYN bằng thuật toán Xô Token (`token_bucket`).
3. [`feat_core.v`](file:///e:/Đề%20cương%20đồ%20án/src/feat_core.v): Module trích xuất đặc trưng + chạy thuật toán **Boyer–Moore** tự động bắt `suspect_ip` và đếm `confirm_cnt`.
4. [`part3_top.v`](file:///e:/Đề%20cương%20đồ%20án/src/part3_top.v): Module tích hợp cả 3 khối trên, tạo giao diện hoàn chỉnh kết nối với Phần 1 và Phần 4.
5. [`part3_tb.v`](file:///e:/Đề%20cương%20đồ%20án/src/part3_tb.v): Testbench tự động kiểm chứng **5 trường hợp bắt buộc đạt PASS 5/5**.

---

## 💡 3. GIẢI THÍCH KIẾN THỨC CỐT LÕI (CỰC KỲ DỄ HIỂU ĐỂ BẢO VỆ)

### A. Khối `pkt_parser.v` (Bộ tách Header)
- **Vấn đề:** Dữ liệu Ethernet đi vào theo từng byte một (`frm_data[7:0]`) tại mỗi nhịp clock 27 MHz.
- **Cách xử lý:** Dùng một bộ đếm byte `byte_cnt` (bắt đầu đếm khi `frm_sof = 1`):
  - **Byte 12..13:** Kiểm tra EtherType. Nếu là `0x0800` thì đánh dấu `is_ipv4 = 1`. Nếu là `0x0806` (gói ARP), đánh dấu `is_ipv4 = 0` và phát xung `hdr_valid = 1` ngay để bộ lọc cho qua luôn (vì ARP cần để hai máy tính nhìn thấy nhau).
  - **Byte 23:** Đọc `ip_proto` (`6` = TCP, `17` = UDP).
  - **Byte 26..29:** Ghép 4 byte thành IP nguồn `src_ip[31:0]`.
  - **Byte 30..33:** Ghép 4 byte thành IP đích `dst_ip[31:0]`.
  - **Byte 47:** Đọc cờ TCP: bit 1 là `SYN`, bit 4 là `ACK`.
  - Khi đọc xong byte 47, phát xung `hdr_valid = 1` trong đúng 1 chu kỳ clock.

### B. Khối `pkt_filter.v` (Bộ lọc 2 lớp)
1. **Quy tắc an toàn đầu tiên:**
   - Khung không phải IPv4 (`is_ipv4 == 0`, như ARP) $\rightarrow$ **Luôn cho qua** (`verdict_drop = 0`).
   - Khung từ Trong ra Ngoài (`hdr_dir == 1`, ví dụ Broker trả lời cảm biến) $\rightarrow$ **Luôn cho qua**.
2. **Lớp 1 - Danh sách chặn (Blocklist 8 ô IP):**
   - So sánh `src_ip` song song với 8 thanh ghi `bl_ip0`..`bl_ip7`.
   - Nếu `ctrl_block_en == 1` và trùng với ô nào đang có hiệu lực (`bl_valid[i] == 1`) $\rightarrow$ Đánh dấu BỎ GÓI ngay lập tức!
3. **Lớp 2 - Giới hạn SYN (Token Bucket):**
   - Một "xô token" chứa tối đa `syn_limit` token. Cứ mỗi 1 giây (27,000,000 nhịp clock), xô được đổ đầy lại.
   - Khi có gói TCP SYN hợp lệ: nếu trong xô còn token $\rightarrow$ lấy 1 token và cho qua. Nếu xô hết sạch token $\rightarrow$ **Bỏ gói** (`verdict_drop = 1`).
   - **Điểm ăn điểm với thầy cô:** *Gói đã bị Lớp 1 chặn sẽ KHÔNG bị trừ token*, giúp bảo toàn token cho các thiết bị hợp lệ khác!

### C. Khối `feat_core.v` (Boyer-Moore & Xác nhận 2 bước)
- **Tại sao cần Boyer-Moore?**
  Khi bị tấn công SYN Flood, kẻ tấn công bắn hàng nghìn gói SYN mỗi giây. Thay vì tốn bảng băm lớn trong FPGA, ta dùng giải thuật đa số **Boyer–Moore** chỉ cần **1 thanh ghi lưu IP** và **1 bộ đếm**:
  - Gói SYN đầu tiên: chọn IP làm `candidate`, gán `votes = 1`.
  - Gặp gói SYN tiếp: nếu trùng IP $\rightarrow$ `votes++`; nếu khác IP $\rightarrow$ `votes--`.
  - Nếu `votes == 0`: IP mới lập tức trở thành `candidate`.
- **Cơ chế xác nhận 2 bước tránh chặn nhầm:**
  - **Cửa sổ $n$:** Phần cứng tìm ra `candidate` nghi vấn nhất và chốt vào thanh ghi `suspect_ip`.
  - **Cửa sổ $n+1$:** Phần cứng đếm chính xác số lượng gói SYN từ đúng `suspect_ip` này vào thanh ghi `confirm_cnt`.
  - **CPU (Firmware):** Chỉ khi `confirm_cnt > 50%` tổng số gói SYN và AI cũng báo tấn công thì CPU mới ghi IP đó vào Danh sách chặn. Nhờ đó, cảm biến thật **không bao giờ bị chặn nhầm**!

---

## 🚀 4. HƯỚNG DẪN CHẠY MÔ PHỎNG TESTBENCH (PASS 5/5)

### Cách đơn giản nhất: Chạy Online trên EDA Playground (Không cần cài phần mềm)
1. Mở trình duyệt vào trang: **[https://www.edaplayground.com](https://www.edaplayground.com)**
2. Khung bên trái (mục **Tools & Simulators**): Chọn **Icarus Verilog 0.9.7**.
3. Ô code bên trái (**Design**): Dán lần lượt nội dung của 4 file:
   - `pkt_parser.v`
   - `pkt_filter.v`
   - `feat_core.v`
   - `part3_top.v`
4. Ô code bên phải (**Testbench**): Dán nội dung của file:
   - `part3_tb.v`
5. Nhấn nút **Run** (màu xanh lá cây ở góc trên).

### Kết quả trên Terminal sẽ hiện đúng 5/5 [PASS]:
```text
====================================================================
[TESTBENCH PHẦN 3] BẮT ĐẦU KIỂM THỬ 5 TRƯỜNG HỢP THEO ĐỀ CƯƠNG MỚI
====================================================================

[TC 1] Kiểm tra: Gói tin từ IP trong Blocklist (192.168.10.50)
-> [PASS] Đã BỎ gói tin từ IP bị chặn (verdict_drop = 1).

[TC 2] Kiểm tra: Giới hạn SYN Token Bucket (ngưỡng = 2 gói)
-> [PASS] Gói SYN thứ 3 vượt ngưỡng đã bị BỎ (verdict_drop = 1).

[TC 3] Kiểm tra: Gói TCP của kết nối đang có (TCP ACK)
-> [PASS] Gói TCP ACK hợp lệ ĐƯỢC CHO QUA (verdict_drop = 0).

[TC 4] Kiểm tra: Gói tin ARP (để 2 bên tìm thấy nhau)
-> [PASS] Gói ARP ĐƯỢC CHO QUA lập tức (verdict_drop = 0).

[TC 5] Kiểm tra: Gói từ IP bị chặn KHÔNG tiêu hao token của IP khác
-> [PASS] Token vẫn còn nguyên cho IP sạch (verdict_drop = 0).

[BỔ SUNG] Kiểm tra thuật toán Boyer-Moore tìm suspect_ip & confirm_cnt
  -> Kết thúc Cửa sổ 1: suspect_ip = c0a80a63 (Kỳ vọng: C0A80A63)
  -> Kết thúc Cửa sổ 2: confirm_cnt = 2 (Kỳ vọng: 2)

====================================================================
🏆 KẾT QUẢ: TOÀN BỘ CÁC TRƯỜNG HỢP ĐỀU [PASS] 5/5!
Phần 3 (Người 3) hoàn thành xuất sắc yêu cầu của đề cương.
====================================================================
```

---

## 🎓 5. BỘ CÂU HỎI VÀ ĐÁP ÁN KHI THẦY CÔ HỎI THI

**Câu 1: Tại sao trong phương án mới nhóm lại bỏ SPI và ESP32?**
> *Trả lời:* Ban đầu SPI chỉ đóng vai trò nhận dữ liệu thống kê để cảnh báo. Nhưng với yêu cầu làm tường lửa bảo vệ thật sự, thiết bị phải nằm trực tiếp trên đường truyền Ethernet 100 Mbps để có thể "chặn đứng gói xấu ngay trên dây mạng". Dùng 2 cổng RMII giúp Tang Nano trở thành cầu nối trong suốt (Transparent Bridge) không làm thay đổi gói tin và độ trễ cực thấp.

**Câu 2: Khối của em quyết định cho qua hay bỏ gói ở thời điểm nào? Có làm chậm đường truyền không?**
> *Trả lời:* Khối `pkt_filter` ra quyết định `verdict_drop` ngay sau khi khung vừa kết thúc (`frm_eof`), chỉ mất 1 nhịp clock (khoảng 37 ns ở clock 27 MHz). Phần 4 lưu khung trong bộ đệm ~4 KB, ngay khi có `verdict_valid`, nếu cho qua thì phát tiếp sang Cổng B, nếu bỏ thì xóa khỏi bộ đệm. Vì vậy đường truyền 100 Mbps hoàn toàn thông suốt và không bị nghẽn.

**Câu 3: Thuật toán Boyer-Moore trong module của em dùng để làm gì?**
> *Trả lời:* Thuật toán đa số Boyer-Moore giúp phần cứng tìm ra IP nào đang gửi nhiều gói SYN nhất trong một cửa sổ thời gian mà chỉ tốn đúng 1 thanh ghi và 1 bộ đếm (không tốn tài nguyên bảng băm trên Tang Nano 9K). IP này được chốt làm `suspect_ip` để cửa sổ kế tiếp đếm kiểm chứng (`confirm_cnt`), giúp CPU không bao giờ chặn nhầm các cảm biến IoT thật.
