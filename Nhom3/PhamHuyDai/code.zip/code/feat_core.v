// ============================================================================
// Module: feat_core
// Nhiệm vụ:
//   - Trích xuất đặc trưng mạng trong cửa sổ thời gian (1 giây / 27M clock).
//   - Chạy thuật toán đa số Boyer-Moore trên các gói SYN để tìm suspect_ip.
//   - Cửa sổ kế tiếp đếm số gói SYN từ đúng suspect_ip -> xuất confirm_cnt.
//   - Xuất các đặc trưng cũ (win_valid, pkt_cnt, syn_cnt, byte_cnt, bitmap...)
//     để Firmware CPU / AI Accelerator đọc qua wb_feat_regs.
// ============================================================================

module feat_core #(
    parameter CLK_FREQ = 27_000_000   // 27 MHz = 1 giây mỗi cửa sổ
) (
    input  wire        clk,
    input  wire        rst_n,

    // Bản ghi header từ pkt_parser
    input  wire        hdr_valid,
    input  wire        hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    input  wire        is_ipv4,
    input  wire [31:0] src_ip,
    input  wire [31:0] dst_ip,
    input  wire [7:0]  ip_proto,
    input  wire [15:0] ip_len,
    input  wire [15:0] src_port,
    input  wire [15:0] dst_port,
    input  wire [7:0]  tcp_flags,

    // Tùy chọn xung kích hoạt hết cửa sổ từ ngoài (nếu không dùng thì nối 0)
    input  wire        ext_win_tick,

    // Giao tiếp với Phần 1 (wb_feat_regs.v)
    output reg         win_valid,     // Xung báo kết thúc cửa sổ
    output reg  [31:0] pkt_cnt,       // Tổng gói ngoài->trong trong cửa sổ
    output reg  [31:0] syn_cnt,       // Tổng gói SYN trong cửa sổ
    output reg  [31:0] byte_cnt,      // Tổng byte dữ liệu trong cửa sổ
    output reg  [7:0]  unique_ips,    // Popcount bitmap IP nguồn
    output reg  [7:0]  unique_ports,  // Popcount bitmap Port đích
    output reg  [31:0] suspect_ip,    // IP nghi vấn (0x2000_0028)
    output reg  [31:0] confirm_cnt    // Số gói SYN xác nhận từ suspect_ip (0x2000_002C)
);

    // ========================================================================
    // 1. Quản lý cửa sổ thời gian (Window Timer)
    // ========================================================================
    reg [24:0] win_timer;
    wire win_end = ext_win_tick | (win_timer >= CLK_FREQ - 1);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            win_timer <= 25'd0;
        end else begin
            if (win_end) begin
                win_timer <= 25'd0;
            end else begin
                win_timer <= win_timer + 25'd1;
            end
        end
    end

    // ========================================================================
    // 2. Bộ tích lũy thống kê trong cửa sổ hiện tại
    // ========================================================================
    reg [31:0] cur_pkt_cnt;
    reg [31:0] cur_syn_cnt;
    reg [31:0] cur_byte_cnt;
    reg [7:0]  bitmap_ips;
    reg [7:0]  bitmap_ports;
    reg [31:0] cur_confirm_cnt;

    // Biến cho thuật toán Boyer-Moore Majority Vote
    reg [31:0] bm_candidate;
    reg [15:0] bm_votes;

    // Hàm đếm số bit 1 trong bitmap (popcount 8-bit)
    function [3:0] popcount8;
        input [7:0] v;
        begin
            popcount8 = v[0] + v[1] + v[2] + v[3] +
                        v[4] + v[5] + v[6] + v[7];
        end
    endfunction

    wire is_syn = (ip_proto == 8'd6) && (tcp_flags[1] == 1'b1);
    wire valid_inbound = hdr_valid && (!hdr_dir) && is_ipv4;

    // ========================================================================
    // 3. FSM / Tiến trình tính toán đặc trưng
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            win_valid       <= 1'b0;
            pkt_cnt         <= 32'd0;
            syn_cnt         <= 32'd0;
            byte_cnt        <= 32'd0;
            unique_ips      <= 8'd0;
            unique_ports    <= 8'd0;
            suspect_ip      <= 32'd0;
            confirm_cnt     <= 32'd0;

            cur_pkt_cnt     <= 32'd0;
            cur_syn_cnt     <= 32'd0;
            cur_byte_cnt    <= 32'd0;
            bitmap_ips      <= 8'd0;
            bitmap_ports    <= 8'd0;
            cur_confirm_cnt <= 32'd0;

            bm_candidate    <= 32'd0;
            bm_votes        <= 16'd0;
        end else begin
            win_valid <= 1'b0; // Xung 1 nhịp

            // Thu thập gói ngoài -> trong hợp lệ
            if (valid_inbound) begin
                cur_pkt_cnt  <= cur_pkt_cnt + 32'd1;
                cur_byte_cnt <= cur_byte_cnt + {16'd0, ip_len};

                // Cập nhật bitmap
                bitmap_ips   <= bitmap_ips | (8'b1 << src_ip[2:0]);
                bitmap_ports <= bitmap_ports | (8'b1 << dst_port[2:0]);

                // Xử lý gói SYN
                if (is_syn) begin
                    cur_syn_cnt <= cur_syn_cnt + 32'd1;

                    // Xác nhận số SYN từ suspect_ip của cửa sổ trước
                    if (src_ip == suspect_ip) begin
                        cur_confirm_cnt <= cur_confirm_cnt + 32'd1;
                    end

                    // Thuật toán Boyer-Moore tìm IP gửi SYN nhiều nhất cho cửa sổ sau
                    if (bm_votes == 16'd0) begin
                        bm_candidate <= src_ip;
                        bm_votes     <= 16'd1;
                    end else if (src_ip == bm_candidate) begin
                        bm_votes <= bm_votes + 16'd1;
                    end else begin
                        bm_votes <= bm_votes - 16'd1;
                    end
                end
            end

            // Khi kết thúc cửa sổ: chốt dữ liệu và reset
            if (win_end) begin
                win_valid    <= 1'b1;
                pkt_cnt      <= cur_pkt_cnt;
                syn_cnt      <= cur_syn_cnt;
                byte_cnt     <= cur_byte_cnt;
                unique_ips   <= {4'd0, popcount8(bitmap_ips)};
                unique_ports <= {4'd0, popcount8(bitmap_ports)};

                // Kết quả xác nhận cửa sổ vừa xong
                confirm_cnt  <= cur_confirm_cnt;

                // Cập nhật IP nghi vấn cho cửa sổ kế tiếp
                suspect_ip   <= bm_candidate;

                // Reset bộ đếm cho cửa sổ mới
                cur_pkt_cnt     <= 32'd0;
                cur_syn_cnt     <= 32'd0;
                cur_byte_cnt    <= 32'd0;
                bitmap_ips      <= 8'd0;
                bitmap_ports    <= 8'd0;
                cur_confirm_cnt <= 32'd0;
                bm_candidate    <= 32'd0;
                bm_votes        <= 16'd0;
            end
        end
    end

endmodule
