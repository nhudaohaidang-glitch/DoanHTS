# Báo cáo ghép hệ thống – Phần 1 ghép Phần 2 (AI v6), Phần 3, Phần 4

Người ghép: Phần 1. Ngày: 07/11/2026, cập nhật 08/11/2026: Phần 1 viết lại `feat_core` cho đúng đặc tả AI v6 (mục 4–5).
Nguồn: thư mục `Nhom3/` trên repo `DoanHTS`:
- `phan2_ai_v6_ban_giao.zip`
- `code.zip` (Phần 3)
- `phan4_eth(2).zip`

## 1. Kết quả nhanh

| Hạng mục | Kết quả |
|---|---|
| Phần 4 `eth_bridge` | Ghép nguyên bản, không sửa. Bài MAC riêng và bài toàn hệ thống PASS |
| Phần 2 AI v6 | Ghép nguyên bản (SHA256 khớp `FILE_SHA256.json`). POST trên phần cứng khớp **9/9 vector** tham chiếu, AI chạy 86 chu kỳ qua bus |
| Phần 3 | Giữ `pkt_parser`, `pkt_filter` của Phần 3 (sửa 6 chỗ); **`feat_core` do Phần 1 viết lại**, đếm chính xác và đúng đủ đặc tả AI v6 (mục 4–5). Testbench của Phần 3: 5/5 (bản gốc 3/5) |
| Kịch bản 40 giây (`tb_gateway`) | PASS. `check_log.py` PASS: chặn .50 lý do DOS, chặn .51 lý do **SCAN**, không chặn nhầm cảm biến |
| Toàn hệ thống với MAC thật (`tb_system_mac`) | PASS |
| Tài nguyên (**Gowin EDA**) | Logic **58 %**, Register 44 %, CLS 79 %, BSRAM 25/26. Không lỗi. (Yosys: 62 %, nextpnr: ~87 % do chèn LUT đi xuyên) |
| Timing (**Gowin EDA**) | Đạt, 0 vi phạm setup/hold: clk 27 MHz → 39,6 MHz, REF_CLK A 50 MHz → 67,3 MHz, REF_CLK B → 76,0 MHz |

## 2. Phần 4 – Ethernet (`eth_bridge`)

- 5 file trong `rtl/` chép nguyên vào `rtl/part4_eth/`.
- Top của kit gọi thẳng `eth_bridge` khi `SELFTEST = 2`. Thêm tham số `RX_EDGE_A`/`RX_EDGE_B` ở top, mặc định 0, để chọn cạnh lấy mẫu trên kit.
- `ev_crc_err[1:0]` và `ev_overflow[1:0]` nối vào `wb_filter_regs`. Bộ đếm `CNT_CRC_ERR`/`CNT_OVERFLOW` cộng **cả 2 bit** mỗi nhịp, đúng yêu cầu trong README Phần 4.
- `eth_mac_wrap.v` chỉ dùng cho bài thử riêng `tb_eth_mac`.
- Kết quả:
  - `tb_eth_mac` PASS.
  - `tb_system_mac` PASS: bộ đếm đặc trưng thấy 51 gói mỗi giây, chặn đúng .50, cảm biến luôn qua.

**Cần Phần 4 làm thêm:** không có lỗi giao tiếp. Khi nạp kit, kiểm lỗi hold ở REF_CLK cổng A (mục 6) bằng Gowin.

## 3. Phần 2 – AI v6

- `rtl/part2_ai/ai_core_model_v6.v` thay cho bản v2, giữ nguyên tên module `ai_core` và cổng.
- Firmware gọi `ai_v6_prepare_window()` từ `ai_v6_integration.h`. Chữ ký hàm giống bản v2, nên chỉ đổi tên hàm.
- POST chạy 9 vector lấy từ `counter_vectors.json`:
  - `empty_skip`, `sensor_feedback`, `single_legitimate_syn`, `ack52_1000`;
  - `pure_vertical_scan_3`, `pure_vertical_scan_30`;
  - `syn_flood_sensor_407`, `syn_high_sensor_2007`, `vertical_scan_sensor_257`.

  Cả 9 khớp đặc trưng đóng gói, điểm và lớp trên phần cứng. Cửa sổ rỗng không gọi AI, đúng hợp đồng.
- Trong kịch bản 40 giây:
  - AI v6 kết luận **bình thường ở cả 22/22 cửa sổ chỉ có cảm biến**; luật kiểm tra hợp lý của firmware không phải can thiệp lần nào.
  - SYN flood được nhận ra đúng.

**Cần Phần 2 xem thêm:** khi đặc trưng đếm chính xác, cửa sổ **SYN flood giả IP** (128 IP nguồn, 1 cổng, 98 % SYN) được AI v6 xếp **SCAN** thay vì DoS (`$IDS,28..31`). Firmware không chặn nhầm (luật kiểm tra hợp lý đòi ≥ 3 cổng mới tin SCAN, và IP giả không có thủ phạm), nhưng nên bổ sung kiểu lưu lượng này vào dữ liệu huấn luyện.

## 4. Phần 3 – đã sửa gì

Mọi chỗ sửa đánh dấu `[GHEP-P1]` trong `rtl/part3/`. Bản gốc giữ ở `rtl/part3/goc/`, toàn bộ thay đổi ở `docs/phan3_sua_khi_ghep.diff`.

**`pkt_parser.v` và `pkt_filter.v`: giữ bản Phần 3, sửa 6 chỗ**

| # | File | Lỗi / thiếu | Hậu quả nếu không sửa | Đã sửa |
|---|---|---|---|---|
| 1 | `pkt_parser.v` | Ở nhịp `frm_sof`, `byte_cnt <= 0`, mọi vị trí lệch 1 byte | **Mọi gói IPv4 bị coi là không phải IPv4**: không chặn, không đếm gì. `part3_tb` chỉ 3/5 | `byte_cnt <= 1` ở nhịp SOF |
| 2 | `pkt_parser.v` | ICMP và giao thức khác TCP/UDP không có `hdr_valid` | Bộ lọc xét ping bằng kết quả của khung trước | Phát `hdr_valid` sau byte IP đích |
| 3 | `pkt_parser.v` | Chưa biết gói phân mảnh, chưa báo khi nào cổng/cờ TCP hợp lệ | Mảnh IPv4 bị đếm sai đặc trưng; ICMP bị gán cổng 0 | Thêm `hdr_frag` (MF hoặc offset ≠ 0) và `hdr_l4` (TCP/UDP không phân mảnh) |
| 4 | `pkt_filter.v` | `consume_token` dùng trước khi khai báo | Gowin/ModelSim có thể báo lỗi | Khai báo lên trước |
| 5 | `pkt_filter.v` | Xô token khởi tạo 100, chỉ nạp lại mỗi giây; SYN tính cả SYN-ACK | Đổi ngưỡng thì giây đầu sai (`part3_tb` TC2 FAIL); SYN-ACK bị giới hạn nhầm | Nạp lại xô khi lớp 2 tắt hoặc ngưỡng đổi; SYN = `hdr_l4 && (flags & 0x12) == 0x02` |
| 6 | `pkt_filter.v`, `part3_top.v` | `CLK_FREQ` cố định, không truyền xuống | Không mô phỏng rút ngắn được | Thêm tham số `CLK_FREQ` |

**`feat_core.v`: Phần 1 viết lại**

Bản gốc của Phần 3 lệch đặc tả AI v6 ở 6 điểm (mục 5). Sửa từng điểm trên bản gốc gần như viết lại, nên Phần 1 thay bằng `feat_core` của mình (trước đây là khối giả `feat_core_stub.v`, đã đúng đặc tả). `part3_top` thêm cổng `feat_enable`, `prot_net`, `prot_mask` và đủ đầu ra `win_id`, `dst_ip_cnt`, `err_cnt`.

- Đếm IP nguồn, IP đích, cổng đích khác nhau **chính xác** tới 128 giá trị mỗi loại (AI bão hòa ở 127). Bảng nằm trong BSRAM, tìm tuần tự; hàng đợi 8 bản ghi hấp thu khung đến sát nhau.
- Chỉ tính gói ngoài → trong, IPv4, không phân mảnh, IP đích thuộc vùng bảo vệ (`PROT_NET`/`PROT_MASK`).
- SYN mở = `(flags & 0x12) == 0x02`. Cổng chỉ tính cho TCP/UDP.
- `err_cnt` = mảnh IPv4 bị loại + gói mất do hàng đợi đầy.
- Bộ đếm thu hẹp cho đúng nhu cầu 100 Mbps: 20 bit cho số gói, 24 bit cho tổng byte.

## 5. Phần 3 – chỗ lệch đặc tả AI v6 trong `feat_core` gốc (đã xử lý bằng bản viết lại)

| # | Lệch | Hậu quả |
|---|---|---|
| 1 | Đếm IP/cổng khác nhau bằng bitmap 8 ô (tối đa 8) | Quét 251 cổng bị AI nhận là **DoS** (đã thử bằng mô hình tham chiếu của Phần 2 và mô phỏng) |
| 2 | Không lọc theo máy cần bảo vệ | Đếm cả broadcast/multicast của laptop |
| 3 | SYN tính cả SYN-ACK | Sai `syn_ratio` |
| 4 | Không bỏ gói phân mảnh | Sai đặc trưng khi có mảnh IPv4 |
| 5 | Thiếu số IP đích khác nhau, số cửa sổ, số gói bị loại | Đặc trưng thứ 5 của AI phải đoán |
| 6 | Gói đến đúng nhịp hết cửa sổ bị mất | Ảnh hưởng nhỏ |

Bản Phần 3 gửi ngày 08/11 chỉ sửa điểm 1, bằng bitmap 256 bit trong flip-flop kèm popcount: sai cú pháp (`popcount256(...)[7:0]`), và tốn ~2 650 ô logic + 16 bộ nhân, đưa cả hệ thống lên ~124 %, không đặt được.

So sánh các cách (cả hệ thống, Yosys, LUT + ALU):

| `feat_core` | Ô logic | Đúng đặc tả | Quét 251 cổng |
|---|---|---|---|
| Phần 3 gốc (bitmap 8 ô) | ~4 900 (57 %) | Không | DoS (sai) |
| Bitmap 256 trong BSRAM, chỉ số theo 8 bit thấp (thử) | ~5 280 (61 %) | Không (hash, thiếu 2–5) | SCAN |
| **Phần 1 viết lại (đếm chính xác) – bản ghép hiện tại** | **~5 400 (62 %)** | **Có** | **SCAN** |
| Phần 3 ngày 08/11 (bitmap 256 flip-flop + popcount) | ~10 700 (124 %, số sau đặt dây) | Không | SCAN, nhưng không nạp được |

## 6. Tài nguyên và timing của bản ghép

### Gowin EDA V1.9.12.04 (số chính thức, build ngày 08/11/2026)

File nạp: `board/prebuilt/tangnano9k_ghep.fs` (build bằng Gowin).

| Tài nguyên | Dùng | Tỉ lệ |
|---|---|---|
| Logic (LUT 3 474 + ALU 1 204 + RAM16 47) | 4 960 / 8 640 | **58 %** |
| Register | 2 894 / 6 693 | 44 % |
| CLS | 3 382 / 4 320 | 79 % |
| BSRAM | 25 / 26 (8 SP + 17 SDPB) | **97 %** |
| DSP | 1 / 10 | 10 % |
| Chân I/O | 26 / 71 | 37 % |

| Clock | Cần | Fmax | Setup / hold |
|---|---|---|---|
| clk_27m | 27 MHz | 39,6 MHz | 0 vi phạm / 0 vi phạm |
| a_ref_clk | 50 MHz | 67,3 MHz | 0 / 0 |
| b_ref_clk | 50 MHz | 76,0 MHz | 0 / 0 |

- **Không ERROR.** 69 cảnh báo, đều vô hại:
  - 32 × EX0211: cổng `pcpi_insn` của PicoRV32 không nối, vì đã tắt PCPI;
  - các cảnh báo `full_case`/`parallel_case` và cắt độ rộng nằm trong `picorv32.v`;
  - PR1014: `b_ref_clk` đi bằng dây thường do chân 63 không phải chân clock. Phần 4 đã biết, và timing vẫn đạt.
- **BSRAM gần hết (25/26):** Gowin đặt cả các bảng đếm của `feat_core` và FIFO vào BSRAM. Muốn thêm bộ nhớ sau này phải dùng RAM16 (còn nhiều), hoặc thu nhỏ bảng.

### Yosys + nextpnr (để so sánh)

Bản đầy đủ (`SELFTEST = 2`, `REF_METER = 0`), chip GW1NR-LV9QN88PC6/I5. Số đo bằng công cụ mã nguồn mở, chỉ để so sánh.

| Tài nguyên | Yosys (sau tổng hợp) | nextpnr (sau đặt dây) |
|---|---|---|
| LUT4 | 4 177 | 6 163 (71 %) |
| ALU | 1 219 | 1 370 |
| Ô logic LUT + ALU | **5 396 / 8 640 (62 %)** | 7 533 (87 %) |
| DFF | 3 229 | 3 691 / 6 480 (57 %) |
| BSRAM | 17 / 26 | 19 / 26 |
| RAM16SDP4 | 77 | 77 / 270 |

nextpnr thêm ~2 000 LUT "đi xuyên" để ghép flip-flop vào ô, nên số sau đặt dây cao hơn; Gowin EDA thường ghép gọn hơn. **Cần build bằng Gowin để có số chính thức.**

**Từng khối** (Yosys, tổng hợp riêng, LUT + ALU):

| Khối | Ô logic | BSRAM |
|---|---|---|
| Phần 1 (CPU, bus, thanh ghi, RAM firmware) | ~2 100 (ước tính, phần còn lại) | 8 |
| Phần 3 (parser + filter của Phần 3, `feat_core` của Phần 1) | 1 941 | 1 (+25 RAM16) |
| Phần 4 | 811 | 8 |
| AI v6 | 573 | 0 |

**Timing** (nextpnr, cả 3 seed 1–3 đều đạt, không lỗi hold):

| Clock | Cần | Đạt (seed 1) |
|---|---|---|
| clk | 27 MHz | 57 MHz |
| REF_CLK A | 50 MHz | 177 MHz |
| REF_CLK B | 50 MHz | 155 MHz |

Ở vài bản build trước, nextpnr từng báo lỗi hold ở `a_ref_clk` (REF_CLK cổng A, chân 35, không đi được bằng đường clock riêng), lúc có lúc không. Kiểm lại bằng Gowin (`gw_sh board\gowin_build.tcl`).

## 7. Phần 1 đã đổi gì để ghép

- `gateway_soc.v`: gọi `part3_top`; nối `feat_enable`, `PROT_NET/MASK` và đủ 6 đặc trưng + `win_id`, `err_cnt` vào `wb_feat_regs`.
- `rtl/part3/feat_core.v`: viết lại (mục 4).
- `wb_filter_regs.v`:
  - 3 bộ đếm gói đọc thẳng từ `pkt_filter`;
  - ghi `CNT_FWD` sinh xung `clear_counters`;
  - bộ đếm CRC/tràn cộng 2 bit của Phần 4.
- `tangnano9k_top.v`: gọi `eth_bridge`, thêm `RX_EDGE_A/B`.
- Firmware:
  - dùng AI v6;
  - POST 9 vector;
  - sửa `start.S`: không cho ld đổi lệnh nạp con trỏ ngăn xếp sang dạng tương đối theo gp (lỗi link khi firmware lớn lên).
- Testbench và script ModelSim cập nhật tên tín hiệu mới.

## 8. Kiểm thử

| Bài | Kết quả |
|---|---|
| `part3_tb.v` (của Phần 3, chỉ đổi tên cổng đặc trưng) | Bản gốc 3/5 → sau khi sửa 5/5 |
| `tb_eth_mac` | PASS |
| `tb_system_mac` | PASS |
| `tb_gateway` (40 giây) | PASS. `check_log.py` PASS |
| `tb_board` (top của kit, `firmware.hex`) | PASS |
| `tb_oled` (đọc lại màn hình) | PASS |

Số liệu `tb_gateway`:
- khung của cảm biến: qua 266, bỏ 0; khung trả lời của broker và ARP: qua 227, bỏ 0;
- khung tấn công bị bỏ: SYN flood 1 541, quét cổng 713, SYN giả IP 603 (do lớp giới hạn SYN).


