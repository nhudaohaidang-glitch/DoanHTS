# Báo cáo ghép hệ thống – Phần 1 ghép Phần 2 (AI v6), Phần 3, Phần 4

Người ghép: Phần 1. Ngày: 07/11/2026.
Nguồn: thư mục `Nhom3/` trên repo `DoanHTS`:
- `phan2_ai_v6_ban_giao.zip`
- `code.zip` (Phần 3)
- `phan4_eth(2).zip`

## 1. Kết quả nhanh

| Hạng mục | Kết quả |
|---|---|
| Phần 4 `eth_bridge` | Ghép nguyên bản, không sửa. Bài MAC riêng và bài toàn hệ thống PASS |
| Phần 2 AI v6 | Ghép nguyên bản (SHA256 khớp `FILE_SHA256.json`). POST trên phần cứng khớp **9/9 vector** tham chiếu, AI chạy 86 chu kỳ qua bus |
| Phần 3 | Phải sửa **4 lỗi** mới chạy được (mục 4). Sau khi sửa, testbench của chính Phần 3 đạt 5/5 (bản gốc: 3/5) |
| Kịch bản 40 giây (`tb_gateway`) | PASS, nhưng `check_log.py` báo **1 lỗi**: máy quét cổng .51 bị chặn với lý do DOS thay vì SCAN, do Phần 3 đếm số cổng tối đa 8 (mục 5) |
| Toàn hệ thống với MAC thật (`tb_system_mac`) | PASS |
| Tài nguyên (Yosys + nextpnr) | Ô logic (LUT 5 418 + ALU 1 262 + RAM16 52) ≈ 78 %, DFF 3 148 (49 %), BSRAM 16/26. Đặt và đi dây xong. Bản trước dùng MAC thử và khối giả Phần 3: ~92 %, không đặt được |
| Timing (nextpnr) | Đạt: clk 27 MHz → 60 MHz, REF_CLK A → 110 MHz, REF_CLK B → 151 MHz. Có 1 lần build báo lỗi hold ở REF_CLK cổng A (mục 6), cần kiểm lại bằng Gowin |

## 2. Phần 4 – Ethernet (`eth_bridge`)

- 5 file trong `rtl/` chép nguyên vào `rtl/part4_eth/`.
- Top của kit gọi thẳng `eth_bridge` khi `SELFTEST = 2`. Thêm tham số `RX_EDGE_A`/`RX_EDGE_B` ở top, mặc định 0, để chọn cạnh lấy mẫu trên kit.
- `ev_crc_err[1:0]` và `ev_overflow[1:0]` nối vào `wb_filter_regs`. Bộ đếm `CNT_CRC_ERR`/`CNT_OVERFLOW` cộng **cả 2 bit** mỗi nhịp, đúng yêu cầu trong README Phần 4.
- `eth_mac_wrap.v` chỉ dùng cho bài thử riêng `tb_eth_mac`.
- Kết quả:
  - `tb_eth_mac` PASS.
  - `tb_system_mac` PASS: bộ đếm đặc trưng thấy 51 gói mỗi giây, chặn đúng .50, cảm biến luôn qua.

**Cần Phần 4 làm thêm:** không có lỗi giao tiếp. Khi nạp kit, kiểm lỗi hold ở REF_CLK cổng A (mục 6) bằng Gowin.

## 3. Phần 2 – AI v6

- `rtl/part2_ai/ai_core_model_v6.v` thay cho bản v2, giữ nguyên tên module `ai_core` và cổng.
- Firmware gọi `ai_v6_prepare_window()` từ `ai_v6_integration.h`. Chữ ký hàm giống bản v2, nên chỉ đổi tên hàm.
- POST chạy 9 vector lấy từ `counter_vectors.json`:
  - `empty_skip`, `sensor_feedback`, `single_legitimate_syn`, `ack52_1000`;
  - `pure_vertical_scan_3`, `pure_vertical_scan_30`;
  - `syn_flood_sensor_407`, `syn_high_sensor_2007`, `vertical_scan_sensor_257`.

  Cả 9 khớp đặc trưng đóng gói, điểm và lớp trên phần cứng. Cửa sổ rỗng không gọi AI, đúng hợp đồng.
- Trong kịch bản 40 giây:
  - AI v6 kết luận **bình thường ở cả 22/22 cửa sổ chỉ có cảm biến**; luật kiểm tra hợp lý của firmware không phải can thiệp lần nào.
  - SYN flood được nhận ra đúng.

**Cần Phần 2 làm thêm:** không có lỗi phía AI. Xem mục 5 về đặc trưng đầu vào: Phần 3 chưa cung cấp đúng định nghĩa trong `spec/FEATURES_V0.md`.

## 4. Phần 3 – các lỗi đã sửa để ghép được

Tất cả chỗ sửa đều đánh dấu `[GHEP-P1]` trong `rtl/part3/`. Bản gốc giữ ở `rtl/part3/goc/`, toàn bộ thay đổi ở `docs/phan3_sua_khi_ghep.diff`. Phần 3 nên đưa các sửa này vào bản của mình.

| # | File | Lỗi | Hậu quả nếu không sửa | Đã sửa |
|---|---|---|---|---|
| 1 | `pkt_parser.v` | Ở nhịp `frm_sof`, `byte_cnt <= 0`, nên byte thứ 2 cũng được coi là byte 0. Mọi vị trí lệch 1 byte | EtherType đọc sai nên **mọi gói IPv4 bị coi là không phải IPv4**: không chặn, không đếm gì. Chạy `part3_tb.v` bằng Icarus chỉ đạt 3/5 | `byte_cnt <= 1` ở nhịp SOF |
| 2 | `pkt_parser.v` | Gói IPv4 không phải TCP/UDP (ICMP – ping) không có `hdr_valid` | `pkt_filter` ra verdict bằng kết quả của **khung trước**: ping có thể bị bỏ nhầm ngay sau gói của IP bị chặn. `feat_core` cũng không đếm gói ICMP | Phát `hdr_valid` sau byte IP đích khi giao thức khác 6/17 |
| 3 | `pkt_filter.v` | `consume_token` dùng trước khi khai báo | Yosys/Gowin có thể báo lỗi hoặc tự tạo dây 1 bit | Khai báo lên trước |
| 4 | `pkt_filter.v` | Xô token khởi tạo 100 và chỉ nạp lại `syn_limit` mỗi giây | Đổi ngưỡng hoặc bật lớp 2 thì giây đầu dùng sai ngưỡng. `part3_tb` TC2 (ngưỡng 2) FAIL | Nạp lại xô khi lớp 2 đang tắt hoặc khi `syn_limit` đổi |
| – | `pkt_filter.v`, `part3_top.v` | `CLK_FREQ` cố định trong `pkt_filter`; `part3_top` không truyền tham số xuống `feat_core` | Không mô phỏng rút ngắn được | Thêm tham số `CLK_FREQ`, truyền xuống cả 2 khối |

## 5. Phần 3 – chỗ chưa đúng hợp đồng (chưa sửa, cần Phần 3 làm)

AI v6 yêu cầu đặc trưng theo `spec/FEATURES_V0.md` của Phần 2. `feat_core.v` hiện lệch ở các điểm sau:

1. **Đếm IP nguồn và cổng đích khác nhau bằng bitmap 8 ô** (theo 3 bit thấp), nên giá trị tối đa là 8. Spec yêu cầu đếm chính xác tới ít nhất 128.

   Hậu quả: thử bằng mô hình tham chiếu của Phần 2, cùng một cửa sổ quét 251 cổng:

   | Số cổng đưa vào AI | Kết quả AI |
   |---|---|
   | 251 (đếm đúng) | SCAN |
   | 8 (bitmap) | DoS |

   Mô phỏng kịch bản 40 giây cũng ra đúng như vậy: `$BLK,192.168.10.51,DOS`. IP vẫn bị chặn, nhưng sai loại tấn công. Ngoài ra, các cổng trùng 3 bit thấp (1883 và 8883) bị đếm là một.

   Đề nghị: bảng đếm chính xác trong BSRAM, tìm tuần tự (như khối giả `rtl/stubs/feat_core_stub.v` của Phần 1), hoặc ít nhất bitmap 128 ô kèm bộ đếm tăng mỗi khi bật một bit mới.
2. **Không lọc theo máy cần bảo vệ.** Spec chỉ đếm gói IPv4 đi vào máy /32 cần bảo vệ (broker). Bản hiện tại đếm mọi gói ngoài → trong, kể cả broadcast/multicast của laptop. Phần 1 đã có sẵn thanh ghi `PROT_NET`/`PROT_MASK` (`0x2000_0030/34`); `feat_core` chỉ cần thêm 2 cổng vào.
3. **SYN đếm cả SYN-ACK.** Spec dùng `(tcp_flags & 0x12) == 0x02`, bản hiện tại chỉ xét bit SYN. Lỗi này có ở cả `feat_core` và xô token của `pkt_filter`.
4. **Không bỏ gói phân mảnh** khỏi thống kê; `pkt_parser` không có `hdr_frag`. Gói phân mảnh vẫn phải qua danh sách chặn.
5. **Thiếu đầu ra:**
   - số IP đích khác nhau (đặc trưng thứ 5 của AI);
   - số thứ tự cửa sổ;
   - số gói bị loại.

   Phần 1 đang tạm thay: IP đích = 1 khi có gói (đúng với lab chỉ bảo vệ 1 máy), số cửa sổ do Phần 1 tự đếm, số gói loại = 0.
6. Gói đến đúng nhịp hết cửa sổ bị mất, vì lệnh xóa ghi đè lệnh cộng. Ảnh hưởng nhỏ.

## 6. Tài nguyên và timing của bản ghép

Bản đầy đủ (`SELFTEST = 2`, `REF_METER = 0`), đo bằng Yosys 0.70 + nextpnr-himbaechel trên chip GW1NR-LV9QN88PC6/I5, sau mọi chỗ sửa ở mục 4. File nạp: `board/prebuilt/tangnano9k_ghep.fs`.

| Tài nguyên | Dùng | Tỉ lệ |
|---|---|---|
| Ô logic (LUT4 5 418 + ALU 1 262 + RAM16SDP4 52) | ~6 730 / 8 640 | **~78 %** |
| DFF | 3 148 / 6 480 | 49 % |
| BSRAM | 16 / 26 | 62 % |
| MULT9X9 | 1 / 40 | 2 % |

**Từng khối** (Yosys, tổng hợp riêng, LUT + ALU):

| Khối | Ô logic | BSRAM |
|---|---|---|
| Phần 1 (CPU, bus, thanh ghi, RAM firmware) | ~3 800 (ước tính, phần còn lại) | 8 |
| Phần 3 | 1 492 | 0 |
| Phần 4 | 811 | 8 |
| AI v6 | 573 | 0 |

**Timing:** cả 3 clock đều đạt.

| Clock | Cần | Đạt |
|---|---|---|
| clk | 27 MHz | 60 MHz |
| REF_CLK A | 50 MHz | 110 MHz |
| REF_CLK B | 50 MHz | 151 MHz |

Ở 1 lần build trước, nextpnr báo lỗi hold ở `a_ref_clk`, do không đi được REF_CLK cổng A (chân 35) bằng đường clock riêng. Lỗi nằm sát ranh giới nên lúc có lúc không, **cần kiểm lại bằng Gowin** (`gw_sh board\gowin_build.tcl`).

**Lưu ý khi Phần 3 sửa đếm chính xác (mục 5.1):**
- Bản mẫu đếm chính xác bằng BSRAM (`rtl/stubs/feat_core_stub.v`) thêm khoảng 520 ô logic và 3 BSRAM, đưa tổng lên khoảng 84 %.
- Bitmap 256 bit trong flip-flop kèm popcount (đã thử ngày 08/11) tốn khoảng 2 650 ô và 16 bộ nhân, đưa tổng lên khoảng 124 %, không đặt được.

## 7. Phần 1 đã đổi gì để ghép

- `gateway_soc.v`: gọi `part3_top`, thêm phần tạm thay cho các đầu ra Phần 3 còn thiếu (mục 5.5).
- `wb_filter_regs.v`:
  - 3 bộ đếm gói đọc thẳng từ `pkt_filter`;
  - ghi `CNT_FWD` sinh xung `clear_counters`;
  - bộ đếm CRC/tràn cộng 2 bit của Phần 4.
- `tangnano9k_top.v`: gọi `eth_bridge`, thêm `RX_EDGE_A/B`.
- Firmware:
  - dùng AI v6;
  - POST 9 vector;
  - sửa `start.S`: không cho ld đổi lệnh nạp con trỏ ngăn xếp sang dạng tương đối theo gp (lỗi link khi firmware lớn lên).
- Testbench và script ModelSim cập nhật tên tín hiệu mới.

## 8. Kiểm thử

| Bài | Kết quả |
|---|---|
| `part3_tb.v` (của Phần 3) | Bản gốc 3/5 → sau khi sửa 5/5 |
| `tb_eth_mac` | PASS |
| `tb_system_mac` | PASS |
| `tb_gateway` (40 giây) | PASS. `check_log.py`: 1 lỗi (quét cổng ra DOS, mục 5.1) |
| `tb_board` (top của kit, `firmware.hex`) | PASS |
| `tb_oled` (đọc lại màn hình) | PASS |

Số liệu `tb_gateway`:
- khung của cảm biến: qua 266, bỏ 0; khung trả lời của broker và ARP: qua 227, bỏ 0;
- khung tấn công bị bỏ: SYN flood 1 541, quét cổng 712, SYN giả IP 603 (do lớp giới hạn SYN).


