/* ai_vectors.h - vector tham chieu AI v6 (Phan 2, counter_vectors.json).
 * Firmware dung luc khoi dong: kiem ai_v6_prepare_window() va AI qua bus.
 * Tu sinh boi tools/gen_tables.py - khong sua tay. */
#ifndef AI_VECTORS_H
#define AI_VECTORS_H
#include <stdint.h>
typedef struct { uint32_t cnt[6]; uint32_t valid; uint32_t feat_lo, feat_hi; int16_t score[3]; uint8_t cls; } ai_vec_t;
#define AI_VEC_NO_AI 255u   /* cua so rong: khong goi AI */
#define AI_VEC_N 9
static const ai_vec_t ai_vec[AI_VEC_N] = {
    {{0u, 0u, 0u, 0u, 0u, 0u}, 0, 0x00000000u, 0x0000u, {0, 0, 0}, 255},
    {{7u, 427u, 1u, 1u, 1u, 1u}, 1, 0x01121E00u, 0x0101u, {719, -479, -193}, 0},
    {{1u, 40u, 1u, 1u, 1u, 1u}, 1, 0x017F1400u, 0x0101u, {299, -81, -4}, 0},
    {{1000u, 52000u, 0u, 1u, 1u, 1u}, 1, 0x01001A7Du, 0x0101u, {725, 323, -1134}, 0},
    {{3u, 120u, 3u, 1u, 1u, 3u}, 1, 0x017F1400u, 0x0301u, {136, -189, 304}, 2},
    {{30u, 1200u, 30u, 1u, 1u, 30u}, 1, 0x017F1403u, 0x1E01u, {-1715, -1463, 3875}, 2},
    {{407u, 16427u, 401u, 2u, 1u, 1u}, 1, 0x027D1432u, 0x0101u, {606, 1002, -1700}, 1},
    {{2007u, 80427u, 2001u, 2u, 1u, 1u}, 1, 0x027E147Fu, 0x0101u, {1418, 1721, -3582}, 1},
    {{257u, 11427u, 251u, 2u, 1u, 251u}, 1, 0x027C1620u, 0x7F01u, {-8442, -1998, 12155}, 2},
};
#endif
