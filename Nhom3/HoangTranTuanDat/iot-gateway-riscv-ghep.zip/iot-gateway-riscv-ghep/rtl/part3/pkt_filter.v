// ============================================================================
// Module: pkt_filter
// Nhiệm vụ:
//   - Lớp 1: So sánh IP nguồn với 8 ô trong danh sách chặn (Blocklist).
//   - Lớp 2: Giới hạn gói SYN bằng cơ chế Xô Token (Token Bucket).
//   - Ra quyết định verdict_valid, verdict_drop cho Phần 4 trước/ngay sau frm_eof.
//   - Cập nhật các bộ đếm: cnt_fwd, cnt_drop_bl, cnt_drop_syn cho Phần 1 đọc.
// ============================================================================

module pkt_filter #(
    parameter CLK_FREQ = 27_000_000   // [GHEP-P1] them tham so (mo phong rut ngan giay)
) (
    input  wire        clk,
    input  wire        rst_n,

    // Giao tiếp với pkt_parser
    input  wire        hdr_valid,
    input  wire        hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    input  wire        is_ipv4,
    input  wire [31:0] src_ip,
    input  wire [31:0] dst_ip,
    input  wire [7:0]  ip_proto,
    input  wire [15:0] ip_len,
    input  wire [15:0] src_port,
    input  wire [15:0] dst_port,
    input  wire [7:0]  tcp_flags,

    // Tín hiệu kết thúc khung từ Phần 4
    input  wire        frm_eof,

    // Thanh ghi cấu hình từ Phần 1 (0x5000_0000)
    input  wire        ctrl_block_en,     // CTRL bit 0
    input  wire        ctrl_syn_limit_en, // CTRL bit 1
    input  wire [15:0] syn_limit,         // Số gói SYN tối đa/giây
    input  wire [7:0]  bl_valid,          // Bit i = 1: ô i hợp lệ
    input  wire [31:0] bl_ip0,
    input  wire [31:0] bl_ip1,
    input  wire [31:0] bl_ip2,
    input  wire [31:0] bl_ip3,
    input  wire [31:0] bl_ip4,
    input  wire [31:0] bl_ip5,
    input  wire [31:0] bl_ip6,
    input  wire [31:0] bl_ip7,
    input  wire        clear_counters,    // Xung xóa bộ đếm khi ghi CNT_FWD

    // Quyết định gửi sang Phần 4 (MAC/Bộ đệm khung)
    output reg         verdict_valid,
    output reg         verdict_drop,

    // Các bộ đếm gửi sang Phần 1 để đọc qua bus Wishbone
    output reg  [31:0] cnt_fwd,
    output reg  [31:0] cnt_drop_bl,
    output reg  [31:0] cnt_drop_syn
);

    // ========================================================================
    // 1. Quản lý Xô Token (Token Bucket) cho Giới hạn SYN (Lớp 2)
    // Hệ thống chạy clock 27 MHz -> 27,000,000 chu kỳ = 1 giây
    // ========================================================================
    reg [24:0] sec_timer;
    reg [15:0] token_bucket;
    reg [15:0] lim_q;           // [GHEP-P1] nguong SYN cua nhip truoc
    reg        consume_token;   // [GHEP-P1] khai bao truoc khi dung (goc khai bao o duoi, Yosys/Gowin bao loi)

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sec_timer    <= 25'd0;
            token_bucket <= 16'd100; // Khởi tạo mặc định
            lim_q        <= 16'd0;   // [GHEP-P1]
        end else begin
            lim_q <= syn_limit;      // [GHEP-P1] nho nguong cu de biet khi CPU doi nguong
            if (sec_timer >= CLK_FREQ - 1) begin
                sec_timer    <= 25'd0;
                token_bucket <= syn_limit; // Mỗi giây làm đầy lại xô token
            end else if (!ctrl_syn_limit_en || syn_limit != lim_q) begin
                // [GHEP-P1] lop 2 dang tat hoac nguong vua doi: nap lai xo theo syn_limit hien tai,
                // de nguong moi co hieu luc ngay (goc: xo = 100 tu luc reset toi het giay dau tien)
                sec_timer    <= sec_timer + 25'd1;
                token_bucket <= syn_limit;
            end else begin
                sec_timer <= sec_timer + 25'd1;

                // Nếu có gói SYN tiêu thụ token
                if (consume_token && (token_bucket > 16'd0)) begin
                    token_bucket <= token_bucket - 16'd1;
                end
            end
        end
    end

    // ========================================================================
    // 2. Logic kiểm tra gói khi nhận được hdr_valid
    // ========================================================================
    reg current_drop_bl;
    reg current_drop_syn;
    reg current_pass;

    // So sánh IP nguồn với 8 ô Blocklist
    wire match_bl = ctrl_block_en && (
        (bl_valid[0] && (src_ip == bl_ip0)) ||
        (bl_valid[1] && (src_ip == bl_ip1)) ||
        (bl_valid[2] && (src_ip == bl_ip2)) ||
        (bl_valid[3] && (src_ip == bl_ip3)) ||
        (bl_valid[4] && (src_ip == bl_ip4)) ||
        (bl_valid[5] && (src_ip == bl_ip5)) ||
        (bl_valid[6] && (src_ip == bl_ip6)) ||
        (bl_valid[7] && (src_ip == bl_ip7))
    );

    wire is_syn_pkt = (ip_proto == 8'd6) && (tcp_flags[1] == 1'b1); // TCP SYN flag

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_drop_bl  <= 1'b0;
            current_drop_syn <= 1'b0;
            current_pass     <= 1'b1;
            consume_token    <= 1'b0;
        end else begin
            consume_token <= 1'b0; // Mặc định 0

            if (hdr_valid) begin
                // Quy tắc 1: Khung không phải IPv4 hoặc khung từ trong ra ngoài (hdr_dir == 1) -> Luôn cho qua!
                if (!is_ipv4 || (hdr_dir == 1'b1)) begin
                    current_drop_bl  <= 1'b0;
                    current_drop_syn <= 1'b0;
                    current_pass     <= 1'b1;
                end else begin
                    // Chiều ngoài -> trong và là IPv4:
                    // Lớp 1: Xét Danh sách chặn
                    if (match_bl) begin
                        current_drop_bl  <= 1'b1;
                        current_drop_syn <= 1'b0;
                        current_pass     <= 1'b0;
                        // Gói bị bỏ bởi Lớp 1 KHÔNG trừ token của gói khác!
                    end else begin
                        current_drop_bl <= 1'b0;
                        // Lớp 2: Xét Giới hạn SYN
                        if (ctrl_syn_limit_en && is_syn_pkt) begin
                            if (token_bucket > 16'd0) begin
                                consume_token    <= 1'b1; // Còn token -> lấy 1 token, cho qua
                                current_drop_syn <= 1'b0;
                                current_pass     <= 1'b1;
                            end else begin
                                current_drop_syn <= 1'b1; // Hết token -> Bỏ gói!
                                current_pass     <= 1'b0;
                            end
                        end else begin
                            // Gói TCP thường (không phải SYN), UDP,... hợp lệ -> Cho qua
                            current_drop_syn <= 1'b0;
                            current_pass     <= 1'b1;
                        end
                    end
                end
            end
        end
    end

    // ========================================================================
    // 3. Xuất quyết định (verdict) tại frm_eof và cập nhật các bộ đếm
    // ========================================================================
    reg eof_d1;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            eof_d1        <= 1'b0;
            verdict_valid <= 1'b0;
            verdict_drop  <= 1'b0;
            cnt_fwd       <= 32'd0;
            cnt_drop_bl   <= 32'd0;
            cnt_drop_syn  <= 32'd0;
        end else begin
            eof_d1 <= frm_eof;

            // Xóa bộ đếm khi có lệnh clear từ CPU
            if (clear_counters) begin
                cnt_fwd      <= 32'd0;
                cnt_drop_bl  <= 32'd0;
                cnt_drop_syn <= 32'd0;
            end

            // Xuất verdict ngay nhịp sau frm_eof (đảm bảo trước 4 nhịp)
            if (frm_eof) begin
                verdict_valid <= 1'b1;
                if (current_drop_bl) begin
                    verdict_drop <= 1'b1;
                    cnt_drop_bl  <= cnt_drop_bl + 32'd1;
                end else if (current_drop_syn) begin
                    verdict_drop <= 1'b1;
                    cnt_drop_syn <= cnt_drop_syn + 32'd1;
                end else begin
                    verdict_drop <= 1'b0;
                    if (is_ipv4 && (hdr_dir == 1'b0)) begin
                        cnt_fwd <= cnt_fwd + 32'd1;
                    end
                end
            end else begin
                verdict_valid <= 1'b0;
            end
        end
    end

endmodule
