// ============================================================================
// Module: part3_top
// Nhóm 03 - Người 3: Tách header, đặc trưng, tìm IP nghi vấn, bộ lọc
// Bao gồm:
//   1. pkt_parser: giải mã Ethernet, IPv4, TCP/UDP
//   2. pkt_filter: Lớp 1 (Blocklist) + Lớp 2 (SYN Token Bucket)
//   3. feat_core: trích xuất đặc trưng + Boyer-Moore tìm suspect_ip
// ============================================================================

module part3_top #(
    parameter CLK_FREQ = 27_000_000   // [GHEP-P1] them tham so, truyen xuong feat_core va pkt_filter
) (
    input  wire        clk,            // Clock hệ thống 27 MHz
    input  wire        rst_n,          // Reset tích cực thấp

    // --- Giao tiếp nhận khung từ Phần 4 (MAC/FIFO) ---
    input  wire        frm_valid,
    input  wire [7:0]  frm_data,
    input  wire        frm_sof,
    input  wire        frm_eof,
    input  wire        frm_dir,
    input  wire        frm_crc_ok,

    // --- Giao tiếp quyết định gửi sang Phần 4 ---
    output wire        verdict_valid,
    output wire        verdict_drop,

    // --- Giao tiếp thanh ghi Bộ lọc với Phần 1 (0x5000_0000) ---
    input  wire        ctrl_block_en,
    input  wire        ctrl_syn_limit_en,
    input  wire [15:0] syn_limit,
    input  wire [7:0]  bl_valid,
    input  wire [31:0] bl_ip0,
    input  wire [31:0] bl_ip1,
    input  wire [31:0] bl_ip2,
    input  wire [31:0] bl_ip3,
    input  wire [31:0] bl_ip4,
    input  wire [31:0] bl_ip5,
    input  wire [31:0] bl_ip6,
    input  wire [31:0] bl_ip7,
    input  wire        clear_counters,
    output wire [31:0] cnt_fwd,
    output wire [31:0] cnt_drop_bl,
    output wire [31:0] cnt_drop_syn,

    // --- Giao tiếp thanh ghi Đặc trưng với Phần 1 (wb_feat_regs.v) ---
    input  wire        ext_win_tick,
    output wire        win_valid,
    output wire [31:0] pkt_cnt,
    output wire [31:0] syn_cnt,
    output wire [31:0] byte_cnt,
    output wire [7:0]  unique_ips,
    output wire [7:0]  unique_ports,
    output wire [31:0] suspect_ip,     // 0x2000_0028
    output wire [31:0] confirm_cnt     // 0x2000_002C
);

    // Tín hiệu nội bộ Phần 3 (kết nối pkt_parser sang pkt_filter và feat_core)
    wire        hdr_valid;
    wire        hdr_dir;
    wire        is_ipv4;
    wire [31:0] src_ip;
    wire [31:0] dst_ip;
    wire [7:0]  ip_proto;
    wire [15:0] ip_len;
    wire [15:0] src_port;
    wire [15:0] dst_port;
    wire [7:0]  tcp_flags;

    // 1. Khối Tách Header
    pkt_parser u_parser (
        .clk        (clk),
        .rst_n      (rst_n),
        .frm_valid  (frm_valid),
        .frm_data   (frm_data),
        .frm_sof    (frm_sof),
        .frm_eof    (frm_eof),
        .frm_dir    (frm_dir),
        .frm_crc_ok (frm_crc_ok),
        .hdr_valid  (hdr_valid),
        .hdr_dir    (hdr_dir),
        .is_ipv4    (is_ipv4),
        .src_ip     (src_ip),
        .dst_ip     (dst_ip),
        .ip_proto   (ip_proto),
        .ip_len     (ip_len),
        .src_port   (src_port),
        .dst_port   (dst_port),
        .tcp_flags  (tcp_flags)
    );

    // 2. Khối Bộ Lọc Gói Tin (2 lớp)
    pkt_filter #(.CLK_FREQ(CLK_FREQ)) u_filter (
        .clk               (clk),
        .rst_n             (rst_n),
        .hdr_valid         (hdr_valid),
        .hdr_dir           (hdr_dir),
        .is_ipv4           (is_ipv4),
        .src_ip            (src_ip),
        .dst_ip            (dst_ip),
        .ip_proto          (ip_proto),
        .ip_len            (ip_len),
        .src_port          (src_port),
        .dst_port          (dst_port),
        .tcp_flags         (tcp_flags),
        .frm_eof           (frm_eof),
        .ctrl_block_en     (ctrl_block_en),
        .ctrl_syn_limit_en (ctrl_syn_limit_en),
        .syn_limit         (syn_limit),
        .bl_valid          (bl_valid),
        .bl_ip0            (bl_ip0),
        .bl_ip1            (bl_ip1),
        .bl_ip2            (bl_ip2),
        .bl_ip3            (bl_ip3),
        .bl_ip4            (bl_ip4),
        .bl_ip5            (bl_ip5),
        .bl_ip6            (bl_ip6),
        .bl_ip7            (bl_ip7),
        .clear_counters    (clear_counters),
        .verdict_valid     (verdict_valid),
        .verdict_drop      (verdict_drop),
        .cnt_fwd           (cnt_fwd),
        .cnt_drop_bl       (cnt_drop_bl),
        .cnt_drop_syn      (cnt_drop_syn)
    );

    // 3. Khối Trích Xuất Đặc Trưng + Boyer-Moore
    feat_core #(.CLK_FREQ(CLK_FREQ)) u_feat (
        .clk          (clk),
        .rst_n        (rst_n),
        .hdr_valid    (hdr_valid),
        .hdr_dir      (hdr_dir),
        .is_ipv4      (is_ipv4),
        .src_ip       (src_ip),
        .dst_ip       (dst_ip),
        .ip_proto     (ip_proto),
        .ip_len       (ip_len),
        .src_port     (src_port),
        .dst_port     (dst_port),
        .tcp_flags    (tcp_flags),
        .ext_win_tick (ext_win_tick),
        .win_valid    (win_valid),
        .pkt_cnt      (pkt_cnt),
        .syn_cnt      (syn_cnt),
        .byte_cnt     (byte_cnt),
        .unique_ips   (unique_ips),
        .unique_ports (unique_ports),
        .suspect_ip   (suspect_ip),
        .confirm_cnt  (confirm_cnt)
    );

endmodule
