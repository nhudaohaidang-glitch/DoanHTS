// ============================================================================
// Module: pkt_parser
// Nhiệm vụ: Bóc tách header Ethernet, IPv4, TCP/UDP từ dòng byte của khung.
// Chuẩn giao tiếp: Tương thích hoàn toàn mục "Phần 3 nội bộ: bản ghi header"
// Miền clock: 27 MHz hệ thống, reset rst_n tích cực thấp.
// ============================================================================

module pkt_parser (
    input  wire        clk,
    input  wire        rst_n,

    // Giao tiếp nhận dòng byte từ Phần 4 (MAC/FIFO)
    input  wire        frm_valid,
    input  wire [7:0]  frm_data,
    input  wire        frm_sof,
    input  wire        frm_eof,
    input  wire        frm_dir,
    input  wire        frm_crc_ok,

    // Bản ghi header xuất ra cho pkt_filter và feat_core
    output reg         hdr_valid,     // Xung 1 nhịp khi bóc xong header
    output reg         hdr_dir,       // 0: ngoài->trong, 1: trong->ngoài
    output reg         is_ipv4,       // 1 = IPv4, 0 = ARP/loại khác
    output reg  [31:0] src_ip,        // Byte đầu ở bit cao [31:24]
    output reg  [31:0] dst_ip,        // Byte đầu ở bit cao [31:24]
    output reg  [7:0]  ip_proto,      // 6 = TCP, 17 = UDP
    output reg  [15:0] ip_len,        // Total length IPv4
    output reg  [15:0] src_port,      // Cổng nguồn TCP/UDP
    output reg  [15:0] dst_port,      // Cổng đích TCP/UDP
    output reg  [7:0]  tcp_flags      // Cờ TCP (bit 1=SYN, bit 4=ACK)
);

    // Bộ đếm vị trí byte trong khung Ethernet hiện tại (bắt đầu từ 0 khi frm_sof=1)
    reg [10:0] byte_cnt;

    // Lưu tạm các byte để ghép thành trường đa byte
    reg [15:0] ether_type;
    reg [3:0]  ip_ihl;                // Chiều dài IPv4 header (đơn vị từ 32-bit, chuẩn là 5 = 20 bytes)
    reg [10:0] l4_offset;             // Vị trí bắt đầu của Transport layer (TCP/UDP)

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            byte_cnt    <= 11'd0;
            hdr_valid   <= 1'b0;
            hdr_dir     <= 1'b0;
            is_ipv4     <= 1'b0;
            src_ip      <= 32'd0;
            dst_ip      <= 32'd0;
            ip_proto    <= 8'd0;
            ip_len      <= 16'd0;
            src_port    <= 16'd0;
            dst_port    <= 16'd0;
            tcp_flags   <= 8'd0;
            ether_type  <= 16'd0;
            ip_ihl      <= 4'd5;
            l4_offset   <= 11'd34;
        end else begin
            hdr_valid <= 1'b0; // Mặc định là xung 1 nhịp

            if (frm_valid) begin
                if (frm_sof) begin
                    byte_cnt <= 11'd1;   // [GHEP-P1] byte cua nhip SOF la byte 0 -> byte ke tiep la 1 (goc: 0, lech 1 byte)
                    hdr_dir  <= frm_dir;
                    is_ipv4  <= 1'b0;
                    ip_proto <= 8'd0;
                    tcp_flags<= 8'd0;
                end else begin
                    byte_cnt <= byte_cnt + 11'd1;
                end

                // Bóc tách theo vị trí byte (Ethernet chuẩn: 14 byte MAC + EtherType)
                case (byte_cnt)
                    // EtherType (Byte 12, 13)
                    11'd12: ether_type[15:8] <= frm_data;
                    11'd13: begin
                        ether_type[7:0] <= frm_data;
                        if ({ether_type[15:8], frm_data} == 16'h0800) begin
                            is_ipv4 <= 1'b1;
                        end else begin
                            is_ipv4 <= 1'b0;
                            // Nếu không phải IPv4 (ví dụ ARP 0x0806), báo hdr_valid ngay lập tức
                            hdr_valid <= 1'b1;
                        end
                    end

                    // IPv4 Header: Bắt đầu từ byte 14
                    11'd14: begin
                        if (is_ipv4) begin
                            ip_ihl    <= frm_data[3:0]; // 4-bit IHL
                            l4_offset <= 11'd14 + {5'd0, frm_data[3:0], 2'b00}; // Offset = 14 + IHL*4
                        end
                    end

                    // Total Length IPv4 (Byte 16, 17)
                    11'd16: if (is_ipv4) ip_len[15:8] <= frm_data;
                    11'd17: if (is_ipv4) ip_len[7:0]  <= frm_data;

                    // Protocol (Byte 23)
                    11'd23: if (is_ipv4) ip_proto <= frm_data;

                    // Source IP (Byte 26..29) - Byte đầu ở bit cao [31:24]
                    11'd26: if (is_ipv4) src_ip[31:24] <= frm_data;
                    11'd27: if (is_ipv4) src_ip[23:16] <= frm_data;
                    11'd28: if (is_ipv4) src_ip[15:8]  <= frm_data;
                    11'd29: if (is_ipv4) src_ip[7:0]   <= frm_data;

                    // Destination IP (Byte 30..33)
                    11'd30: if (is_ipv4) dst_ip[31:24] <= frm_data;
                    11'd31: if (is_ipv4) dst_ip[23:16] <= frm_data;
                    11'd32: if (is_ipv4) dst_ip[15:8]  <= frm_data;
                    11'd33: if (is_ipv4) begin
                        dst_ip[7:0]   <= frm_data;
                        // [GHEP-P1] IPv4 khong phai TCP/UDP (ICMP...): bao hdr_valid sau IP dich,
                        // de bo loc xet dung khung nay va feat_core dem du goi IPv4
                        if (ip_proto != 8'd6 && ip_proto != 8'd17) hdr_valid <= 1'b1;
                    end

                    default: ;
                endcase

                // Đọc tầng Giao vận (L4: TCP hoặc UDP) dựa trên l4_offset
                if (is_ipv4 && byte_cnt >= l4_offset) begin
                    // Source Port (offset + 0, 1)
                    if (byte_cnt == l4_offset + 11'd0) src_port[15:8] <= frm_data;
                    if (byte_cnt == l4_offset + 11'd1) src_port[7:0]  <= frm_data;

                    // Dest Port (offset + 2, 3)
                    if (byte_cnt == l4_offset + 11'd2) dst_port[15:8] <= frm_data;
                    if (byte_cnt == l4_offset + 11'd3) dst_port[7:0]  <= frm_data;

                    // Nếu là TCP (ip_proto == 6), cờ TCP flags ở byte offset + 13
                    if (ip_proto == 8'd6) begin
                        if (byte_cnt == l4_offset + 11'd13) begin
                            tcp_flags <= frm_data;
                            // Đã đọc xong toàn bộ header quan trọng của TCP!
                            hdr_valid <= 1'b1;
                        end
                    end else if (ip_proto == 8'd17) begin
                        // UDP: đọc xong port đích ở byte 3 là đủ thông tin
                        if (byte_cnt == l4_offset + 11'd3) begin
                            tcp_flags <= 8'd0;
                            hdr_valid <= 1'b1;
                        end
                    end
                end
            end

            // Reset bộ đếm khi hết khung
            if (frm_eof) begin
                byte_cnt <= 11'd0;
            end
        end
    end

endmodule
