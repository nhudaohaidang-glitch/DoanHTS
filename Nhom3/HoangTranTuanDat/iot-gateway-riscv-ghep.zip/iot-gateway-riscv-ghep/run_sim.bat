@echo off
rem Chay mo phong tren Windows (can Icarus Verilog va Python 3 trong PATH). RTL: sources.f
rem   run_sim.bat         : toan he thong 40 giay mo phong (~6-10 phut), kiem log bang check_log.py
rem   run_sim.bat quick   : chay 9 giay de xem log nhanh (khong kiem tra)
rem   run_sim.bat oled    : man OLED (mo hinh SSD1306)
rem   run_sim.bat board   : top cua kit voi firmware.hex that
rem   run_sim.bat mac     : rieng MAC Ethernet Phan 4
rem   run_sim.bat system  : toan he thong voi MAC that
cd /d "%~dp0"
if not exist sim\out mkdir sim\out

if /I "%1"=="quick" (
    iverilog -g2012 -o sim\out\tb_gateway.vvp -c sources.f sim\tb_gateway.v || goto :err
    vvp -n sim\out\tb_gateway.vvp +stop=9
    exit /b 0
)
if /I "%1"=="oled" (
    iverilog -g2012 -o sim\out\tb_oled.vvp -c sources.f sim\ssd1306_model.v sim\tb_oled.v || goto :err
    vvp -n sim\out\tb_oled.vvp
    exit /b 0
)
if /I "%1"=="mac" (
    iverilog -g2012 -o sim\out\tb_eth_mac.vvp rtl\part4_eth\async_fifo.v rtl\part4_eth\rmii_rx.v rtl\part4_eth\rmii_tx.v rtl\part4_eth\frame_buf.v rtl\part4_eth\eth_bridge.v rtl\part4_eth\eth_mac_wrap.v sim\tb_eth_mac.v || goto :err
    vvp -n sim\out\tb_eth_mac.vvp
    exit /b 0
)
if /I "%1"=="system" (
    iverilog -g2012 -o sim\out\tb_system_mac.vvp -c sources.f rtl\board\tangnano9k_top.v sim\tb_system_mac.v || goto :err
    vvp -n sim\out\tb_system_mac.vvp
    exit /b 0
)
if /I "%1"=="board" (
    iverilog -g2012 -o sim\out\tb_board.vvp -c sources.f rtl\board\tangnano9k_top.v sim\ssd1306_model.v sim\tb_board.v || goto :err
    vvp -n sim\out\tb_board.vvp
    exit /b 0
)
iverilog -g2012 -o sim\out\tb_gateway.vvp -c sources.f sim\tb_gateway.v || goto :err
vvp -n sim\out\tb_gateway.vvp
python tools\check_log.py sim\out\uart.log
exit /b 0

:err
echo LOI: bien dich Verilog that bai
exit /b 1
