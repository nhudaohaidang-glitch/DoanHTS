# Danh sach file RTL (thu tu bien dich) - Phan 1 phien ban tuong lua Ethernet
# Phan 3 (ban cua Phan 3, part3_top):  rtl/part3/*.v
#   Cho sua khi ghep danh dau "[GHEP-P1]"; ban goc giu trong rtl/part3/goc/ (khong bien dich).
#   Khoi gia cu cua Phan 1 van o rtl/stubs/ (khong bien dich).
# Phan 2 (AI v6, ban cua Phan 2):     rtl/part2_ai/ai_core_model_v6.v (khong sua)
# Phan 4 (MAC Ethernet that, ban cua Phan 4 - eth_bridge): rtl/part4_eth/*.v (khong sua)
#   - Top cua kit goi thang eth_bridge khi SELFTEST = 2.
#   - eth_mac_wrap.v (module eth_mac) chi dung cho tb_eth_mac.
#   - eth_stub chi con dung cho mo phong / demo (SELFTEST = 1).
rtl/picorv32.v
rtl/fw_ram.v
rtl/uart_tx.v
rtl/wb_ram.v
rtl/wb_uart.v
rtl/clk_meter.v
rtl/wb_sys.v
rtl/wb_feat_regs.v
rtl/wb_ai_regs.v
rtl/wb_filter_regs.v
rtl/gateway_soc.v
rtl/part2_ai/ai_core_model_v6.v
rtl/part3/pkt_parser.v
rtl/part3/feat_core.v
rtl/part3/pkt_filter.v
rtl/part3/part3_top.v
rtl/part4_eth/async_fifo.v
rtl/part4_eth/rmii_rx.v
rtl/part4_eth/rmii_tx.v
rtl/part4_eth/frame_buf.v
rtl/part4_eth/eth_bridge.v
rtl/part4_eth/eth_mac_wrap.v
rtl/stubs/eth_stub.v
