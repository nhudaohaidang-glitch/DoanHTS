/* =============================================================================
 * hw.h - Ban do thanh ghi phan cung (khop voi rtl/soc_top.v va rtl/wb_*.v)
 * ========================================================================== */
#ifndef HW_H
#define HW_H

#include <stdint.h>

#define REG32(addr)        (*(volatile uint32_t *)(addr))

#define CLK_HZ             27000000u

/* ---------------- UART TX: 0x1000_0000 ---------------- */
#define UART_BASE          0x10000000u
#define UART_DATA          REG32(UART_BASE + 0x00)   /* W: gui 1 byte            */
#define UART_STATUS        REG32(UART_BASE + 0x04)   /* R: bit0 = dang ban       */
#define UART_BUSY          (1u << 0)

/* ---------------- Khoi dac trung (Phan 3): 0x2000_0000 ---------------- */
#define FEAT_BASE          0x20000000u
#define FEAT_STATUS        REG32(FEAT_BASE + 0x00)
#define FEAT_CTRL          REG32(FEAT_BASE + 0x04)
#define FEAT_WIN_ID        REG32(FEAT_BASE + 0x08)
#define FEAT_PKT_CNT       REG32(FEAT_BASE + 0x0C)
#define FEAT_BYTE_SUM      REG32(FEAT_BASE + 0x10)
#define FEAT_SYN_CNT       REG32(FEAT_BASE + 0x14)
#define FEAT_SRC_IP        REG32(FEAT_BASE + 0x18)
#define FEAT_DST_IP        REG32(FEAT_BASE + 0x1C)
#define FEAT_DST_PORT      REG32(FEAT_BASE + 0x20)
#define FEAT_ERR_CNT       REG32(FEAT_BASE + 0x24)
#define FEAT_ST_READY      (1u << 0)
#define FEAT_ST_OVERRUN    (1u << 1)
#define FEAT_CTRL_ACK      (1u << 0)
#define FEAT_CTRL_CLR_OVR  (1u << 1)
#define FEAT_CTRL_ENABLE   (1u << 8)

/* ---------------- AI accelerator (Phan 2): 0x3000_0000 ---------------- */
#define AI_BASE            0x30000000u
#define AI_STATUS          REG32(AI_BASE + 0x00)
#define AI_CTRL            REG32(AI_BASE + 0x04)
#define AI_FEAT_LO         REG32(AI_BASE + 0x08)     /* f0..f3, f0 o bit 7:0  */
#define AI_FEAT_HI         REG32(AI_BASE + 0x0C)     /* f4..f5                */
#define AI_RESULT          REG32(AI_BASE + 0x10)
#define AI_SCORE0          REG32(AI_BASE + 0x14)
#define AI_SCORE1          REG32(AI_BASE + 0x18)
#define AI_SCORE2          REG32(AI_BASE + 0x1C)
#define AI_LAT             REG32(AI_BASE + 0x20)
#define AI_ST_BUSY         (1u << 0)
#define AI_ST_DONE         (1u << 1)
#define AI_CTRL_START      (1u << 0)
#define AI_CTRL_ABORT      (1u << 1)

/* ---------------- He thong: 0x4000_0000 ---------------- */
#define SYS_BASE           0x40000000u
#define SYS_LED            REG32(SYS_BASE + 0x00)    /* 6 bit, 1 = sang       */
#define SYS_CYCLE          REG32(SYS_BASE + 0x04)    /* dem chu ky clock      */
#define SYS_BUZZER         REG32(SYS_BASE + 0x08)    /* bit0 = muc chan coi   */
#define SYS_BTN            REG32(SYS_BASE + 0x0C)    /* bit0 = dang nhan S1   */
#define SYS_ID             REG32(SYS_BASE + 0x10)    /* 0x52563332 "RV32"     */
#define SYS_SCRATCH        REG32(SYS_BASE + 0x14)
#define SYS_ID_VALUE       0x52563332u

/* Muc logic lam coi keu: doi thanh 0 neu module coi tich cuc muc thap */
#define BUZZER_ON_LEVEL    1u

#endif
