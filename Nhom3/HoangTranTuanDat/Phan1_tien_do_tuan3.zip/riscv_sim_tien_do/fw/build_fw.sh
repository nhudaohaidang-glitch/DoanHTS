#!/usr/bin/env sh
# Bien dich firmware -> firmware.hex (Linux/WSL/Git Bash)
# Doi PREFIX neu ban dung bo bien dich khac, vi du:  PREFIX=riscv-none-elf- ./build_fw.sh
set -e
cd "$(dirname "$0")"
PREFIX=${PREFIX:-riscv64-unknown-elf-}
CFLAGS="-march=rv32i -mabi=ilp32 -Os -ffreestanding -fno-builtin -nostdlib -Wall -Wextra $EXTRA_CFLAGS"
SRC="start.S main.c uart.c libc_min.c"

${PREFIX}gcc $CFLAGS -T link.ld -Wl,-Map,firmware.map,--no-warn-rwx-segments,--gc-sections \
    -ffunction-sections -fdata-sections $SRC -lgcc -o firmware.elf
${PREFIX}objcopy -O binary firmware.elf firmware.bin
${PREFIX}objdump -d firmware.elf > firmware.lst
${PREFIX}size firmware.elf
python3 makehex.py firmware.bin 4096 > firmware.hex
echo "OK: fw/firmware.hex"
