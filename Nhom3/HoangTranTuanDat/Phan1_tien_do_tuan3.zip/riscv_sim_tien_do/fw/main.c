/* =============================================================================
 * main.c - Firmware IoT Gateway (Phan 1) - BAN DANG PHAT TRIEN
 *
 * Da lam:
 *   - Khoi dong: tat LED/coi, in thong tin, tu kiem tra (POST): thanh ghi ID,
 *     ghi/doc theo tu va theo byte, goi thu AI accelerator
 *   - Vong lap: cho khoi dac trung bao co cua so moi, doc 8 thanh ghi bo dem,
 *     xac nhan (ACK), in so lieu tho ra UART, LED0 dao trang thai moi cua so
 *
 * Dang lam (TODO):
 *   - Tinh 6 dac trung va luong tu hoa ve int8
 *   - Ghi dac trung vao AI accelerator, doc ket qua phan loai
 *   - Loc canh bao, dieu khien LED canh bao va coi, nut S1 tat coi
 *   - Gui dong ket qua co checksum cho ESP32 (Phan 4)
 * ========================================================================== */
#include <stdint.h>
#include "hw.h"
#include "uart.h"

#define NO_DATA_TIMEOUT   (3u * CLK_HZ)     /* 3 s khong co cua so -> in nhac nho */
#define AI_TIMEOUT        200000u           /* chu ky                              */

#define LED_HEARTBEAT     (1u << 0)
#define LED_ERROR         (1u << 5)

static void log_line(const char *s)
{
    uart_puts("# ");
    uart_puts(s);
    uart_puts("\r\n");
}

/* Goi thu AI accelerator voi 6 dac trung = 0, tra ve so chu ky tinh */
static int ai_ping(uint32_t *lat)
{
    AI_FEAT_LO = 0;
    AI_FEAT_HI = 0;
    AI_CTRL = AI_CTRL_START;

    uint32_t t0 = SYS_CYCLE;
    while (!(AI_STATUS & AI_ST_DONE)) {
        if (SYS_CYCLE - t0 > AI_TIMEOUT) {
            AI_CTRL = AI_CTRL_ABORT;
            return -1;
        }
    }
    *lat = AI_LAT;
    return 0;
}

/* Tu kiem tra luc khoi dong */
static uint32_t post(uint32_t *ai_lat)
{
    uint32_t err = 0;

    if (SYS_ID != SYS_ID_VALUE)
        err |= 1u;                                   /* bus / giai ma dia chi */

    SYS_SCRATCH = 0xA5A5F00Fu;
    if (SYS_SCRATCH != 0xA5A5F00Fu)
        err |= 2u;
    SYS_SCRATCH = 0x5A5A0FF0u;
    *(volatile uint8_t *)(SYS_BASE + 0x14 + 1) = 0x77; /* ghi 1 byte (sel) */
    if (SYS_SCRATCH != 0x5A5A77F0u)
        err |= 2u;

    if (ai_ping(ai_lat) != 0)
        err |= 4u;                                   /* AI khong tra loi */

    return err;
}

int main(void)
{
    char line[120];
    strbuf_t sb;
    uint32_t ai_lat0 = 0;

    SYS_LED = 0;
    SYS_BUZZER = BUZZER_ON_LEVEL ^ 1u;               /* tat coi */

    uart_puts("\r\n");
    log_line("IDS Gateway - PicoRV32 RV32I @ 27 MHz (ban dang phat trien)");

    uint32_t post_err = post(&ai_lat0);
    sb_init(&sb, line, sizeof(line));
    if (post_err == 0) {
        sb_puts(&sb, "POST OK, AI lat=");
        sb_u32(&sb, ai_lat0);
        sb_puts(&sb, " chu ky");
    } else {
        sb_puts(&sb, "POST LOI 0x");
        sb_hex(&sb, post_err, 2);
    }
    log_line(line);

    FEAT_CTRL = FEAT_CTRL_ENABLE | FEAT_CTRL_CLR_OVR;

    uint32_t heartbeat = 0;
    uint32_t t_wait = SYS_CYCLE;

    for (;;) {
        /* ---- cho cua so moi */
        if (!(FEAT_STATUS & FEAT_ST_READY)) {
            if (SYS_CYCLE - t_wait > NO_DATA_TIMEOUT) {
                log_line("Chua co du lieu tu khoi dac trung");
                t_wait = SYS_CYCLE;
            }
            continue;
        }
        t_wait = SYS_CYCLE;

        /* ---- doc so lieu cua so */
        uint32_t win   = FEAT_WIN_ID;
        uint32_t pkt   = FEAT_PKT_CNT;
        uint32_t bytes = FEAT_BYTE_SUM;
        uint32_t syn   = FEAT_SYN_CNT;
        uint32_t src   = FEAT_SRC_IP;
        uint32_t dst   = FEAT_DST_IP;
        uint32_t port  = FEAT_DST_PORT;
        uint32_t st    = FEAT_STATUS;
        FEAT_CTRL = FEAT_CTRL_ENABLE | FEAT_CTRL_ACK |
                    ((st & FEAT_ST_OVERRUN) ? FEAT_CTRL_CLR_OVR : 0);

        /* TODO: tinh dac trung, goi AI, loc canh bao, gui ket qua cho ESP32 */

        /* ---- LED nhip tim + in so lieu tho */
        heartbeat ^= 1u;
        SYS_LED = (heartbeat ? LED_HEARTBEAT : 0) | (post_err ? LED_ERROR : 0);

        sb_init(&sb, line, sizeof(line));
        sb_puts(&sb, "win ");    sb_u32(&sb, win);
        sb_puts(&sb, ": pkt=");  sb_u32(&sb, pkt);
        sb_puts(&sb, " bytes="); sb_u32(&sb, bytes);
        sb_puts(&sb, " syn=");   sb_u32(&sb, syn);
        sb_puts(&sb, " src=");   sb_u32(&sb, src);
        sb_puts(&sb, " dst=");   sb_u32(&sb, dst);
        sb_puts(&sb, " port=");  sb_u32(&sb, port);
        if (st & FEAT_ST_OVERRUN)
            sb_puts(&sb, " (mat cua so)");
        log_line(line);
    }
}
