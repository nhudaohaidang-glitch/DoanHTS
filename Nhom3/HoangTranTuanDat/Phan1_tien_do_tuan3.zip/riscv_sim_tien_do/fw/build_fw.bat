@echo off
rem Bien dich firmware -> firmware.hex (Windows, bo xPack riscv-none-elf-gcc)
rem Neu ban dung bo bien dich khac, sua dong "set PREFIX=" ben duoi.
cd /d "%~dp0"
set PREFIX=riscv-none-elf-
set CFLAGS=-march=rv32i -mabi=ilp32 -Os -ffreestanding -fno-builtin -nostdlib -Wall -Wextra
set SRC=start.S main.c uart.c libc_min.c

%PREFIX%gcc %CFLAGS% -T link.ld -Wl,-Map,firmware.map,--no-warn-rwx-segments,--gc-sections -ffunction-sections -fdata-sections %SRC% -lgcc -o firmware.elf || goto :err
%PREFIX%objcopy -O binary firmware.elf firmware.bin || goto :err
%PREFIX%objdump -d firmware.elf > firmware.lst
%PREFIX%size firmware.elf
python makehex.py firmware.bin 4096 > firmware.hex || goto :err
echo OK: fw\firmware.hex
exit /b 0

:err
echo LOI: bien dich firmware that bai
exit /b 1
