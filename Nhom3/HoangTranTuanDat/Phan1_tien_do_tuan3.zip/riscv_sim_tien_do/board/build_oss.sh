#!/usr/bin/env sh
# =============================================================================
# Dung file nap .fs cho Tang Nano 9K bang bo cong cu ma nguon mo
# (Yosys + nextpnr-himbaechel + apicula). Chay tu bat ky dau:
#     ./board/build_oss.sh
# Can: pip install yowasp-yosys yowasp-nextpnr-himbaechel-gowin apycula
# (hoac ban yosys / nextpnr-himbaechel cai san: dat YOSYS=yosys NEXTPNR=nextpnr-himbaechel)
# =============================================================================
set -e
cd "$(dirname "$0")/.."
YOSYS=${YOSYS:-yowasp-yosys}
NEXTPNR=${NEXTPNR:-yowasp-nextpnr-himbaechel-gowin}
mkdir -p build

SRC="$(grep -v '^#' sources.f | tr '\n' ' ') rtl/board/tangnano9k_top.v"

echo "== Tong hop (Yosys)"
$YOSYS -q -l build/yosys.log \
    -p "read_verilog $SRC; synth_gowin -top tangnano9k_top -json build/tangnano9k_synth.json"

echo "== Dat va di day (nextpnr)"
$NEXTPNR -q -l build/nextpnr.log \
    --json build/tangnano9k_synth.json --write build/tangnano9k_pnr.json \
    --device GW1NR-LV9QN88PC6/I5 --vopt family=GW1N-9C \
    --vopt cst=board/tangnano9k.cst --freq 27

echo "== Dong goi file nap (apicula)"
gowin_pack -d GW1N-9C -o build/tangnano9k.fs build/tangnano9k_pnr.json

sed -n '/Device utilisation/,/^$/p' build/nextpnr.log | grep -E "IOB|LUT4|ALU:|DFF|BSRAM|MULT18X18:|RAM16SDP4"
grep -E "Max frequency for clock" build/nextpnr.log | tail -1
echo "OK: build/tangnano9k.fs"
