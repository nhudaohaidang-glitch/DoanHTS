// Rang buoc thoi gian: clock 27 MHz (chu ky 37,037 ns)
create_clock -name clk_27m -period 37.037 -waveform {0 18.518} [get_ports {clk_27m}]
