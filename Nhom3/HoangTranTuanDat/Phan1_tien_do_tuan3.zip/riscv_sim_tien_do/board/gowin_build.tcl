# =============================================================================
# gowin_build.tcl - Dung file nap bang Gowin EDA o che do dong lenh (gw_sh)
# Chay tu thu muc goc riscv_sim (Command Prompt):
#     "C:\Gowin\Gowin_V1.9.x_x64\IDE\bin\gw_sh.exe" board\gowin_build.tcl
# (sua duong dan gw_sh.exe theo noi ban cai Gowin)
#
# - Doc danh sach file RTL tu sources.f (giong mo phong)
# - Tu tao build/gowin/gowin_top.v chua duong dan TUYET DOI toi fw/firmware.hex,
#   de Gowin luon tim thay file khoi tao RAM
# Ket qua: impl/pnr/tangnano9k.fs
# =============================================================================
set root [file normalize [file join [file dirname [info script]] ..]]
cd $root
set fw [file normalize [file join $root fw firmware.hex]]
if {![file exists $fw]} { error "Khong thay $fw - hay bien dich firmware truoc" }

file mkdir [file join $root build gowin]
set wrap [file join $root build gowin gowin_top.v]
set f [open $wrap w]
puts $f "// Tu sinh boi gowin_build.tcl - khong sua tay"
puts $f "module gowin_top ("
puts $f "    input clk_27m, input rst_n, input key_n,"
puts $f "    output uart_tx, output esp_uart_tx, output buzzer,"
puts $f "    input spi_sclk, input spi_mosi, input spi_cs_n, output spi_miso,"
puts $f "    output \[5:0\] led_n);"
puts $f "    tangnano9k_top #(.FIRMWARE(\"$fw\")) u_top ("
puts $f "        .clk_27m(clk_27m), .rst_n(rst_n), .key_n(key_n),"
puts $f "        .uart_tx(uart_tx), .esp_uart_tx(esp_uart_tx), .buzzer(buzzer),"
puts $f "        .spi_sclk(spi_sclk), .spi_mosi(spi_mosi), .spi_cs_n(spi_cs_n), .spi_miso(spi_miso),"
puts $f "        .led_n(led_n));"
puts $f "endmodule"
close $f

set_device GW1NR-LV9QN88PC6/I5 -device_version C

set src [open [file join $root sources.f] r]
foreach line [split [read $src] "\n"] {
    set line [string trim $line]
    if {$line eq "" || [string index $line 0] eq "#"} { continue }
    add_file $line
}
close $src
add_file rtl/board/tangnano9k_top.v
add_file build/gowin/gowin_top.v
add_file board/tangnano9k.cst
add_file board/tangnano9k.sdc

set_option -top_module gowin_top
set_option -verilog_std sysv2017
set_option -output_base_name tangnano9k

run all
