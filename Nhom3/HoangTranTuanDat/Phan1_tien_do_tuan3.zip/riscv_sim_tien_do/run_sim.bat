@echo off
rem Chay mo phong tren Windows (can Icarus Verilog trong PATH). Danh sach file RTL: sources.f
rem   run_sim.bat        : toan he thong (CPU + bus + khoi gia Phan 2/3), tu kiem tra
rem   run_sim.bat vcd    : nhu tren, ghi dang song build\tb_soc.vcd va mo GTKWave
rem   run_sim.bat board  : top cua kit Tang Nano 9K (UART 115200 that)
cd /d "%~dp0"
if not exist build mkdir build

if /I "%1"=="board" (
    iverilog -g2012 -c sources.f -o build\board.vvp rtl\board\tangnano9k_top.v sim\tb_board.v || goto :err
    vvp -n build\board.vvp
    exit /b 0
)

iverilog -g2012 -c sources.f -o build\sim.vvp sim\tb_soc.v || goto :err
if /I "%1"=="vcd" (
    vvp -n build\sim.vvp +vcd
    gtkwave build\tb_soc.vcd sim\tb_soc.gtkw
) else (
    vvp -n build\sim.vvp
)
exit /b 0

:err
echo LOI: bien dich Verilog that bai
exit /b 1
