// =============================================================================
// tb_soc.v - Testbench toan he thong (soc_top + khoi gia Phan 2/3) - ban dang phat trien
//
// De mo phong nhanh: UART 1,35 Mbaud (20 chu ky/bit), cua so 60.000 chu ky.
// Testbench tu kiem tra:
//   - Firmware khoi dong, POST OK (bus, thanh ghi, AI accelerator tra loi)
//   - CPU doc duoc so lieu tung cua so qua bus Wishbone: win tang lien tiep
//   - LED0 (nhip tim) dao trang thai moi cua so, CPU khong bi trap
// Them +vcd khi chay vvp de ghi dang song ra build/tb_soc.vcd.
// =============================================================================
`timescale 1ns / 1ps

module tb_soc;
    localparam integer CLK_HZ       = 27_000_000;
    localparam integer BAUD         = 1_350_000;
    localparam integer CLKS_PER_BIT = CLK_HZ / BAUD;       // 20
    localparam integer N_WINDOWS    = 8;
    localparam integer TIMEOUT_CYC  = 1_500_000;

    reg clk = 1'b0;
    reg resetn = 1'b0;
    always #18.518 clk = ~clk;                               // 27 MHz

    wire       uart_txd, buzzer, trap, spi_miso;
    wire [5:0] led;

    soc_top #(
        .CLK_HZ       (CLK_HZ),
        .BAUD         (BAUD),
        .FIRMWARE     ("fw/firmware.hex"),
        .DEBOUNCE_CYC (50)
    ) dut (
        .clk (clk), .resetn (resetn),
        .uart_txd (uart_txd), .led (led), .buzzer (buzzer), .btn_pressed (1'b0),
        .spi_sclk (1'b0), .spi_mosi (1'b0), .spi_cs_n (1'b1), .spi_miso (spi_miso),
        .trap (trap)
    );
    defparam dut.u_feat.WINDOW_CYCLES = 60_000;

    // ------------------------------------------------------------ bo thu UART + tach dong
    reg [8*120-1:0] line = 0;
    integer line_len = 0;
    reg [7:0] ch;
    integer   i;

    integer windows = 0, errors = 0, post_ok = 0, last_win = -1, win, pos;
    reg     last_led0 = 1'b0;
    reg [7:0] c;

    task process_line;
        begin
            if (line[8*line_len-1 -: 8] == "#") begin
                $display("  %0s", line);
                if (line[8*line_len-1 -: 8*9] == "# POST OK") post_ok = 1;
                if (line_len > 6 && line[8*line_len-1 -: 8*6] == "# win ") begin
                    // doc so thu tu cua so ngay sau "# win "
                    win = 0;
                    for (pos = line_len - 7; pos >= 0; pos = pos - 1) begin
                        c = line[8*pos +: 8];
                        if (c >= "0" && c <= "9") win = win * 10 + (c - 8'd48);
                        else pos = -1;                                  // het so
                    end
                    windows = windows + 1;
                    if (last_win >= 0 && win != last_win + 1) begin
                        errors = errors + 1;
                        $display("[TB]   LOI: win khong lien tiep (%0d sau %0d)", win, last_win);
                    end
                    if (windows > 1 && led[0] == last_led0) begin
                        errors = errors + 1;
                        $display("[TB]   LOI: LED0 khong dao trang thai");
                    end
                    last_win  = win;
                    last_led0 = led[0];
                end
            end
        end
    endtask

    initial begin : uart_rx_model
        wait (resetn === 1'b1);
        forever begin
            @(negedge uart_txd);
            repeat (CLKS_PER_BIT / 2) @(posedge clk);
            for (i = 0; i < 8; i = i + 1) begin
                repeat (CLKS_PER_BIT) @(posedge clk);
                ch[i] = uart_txd;
            end
            repeat (CLKS_PER_BIT) @(posedge clk);
            if (uart_txd !== 1'b1) begin
                errors = errors + 1;
                $display("[TB]   LOI: stop bit UART");
            end
            if (ch == 8'h0A) begin
                if (line_len > 0) process_line;
                line = 0;
                line_len = 0;
            end else if (ch != 8'h0D && line_len < 120) begin
                line = {line[8*119-1:0], ch};
                line_len = line_len + 1;
            end
        end
    end

    // ------------------------------------------------------------ dieu khien
    integer cycles = 0;
    always @(posedge clk) cycles <= cycles + 1;

    initial begin
        if ($test$plusargs("vcd")) begin
            // chi ghi cac tin hieu chinh trong 150.000 chu ky dau (POST + 2 cua so) de file nho
            $dumpfile("build/tb_soc.vcd");
            $dumpvars(1, tb_soc);
            $dumpvars(1, tb_soc.dut);
            $dumpvars(1, tb_soc.dut.u_feat_regs);
            fork
                begin
                    repeat (150_000) @(posedge clk);
                    $dumpoff;
                    $display("[TB] (da ghi dang song 150.000 chu ky dau vao build/tb_soc.vcd)");
                end
            join_none
        end
        $display("[TB] Mo phong toan he thong: PicoRV32 + Wishbone + khoi gia Phan 2/3");
        repeat (20) @(posedge clk);
        resetn = 1'b1;

        wait (windows >= N_WINDOWS || trap || cycles > TIMEOUT_CYC);
        repeat (10) @(posedge clk);
        $display("[TB] ---------------------------------------------------------");
        $display("[TB] So cua so CPU da doc: %0d, so chu ky: %0d", windows, cycles);
        if (!post_ok)              begin errors = errors + 1; $display("[TB]   LOI: khong thay POST OK"); end
        if (trap)                  begin errors = errors + 1; $display("[TB]   LOI: CPU bi trap"); end
        if (windows < N_WINDOWS)   begin errors = errors + 1; $display("[TB]   LOI: het thoi gian"); end
        if (errors == 0) $display("[TB] KET QUA: PASS - CPU doc dung so lieu qua bus Wishbone");
        else             $display("[TB] KET QUA: FAIL - %0d loi", errors);
        $finish;
    end
endmodule
