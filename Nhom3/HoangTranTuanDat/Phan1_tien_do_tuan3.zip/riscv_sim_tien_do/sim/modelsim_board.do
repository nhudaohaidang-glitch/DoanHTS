# =============================================================================
# modelsim_board.do - Mo phong top cua kit Tang Nano 9K bang ModelSim / Questa
# Cach chay: trong ModelSim chon File > Change Directory -> thu muc riscv_sim,
#            roi go o cua so Transcript:   do sim/modelsim_board.do
# =============================================================================
if {![file exists sources.f]} {
    error "Hay File > Change Directory toi thu muc riscv_sim truoc"
}
if {[file exists work]} { vdel -lib work -all }
vlib work

set files {}
set fh [open sources.f r]
foreach line [split [read $fh] "\n"] {
    set line [string trim $line]
    if {$line ne "" && [string index $line 0] ne "#"} { lappend files $line }
}
close $fh
eval vlog -sv $files rtl/board/tangnano9k_top.v sim/tb_board.v

vsim -voptargs=+acc -onfinish stop work.tb_board

add wave -divider "Kit"
add wave /tb_board/clk /tb_board/dut/resetn /tb_board/uart_tx /tb_board/buzzer
add wave -radix bin /tb_board/led_n
add wave -divider "Bus Wishbone"
add wave /tb_board/dut/u_soc/wb_stb /tb_board/dut/u_soc/wb_we /tb_board/dut/u_soc/wb_ack
add wave -radix hex /tb_board/dut/u_soc/wb_adr /tb_board/dut/u_soc/wb_dat_w /tb_board/dut/u_soc/wb_dat_r
add wave /tb_board/dut/u_soc/stb_ram /tb_board/dut/u_soc/stb_uart /tb_board/dut/u_soc/stb_sys

run -all
wave zoom full
