// =============================================================================
// tb_board.v - Testbench cho tangnano9k_top (muc kit, UART 115200 that):
//   reset bat nguon, POST, CPU doc cua so dau tien, dao muc LED, chan ESP32 = chan USB
// Cua so cua khoi gia rut ngan con 400.000 chu ky de mo phong nhanh.
// =============================================================================
`timescale 1ns / 1ps

module tb_board;
    localparam integer CLKS_PER_BIT = 27_000_000 / 115_200;
    localparam integer TIMEOUT_CYC  = 1_500_000;

    reg  clk = 1'b0;
    always #18.518 clk = ~clk;

    wire       uart_tx, esp_uart_tx, buzzer, spi_miso;
    wire [5:0] led_n;

    tangnano9k_top dut (
        .clk_27m (clk), .rst_n (1'b1), .key_n (1'b1),
        .uart_tx (uart_tx), .esp_uart_tx (esp_uart_tx), .buzzer (buzzer),
        .spi_sclk (1'b0), .spi_mosi (1'b0), .spi_cs_n (1'b1), .spi_miso (spi_miso),
        .led_n (led_n)
    );
`ifndef NETLIST
    defparam dut.u_soc.u_feat.WINDOW_CYCLES = 400_000;
`endif

    reg [8*120-1:0] line = 0;
    integer line_len = 0, i, post_ok = 0, frames = 0, errors = 0;
    reg [7:0] ch;

    initial begin : uart_rx_model
        wait (uart_tx === 1'b1);
        forever begin
            @(negedge uart_tx);
            repeat (CLKS_PER_BIT / 2) @(posedge clk);
            for (i = 0; i < 8; i = i + 1) begin
                repeat (CLKS_PER_BIT) @(posedge clk);
                ch[i] = uart_tx;
            end
            repeat (CLKS_PER_BIT) @(posedge clk);
            if (ch == 8'h0A) begin
                if (line_len > 0) begin
                    $display("  %0s", line);
                    if (line[8*line_len-1 -: 8*9] == "# POST OK") post_ok = 1;
                    if (line_len > 6 && line[8*line_len-1 -: 8*6] == "# win ") frames = frames + 1;
                end
                line = 0;
                line_len = 0;
            end else if (ch != 8'h0D && line_len < 120) begin
                line = {line[8*119-1:0], ch};
                line_len = line_len + 1;
            end
        end
    end

    always @(posedge clk)
        if (esp_uart_tx !== uart_tx) begin
            errors = errors + 1;
            $display("[TB] LOI: chan ESP32 khac chan USB");
        end

    integer cycles = 0;
    always @(posedge clk) cycles <= cycles + 1;

    initial begin
        $display("[TB] Mo phong muc kit: tangnano9k_top");
        wait (frames >= 1 || cycles > TIMEOUT_CYC);
        repeat (10) @(posedge clk);
        $display("[TB] So chu ky: %0d (gom ~65536 chu ky reset bat nguon)", cycles);
        $display("[TB] Chan LED (muc 0 = sang): %b, coi: %b", led_n, buzzer);
        if (!post_ok)    begin errors = errors + 1; $display("[TB] LOI: khong thay POST OK"); end
        if (frames < 1)  begin errors = errors + 1; $display("[TB] LOI: CPU chua doc duoc cua so nao"); end
        // cua so 0 la binh thuong: chi LED0 (nhip tim) sang -> led_n = 111110
        if (led_n !== 6'b111110) begin errors = errors + 1; $display("[TB] LOI: chan LED sai"); end
        if (buzzer !== 1'b0)     begin errors = errors + 1; $display("[TB] LOI: coi keu sai"); end
        if (errors == 0) $display("[TB] KET QUA: PASS - top cua kit chay dung");
        else             $display("[TB] KET QUA: FAIL - %0d loi", errors);
        $finish;
    end
endmodule
