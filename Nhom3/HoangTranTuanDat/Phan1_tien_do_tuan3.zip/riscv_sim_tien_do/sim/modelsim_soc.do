# =============================================================================
# modelsim_soc.do - Mo phong toan he thong bang ModelSim / Questa
# Cach chay: trong ModelSim chon File > Change Directory -> thu muc riscv_sim,
#            roi go o cua so Transcript:   do sim/modelsim_soc.do
# =============================================================================
if {![file exists sources.f]} {
    error "Hay File > Change Directory toi thu muc riscv_sim truoc"
}
if {[file exists work]} { vdel -lib work -all }
vlib work

# doc danh sach file RTL tu sources.f (bo dong chu thich #)
set files {}
set fh [open sources.f r]
foreach line [split [read $fh] "\n"] {
    set line [string trim $line]
    if {$line ne "" && [string index $line 0] ne "#"} { lappend files $line }
}
close $fh
eval vlog -sv $files sim/tb_soc.v

vsim -voptargs=+acc -onfinish stop work.tb_soc

add wave -divider "Bus Wishbone"
add wave /tb_soc/clk /tb_soc/resetn
add wave /tb_soc/dut/wb_cyc /tb_soc/dut/wb_stb /tb_soc/dut/wb_we /tb_soc/dut/wb_ack
add wave -radix hex /tb_soc/dut/wb_adr /tb_soc/dut/wb_sel /tb_soc/dut/wb_dat_w /tb_soc/dut/wb_dat_r
add wave -divider "Giai ma dia chi"
add wave /tb_soc/dut/stb_ram /tb_soc/dut/stb_uart /tb_soc/dut/stb_feat /tb_soc/dut/stb_ai /tb_soc/dut/stb_sys
add wave -divider "Dac trung / AI"
add wave /tb_soc/dut/f_valid
add wave -radix unsigned /tb_soc/dut/f_win_id /tb_soc/dut/f_pkt /tb_soc/dut/f_port
add wave /tb_soc/dut/a_start /tb_soc/dut/a_busy /tb_soc/dut/a_done
add wave -radix hex /tb_soc/dut/a_feat
add wave -radix unsigned /tb_soc/dut/a_class
add wave -divider "UART / LED / coi"
add wave /tb_soc/uart_txd /tb_soc/buzzer
add wave -radix bin /tb_soc/led

run -all
wave zoom full
