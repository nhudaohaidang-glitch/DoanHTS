# Phần 1 – CPU & tích hợp: IoT Gateway RISC-V (tiến độ tuần 3)

## Đã làm

- **Tuần 1:**
  - Tìm hiểu RV32I, PicoRV32, Wishbone.
  - Sơ đồ khối.
  - Bản đồ địa chỉ.
- **Tuần 2:**
  - Mô phỏng PicoRV32 + RAM + UART.
  - File top cho kit Tang Nano 9K, gán chân, ràng buộc clock 27 MHz.
  - Tổng hợp, dựng file nạp.
- **Tuần 3:**
  - Bus Wishbone và bộ giải mã địa chỉ.
  - Khối thanh ghi cho UART, LED/còi/nút, khối đặc trưng (Phần 3), AI accelerator (Phần 2).
  - Khối giả cho Phần 2 và 3 để thử hệ thống trước.

## Đang làm

Firmware vòng lặp chính. Hiện CPU đã:
- tự kiểm tra lúc khởi động (POST);
- đọc được số liệu từng cửa sổ qua bus và in ra UART.

Còn lại:
- tính đặc trưng, gọi AI;
- lọc cảnh báo;
- gửi kết quả cho ESP32 (các chỗ `TODO` trong `fw/main.c`).

## Cấu trúc thư mục

```
rtl/picorv32.v              Lõi CPU PicoRV32 (YosysHQ, giấy phép ISC)
rtl/soc_top.v               CPU + bus Wishbone + giải mã địa chỉ + các khối ngoại vi
rtl/wb_ram.v, fw_ram.v      RAM firmware 16 KB
rtl/wb_uart.v, uart_tx.v    UART TX
rtl/wb_sys.v                LED, còi, nút S1, bộ đếm chu kỳ, thanh ghi ID
rtl/wb_feat_regs.v          thanh ghi khối đặc trưng (Phần 3)
rtl/wb_ai_regs.v            thanh ghi AI accelerator (Phần 2)
rtl/stubs/                  khối giả cho Phần 2, 3
rtl/board/tangnano9k_top.v  top cho kit
sources.f                   danh sách file RTL
board/                      gán chân, ràng buộc clock, script dựng, file nạp
fw/                         firmware C (đang phát triển)
sim/                        testbench, script ModelSim, cấu hình GTKWave
docs/so_do_khoi.*           sơ đồ khối
```

## Bản đồ địa chỉ

| Địa chỉ       | Khối               | Thanh ghi chính                                      |
|---------------|--------------------|------------------------------------------------------|
| `0x0000_0000` | RAM firmware 16 KB |                                                      |
| `0x1000_0000` | UART TX            | DATA, STATUS                                         |
| `0x2000_0000` | Khối đặc trưng     | STATUS, CTRL, WIN_ID, PKT_CNT, BYTE_SUM, SYN_CNT, SRC_IP, DST_IP, DST_PORT, ERR_CNT |
| `0x3000_0000` | AI accelerator     | STATUS, CTRL, FEAT_LO, FEAT_HI, RESULT, SCORE0–2, LAT |
| `0x4000_0000` | Hệ thống           | LED, CYCLE, BUZZER, BTN, ID, SCRATCH                 |

Bộ giải mã dùng 4 bit cao của địa chỉ. Mỗi khối trả `ack` sau 1 chu kỳ. Vùng không gắn vẫn trả
`ack` để CPU không treo.

## Mô phỏng

**Icarus Verilog** (<https://bleyer.org/icarus/>, khi cài tích *Add to PATH*). Mở cmd trong
thư mục `riscv_sim`:

| Lệnh                | Việc                                                            |
|---------------------|-----------------------------------------------------------------|
| `run_sim.bat board` | top của kit: reset, POST, CPU đọc cửa sổ đầu tiên (~30 giây)    |
| `run_sim.bat`       | toàn hệ thống: CPU đọc 8 cửa sổ liên tiếp qua bus               |
| `run_sim.bat vcd`   | như trên, mở GTKWave với sẵn tín hiệu bus, giải mã, UART, LED   |

**ModelSim / Questa:** *File → Change Directory* tới `riscv_sim`, rồi gõ ở Transcript
`do sim/modelsim_board.do` hoặc `do sim/modelsim_soc.do`.

Kết quả đúng có dòng `KET QUA: PASS`.

## Chạy trên kit

1. Gowin Programmer: **Scan Device** → GW1NR-9C → **SRAM Mode / SRAM Program** → chọn
   `board\prebuilt\tangnano9k.fs` → **Program/Configure**.
2. PuTTY: *Serial*, cổng COM của kit, 115200. Nhấn **S2** để reset, sẽ thấy:

```
# IDS Gateway - PicoRV32 RV32I @ 27 MHz (ban dang phat trien)
# POST OK, AI lat=42 chu ky
# win 0: pkt=163 bytes=78240 syn=9 src=10 dst=5 port=10
# win 1: ...
```

Mỗi giây một dòng, LED0 nhấp nháy theo. Cả 6 LED nhấp nháy đều = CPU lỗi.

Dựng lại bằng Gowin EDA: tạo project chip **GW1NR-LV9QN88PC6/I5**, thêm các file trong
`sources.f` cùng `rtl\board\tangnano9k_top.v`, `board\tangnano9k.cst`, `board\tangnano9k.sdc`.
Sửa `parameter FIRMWARE` trong `tangnano9k_top.v` thành đường dẫn tuyệt đối tới `fw/firmware.hex`.
Chọn Top = `tangnano9k_top`, và tích *Use JTAGSEL_N as regular IO* nếu Gowin báo lỗi chân 4.
Hoặc chạy `gw_sh board\gowin_build.tcl`.

## Việc tiếp theo

- Hoàn thiện firmware: tính đặc trưng, gọi AI, lọc cảnh báo, gửi kết quả cho ESP32.
- Chạy thử trên kit, đo tài nguyên bằng Gowin EDA.
- Ghép khối AI của Phần 2.
