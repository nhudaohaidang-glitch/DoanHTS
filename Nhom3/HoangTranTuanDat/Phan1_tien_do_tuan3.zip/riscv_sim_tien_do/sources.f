# Danh sach file RTL (thu tu bien dich). Khi ghep phan cua nhom:
#   thay rtl/stubs/feat_core_stub.v bang file feat_core cua Phan 3
#   thay rtl/stubs/ai_core_stub.v   bang file ai_core cua Phan 2 (them file con neu co)
rtl/picorv32.v
rtl/fw_ram.v
rtl/uart_tx.v
rtl/wb_ram.v
rtl/wb_uart.v
rtl/wb_sys.v
rtl/wb_feat_regs.v
rtl/wb_ai_regs.v
rtl/soc_top.v
rtl/stubs/feat_core_stub.v
rtl/stubs/ai_core_stub.v
