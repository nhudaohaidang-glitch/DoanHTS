#!/usr/bin/env sh
# Chay mo phong (Linux/WSL/Git Bash). Danh sach file RTL nam trong sources.f
#   ./run_sim.sh          : toan he thong (CPU + bus + khoi gia Phan 2/3), tu kiem tra
#   ./run_sim.sh vcd      : nhu tren, ghi dang song build/tb_soc.vcd
#   ./run_sim.sh board    : top cua kit Tang Nano 9K (UART 115200 that)
set -e
cd "$(dirname "$0")"
mkdir -p build
if [ "$1" = "board" ]; then
    iverilog -g2012 -c sources.f -o build/board.vvp rtl/board/tangnano9k_top.v sim/tb_board.v
    vvp -n build/board.vvp
    exit 0
fi
iverilog -g2012 -c sources.f -o build/sim.vvp sim/tb_soc.v
if [ "$1" = "vcd" ]; then
    vvp -n build/sim.vvp +vcd
    echo "Mo dang song: gtkwave build/tb_soc.vcd sim/tb_soc.gtkw"
else
    vvp -n build/sim.vvp
fi
