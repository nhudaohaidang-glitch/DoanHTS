// =============================================================================
// wb_sys.v - Slave Wishbone: khoi he thong (0x4000_0000)
//   +0x00 LED     (R/W) 6 bit thap, 1 = sang
//   +0x04 CYCLE   (R)   bo dem chu ky clock 32 bit (CLK_HZ lan/giay)
//   +0x08 BUZZER  (R/W) bit0 = muc logic dua ra chan coi
//   +0x0C BTN     (R)   bit0 = 1 khi dang nhan nut S1 (da dong bo, chong rung ~10 ms)
//   +0x10 ID      (R)   0x5256_3332 ("RV32") - de firmware kiem tra bus
//   +0x14 SCRATCH (R/W) thanh ghi thu, khong anh huong gi
// =============================================================================
`timescale 1ns / 1ps
module wb_sys #(
    parameter integer DEBOUNCE_CYC = 270_000          // ~10 ms o 27 MHz
) (
    input  wire        clk,
    input  wire        rst,
    input  wire        stb,
    input  wire        we,
    input  wire [31:0] adr,
    input  wire [3:0]  sel,
    input  wire [31:0] dat_w,
    output reg  [31:0] dat_r,
    output reg         ack,
    output wire [5:0]  led,
    output wire        buzzer,
    input  wire        btn_pressed                    // 1 = dang nhan (chua dong bo)
);
    localparam [31:0] SYS_ID = 32'h5256_3332;

    reg [5:0]  led_reg;
    reg        buz_reg;
    reg [31:0] scratch;
    reg [31:0] cycle_cnt;
    assign led    = led_reg;
    assign buzzer = buz_reg;

    // ------------------------------------------------ Bo dem chu ky
    always @(posedge clk) begin
        if (rst) cycle_cnt <= 32'd0;
        else     cycle_cnt <= cycle_cnt + 32'd1;
    end

    // ------------------------------------------------ Dong bo + chong rung nut bam
    localparam integer DW = (DEBOUNCE_CYC > 1) ? $clog2(DEBOUNCE_CYC) : 1;
    reg [1:0]    btn_sync = 2'b00;
    reg          btn_state;
    reg [DW-1:0] db_cnt;
    always @(posedge clk) begin
        btn_sync <= {btn_sync[0], btn_pressed};
        if (rst) begin
            btn_state <= 1'b0;
            db_cnt    <= {DW{1'b0}};
        end else if (btn_sync[1] == btn_state) begin
            db_cnt <= {DW{1'b0}};
        end else if (db_cnt == DEBOUNCE_CYC - 1) begin
            btn_state <= btn_sync[1];
            db_cnt    <= {DW{1'b0}};
        end else begin
            db_cnt <= db_cnt + 1'b1;
        end
    end

    // ------------------------------------------------ Thanh ghi
    always @(posedge clk) begin
        ack <= 1'b0;
        if (rst) begin
            led_reg <= 6'd0;
            buz_reg <= 1'b0;
            scratch <= 32'd0;
            dat_r   <= 32'd0;
        end else if (stb && !ack) begin
            ack   <= 1'b1;
            dat_r <= 32'd0;
            case (adr[4:2])
                3'd0: begin
                    if (we) led_reg <= dat_w[5:0];
                    dat_r <= {26'd0, led_reg};
                end
                3'd1: dat_r <= cycle_cnt;
                3'd2: begin
                    if (we) buz_reg <= dat_w[0];
                    dat_r <= {31'd0, buz_reg};
                end
                3'd3: dat_r <= {31'd0, btn_state};
                3'd4: dat_r <= SYS_ID;
                3'd5: begin
                    if (we) begin
                        if (sel[0]) scratch[ 7: 0] <= dat_w[ 7: 0];
                        if (sel[1]) scratch[15: 8] <= dat_w[15: 8];
                        if (sel[2]) scratch[23:16] <= dat_w[23:16];
                        if (sel[3]) scratch[31:24] <= dat_w[31:24];
                    end
                    dat_r <= scratch;
                end
                default: ;
            endcase
        end
    end
endmodule
