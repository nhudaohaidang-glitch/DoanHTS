// =============================================================================
// feat_core_stub.v - KHOI GIA cho Phan 3 (trich xuat dac trung + SPI slave)
//
// Dung de thu toan he thong khi chua co khoi that. Khoi nay KHONG doc SPI ma tu
// tao so lieu cua so theo mot kich ban lap lai 16 cua so:
//     N N N N  D D D D  N N N  P P P P  N
//     (N = binh thuong, D = DoS/SYN flood, P = Port Scan)
// gia tri co nhieu ngau nhien (LFSR) de giong luu luong that.
//
// Khi Phan 3 xong: thay file nay bang file chua module feat_core that,
// GIU NGUYEN ten module va danh sach cong ben duoi.
// =============================================================================
`timescale 1ns / 1ps
module feat_core #(
    parameter integer WINDOW_CYCLES = 27_000_000      // do dai cua so (1 s o 27 MHz)
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        enable,        // tu CPU: 1 = hoat dong
    // SPI tu ESP32 (khoi gia khong dung)
    input  wire        spi_sclk,
    input  wire        spi_mosi,
    input  wire        spi_cs_n,
    output wire        spi_miso,
    // ket qua moi cua so: win_valid = xung 1 chu ky, cac gia tri hop le cung chu ky do
    output reg         win_valid,
    output reg  [15:0] win_id,
    output reg  [31:0] pkt_cnt,
    output reg  [31:0] byte_sum,
    output reg  [31:0] syn_cnt,
    output reg  [15:0] src_ip_cnt,
    output reg  [15:0] dst_ip_cnt,
    output reg  [15:0] dst_port_cnt,
    output reg  [15:0] err_cnt
);
    assign spi_miso = 1'b0;

    // kich ban: 0 = N, 1 = D, 2 = P
    function [1:0] scenario;
        input [3:0] idx;
        case (idx)
            4'd4, 4'd5, 4'd6, 4'd7:     scenario = 2'd1;
            4'd11, 4'd12, 4'd13, 4'd14: scenario = 2'd2;
            default:                    scenario = 2'd0;
        endcase
    endfunction

    localparam integer CW = $clog2(WINDOW_CYCLES + 1);
    reg [CW-1:0] tick;
    reg [15:0]   next_id;
    reg [31:0]   lfsr;

    wire [1:0]  sc = scenario(next_id[3:0]);
    // cac so ngau nhien nho lay tu LFSR
    wire [11:0] r12 = lfsr[11:0];
    wire [9:0]  r10 = lfsr[21:12];
    wire [6:0]  r7  = lfsr[28:22];
    wire [3:0]  r4  = lfsr[31:28];

    reg [31:0] n_pkt, n_bytes;

    // tong byte = so goi x kich thuoc TB, tinh bang dich + cong (khong ton bo nhan)
    always @(*) begin
        case (sc)
            2'd1: begin                                  // goi SYN nho: 62 hoac 64 byte
                n_pkt   = 32'd6000 + {20'd0, r12[10:0]};
                n_bytes = (n_pkt << 6) - (r4[0] ? (n_pkt << 1) : 32'd0);
            end
            2'd2: begin                                  // goi SYN nho: 58 hoac 60 byte
                n_pkt   = 32'd500 + {22'd0, r10[8:0]};
                n_bytes = (n_pkt << 6) - (n_pkt << 2) - (r4[1] ? (n_pkt << 1) : 32'd0);
            end
            default: begin                               // goi du lieu: 256..480 byte
                n_pkt   = 32'd96 + {25'd0, r7};
                n_bytes = (n_pkt << 8) + (r10[0] ? (n_pkt << 7) : 32'd0)
                                       + (r10[1] ? (n_pkt << 6) : 32'd0)
                                       + (r10[2] ? (n_pkt << 5) : 32'd0);
            end
        endcase
    end

    always @(posedge clk) begin
        win_valid <= 1'b0;
        if (!rst_n) begin
            tick    <= {CW{1'b0}};
            next_id <= 16'd0;
            lfsr    <= 32'hACE1_2468;
            err_cnt <= 16'd0;
        end else begin
            lfsr <= {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
            if (!enable) begin
                tick <= {CW{1'b0}};
            end else if (tick != WINDOW_CYCLES - 1) begin
                tick <= tick + 1'b1;
            end else begin
                tick      <= {CW{1'b0}};
                win_valid <= 1'b1;
                win_id    <= next_id;
                next_id   <= next_id + 16'd1;
                pkt_cnt   <= n_pkt;
                byte_sum  <= n_bytes;
                case (sc)
                    2'd1: begin                          // SYN flood, IP nguon gia mao
                        syn_cnt      <= n_pkt - {28'd0, r4[2:0]} - 32'd10;
                        src_ip_cnt   <= 16'd150 + {9'd0, r7};
                        dst_ip_cnt   <= 16'd1;
                        dst_port_cnt <= 16'd1 + {15'd0, r4[0]};
                    end
                    2'd2: begin                          // quet nhieu cong tren 1 may
                        syn_cnt      <= n_pkt - {28'd0, r4} - 32'd5;
                        src_ip_cnt   <= 16'd1;
                        dst_ip_cnt   <= 16'd1;
                        dst_port_cnt <= 16'd400 + {7'd0, r10[8:0]};
                    end
                    default: begin                       // luu luong binh thuong
                        syn_cnt      <= 32'd2 + {28'd0, r4[2:0]};
                        src_ip_cnt   <= 16'd3 + {13'd0, r4[2:0]};
                        dst_ip_cnt   <= 16'd2 + {14'd0, r4[1:0]};
                        dst_port_cnt <= 16'd3 + {13'd0, r10[2:0]};
                    end
                endcase
            end
        end
    end
endmodule
