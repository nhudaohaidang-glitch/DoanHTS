// =============================================================================
// ai_core_stub.v - KHOI GIA cho Phan 2 (AI accelerator MLP)
//
// Dung de thu toan he thong khi chua co khoi that. Khoi nay KHONG phai mang no-ron:
// no phan loai bang vai nguong don gian tren dac trung da luong tu hoa, va gia lap
// thoi gian tinh ~40 chu ky giong mot MLP dung chung 1 bo MAC.
//
// Khi Phan 2 xong: thay file nay bang file chua module ai_core that,
// GIU NGUYEN ten module va danh sach cong ben duoi.
//
// Quy uoc dac trung (int8, gia tri 0..127, do firmware luong tu hoa):
//   feat[ 7: 0] f0 = so goi tin          feat[31:24] f3 = so IP nguon khac nhau
//   feat[15: 8] f1 = kich thuoc goi TB   feat[39:32] f4 = so IP dich khac nhau
//   feat[23:16] f2 = ty le goi SYN       feat[47:40] f5 = so cong dich khac nhau
// =============================================================================
`timescale 1ns / 1ps
module ai_core (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,         // xung 1 chu ky; feat giu on dinh tu start den done
    input  wire [47:0] feat,          // 6 x int8
    output wire        busy,          // =1 trong luc dang tinh
    output reg         done,          // xung 1 chu ky khi co ket qua
    output reg  [1:0]  class_id,      // 0 = Binh thuong, 1 = DoS, 2 = Port Scan
    output reg  [47:0] scores         // 3 x 16 bit co dau: [15:0] lop 0, [31:16] lop 1, [47:32] lop 2
);
    localparam integer LATENCY = 40;

    wire [7:0] f_pkt  = feat[ 7: 0];
    wire [7:0] f_syn  = feat[23:16];
    wire [7:0] f_port = feat[47:40];

    reg [5:0] cnt;
    reg       run;
    assign busy = run;

    always @(posedge clk) begin
        done <= 1'b0;
        if (!rst_n) begin
            run      <= 1'b0;
            cnt      <= 6'd0;
            class_id <= 2'd0;
            scores   <= 48'd0;
        end else if (start && !run) begin
            run <= 1'b1;
            cnt <= 6'd0;
        end else if (run) begin
            if (cnt == LATENCY - 1) begin
                run    <= 1'b0;
                done   <= 1'b1;
                scores <= {8'd0, f_port, 8'd0, f_pkt, 8'd0, 8'd127 - f_syn};
                if (f_port >= 8'd48 && f_syn >= 8'd64)
                    class_id <= 2'd2;
                else if (f_pkt >= 8'd88 && f_syn >= 8'd64)
                    class_id <= 2'd1;
                else
                    class_id <= 2'd0;
            end else begin
                cnt <= cnt + 6'd1;
            end
        end
    end
endmodule
