// =============================================================================
// soc_top.v - He thong IoT Gateway phat hien tan cong (Phan 1: CPU + bus + tich hop)
//
//   PicoRV32 (RV32I) --Wishbone--> bo giai ma dia chi --> 5 slave:
//
//   Dia chi       Slave          File                Ghi chu
//   0x0000_0000   RAM 16 KB      wb_ram.v            firmware + du lieu + ngan xep
//   0x1000_0000   UART TX        wb_uart.v           ra USB (debug) va ESP32 (Phan 4)
//   0x2000_0000   Dac trung      wb_feat_regs.v  --> feat_core (Phan 3)
//   0x3000_0000   AI             wb_ai_regs.v    --> ai_core   (Phan 2)
//   0x4000_0000   He thong       wb_sys.v            LED, coi, nut, bo dem chu ky
//   con lai       (khong gan)    -                   doc ra 0, ghi bi bo qua
//
// Bo giai ma dung 4 bit cao cua dia chi. Moi slave tra ack sau 1 chu ky.
// Chi tiet thanh ghi: xem dau moi file wb_*.v va docs/giao_tiep.md.
// =============================================================================
`timescale 1ns / 1ps
module soc_top #(
    parameter integer CLK_HZ       = 27_000_000,
    parameter integer BAUD         = 115_200,
    parameter integer MEM_WORDS    = 4096,           // 16 KB
    parameter         FIRMWARE     = "fw/firmware.hex",
    parameter integer DEBOUNCE_CYC = 270_000         // chong rung nut ~10 ms
) (
    input  wire       clk,
    input  wire       resetn,
    // UART TX: dua ra ca cong USB lan ESP32
    output wire       uart_txd,
    // LED, coi, nut bam
    output wire [5:0] led,          // 1 = sang
    output wire       buzzer,
    input  wire       btn_pressed,  // 1 = dang nhan nut S1
    // SPI tu ESP32 -> feat_core (Phan 3)
    input  wire       spi_sclk,
    input  wire       spi_mosi,
    input  wire       spi_cs_n,
    output wire       spi_miso,
    // CPU loi
    output wire       trap
);
    wire rst = !resetn;

    // ================================================================ CPU (Wishbone master)
    wire [31:0] wb_adr, wb_dat_w;
    wire [31:0] wb_dat_r;
    wire [3:0]  wb_sel;
    wire        wb_we, wb_stb, wb_cyc;
    wire        wb_ack;

    picorv32_wb #(
        .ENABLE_COUNTERS   (0),
        .ENABLE_COUNTERS64 (0),
        .ENABLE_MUL        (0),     // khong dung nhan/chia phan cung: tiet kiem LUT
        .ENABLE_DIV        (0),
        .ENABLE_IRQ        (0),
        .COMPRESSED_ISA    (0),
        .PROGADDR_RESET    (32'h0000_0000)
    ) u_cpu (
        .trap      (trap),
        .wb_rst_i  (rst),
        .wb_clk_i  (clk),
        .wbm_adr_o (wb_adr),
        .wbm_dat_o (wb_dat_w),
        .wbm_dat_i (wb_dat_r),
        .wbm_we_o  (wb_we),
        .wbm_sel_o (wb_sel),
        .wbm_stb_o (wb_stb),
        .wbm_ack_i (wb_ack),
        .wbm_cyc_o (wb_cyc),
        .pcpi_valid (), .pcpi_insn (), .pcpi_rs1 (), .pcpi_rs2 (),
        .pcpi_wr    (1'b0), .pcpi_rd (32'd0), .pcpi_wait (1'b0), .pcpi_ready (1'b0),
        .irq        (32'd0), .eoi (),
        .trace_valid (), .trace_data (),
        .mem_instr  ()
    );

    // ================================================================ Giai ma dia chi
    wire       req      = wb_cyc && wb_stb;
    wire [3:0] region   = wb_adr[31:28];
    wire       stb_ram  = req && (region == 4'h0);
    wire       stb_uart = req && (region == 4'h1);
    wire       stb_feat = req && (region == 4'h2);
    wire       stb_ai   = req && (region == 4'h3);
    wire       stb_sys  = req && (region == 4'h4);
    wire       stb_none = req && (region > 4'h4);

    wire [31:0] dr_ram, dr_uart, dr_feat, dr_ai, dr_sys;
    wire        ack_ram, ack_uart, ack_feat, ack_ai, ack_sys;
    reg         ack_none;

    always @(posedge clk) begin                      // vung khong gan: van tra ack de CPU khong treo
        if (rst) ack_none <= 1'b0;
        else     ack_none <= stb_none && !ack_none;
    end

    assign wb_ack   = ack_ram | ack_uart | ack_feat | ack_ai | ack_sys | ack_none;
    assign wb_dat_r = ack_ram  ? dr_ram  :
                      ack_uart ? dr_uart :
                      ack_feat ? dr_feat :
                      ack_ai   ? dr_ai   :
                      ack_sys  ? dr_sys  : 32'd0;

    // ================================================================ Slave
    wb_ram #(.WORDS(MEM_WORDS), .INIT(FIRMWARE)) u_ram (
        .clk (clk), .rst (rst), .stb (stb_ram), .we (wb_we), .adr (wb_adr),
        .sel (wb_sel), .dat_w (wb_dat_w), .dat_r (dr_ram), .ack (ack_ram)
    );

    wb_uart #(.CLK_HZ(CLK_HZ), .BAUD(BAUD)) u_uart (
        .clk (clk), .rst (rst), .stb (stb_uart), .we (wb_we), .adr (wb_adr),
        .dat_w (wb_dat_w), .dat_r (dr_uart), .ack (ack_uart), .txd (uart_txd)
    );

    wb_sys #(.DEBOUNCE_CYC(DEBOUNCE_CYC)) u_sys (
        .clk (clk), .rst (rst), .stb (stb_sys), .we (wb_we), .adr (wb_adr),
        .sel (wb_sel), .dat_w (wb_dat_w), .dat_r (dr_sys), .ack (ack_sys),
        .led (led), .buzzer (buzzer), .btn_pressed (btn_pressed)
    );

    // ---------------------------------------------------------------- Phan 3: dac trung
    wire        f_enable, f_valid;
    wire [15:0] f_win_id, f_src, f_dst, f_port, f_err;
    wire [31:0] f_pkt, f_bytes, f_syn;

    wb_feat_regs u_feat_regs (
        .clk (clk), .rst (rst), .stb (stb_feat), .we (wb_we), .adr (wb_adr),
        .dat_w (wb_dat_w), .dat_r (dr_feat), .ack (ack_feat),
        .core_enable (f_enable), .win_valid (f_valid), .win_id (f_win_id),
        .pkt_cnt (f_pkt), .byte_sum (f_bytes), .syn_cnt (f_syn),
        .src_ip_cnt (f_src), .dst_ip_cnt (f_dst), .dst_port_cnt (f_port), .err_cnt (f_err)
    );

    feat_core u_feat (
        .clk (clk), .rst_n (resetn), .enable (f_enable),
        .spi_sclk (spi_sclk), .spi_mosi (spi_mosi), .spi_cs_n (spi_cs_n), .spi_miso (spi_miso),
        .win_valid (f_valid), .win_id (f_win_id),
        .pkt_cnt (f_pkt), .byte_sum (f_bytes), .syn_cnt (f_syn),
        .src_ip_cnt (f_src), .dst_ip_cnt (f_dst), .dst_port_cnt (f_port), .err_cnt (f_err)
    );

    // ---------------------------------------------------------------- Phan 2: AI
    wire        a_start, a_busy, a_done;
    wire [47:0] a_feat, a_scores;
    wire [1:0]  a_class;

    wb_ai_regs u_ai_regs (
        .clk (clk), .rst (rst), .stb (stb_ai), .we (wb_we), .adr (wb_adr),
        .sel (wb_sel), .dat_w (wb_dat_w), .dat_r (dr_ai), .ack (ack_ai),
        .core_start (a_start), .core_feat (a_feat), .core_busy (a_busy),
        .core_done (a_done), .core_class (a_class), .core_scores (a_scores)
    );

    ai_core u_ai (
        .clk (clk), .rst_n (resetn), .start (a_start), .feat (a_feat),
        .busy (a_busy), .done (a_done), .class_id (a_class), .scores (a_scores)
    );
endmodule
