// =============================================================================
// wb_feat_regs.v - Slave Wishbone: thanh ghi cua khoi trich xuat dac trung (0x2000_0000)
// Noi CPU voi loi feat_core (Phan 3). Phan 3 KHONG can sua file nay.
//
//   +0x00 STATUS   (R)   bit0 READY   = co cua so moi chua doc
//                        bit1 OVERRUN = co cua so bi bo vi CPU chua doc kip (dinh, xoa bang CTRL)
//   +0x04 CTRL     (R/W) ghi bit0 = 1: ACK, da doc xong -> xoa READY
//                        ghi bit1 = 1: xoa OVERRUN
//                        bit8 ENABLE (R/W, mac dinh 1) -> dua sang feat_core
//   +0x08 WIN_ID   (R)   so thu tu cua so (16 bit)
//   +0x0C PKT_CNT  (R)   so goi tin trong cua so
//   +0x10 BYTE_SUM (R)   tong so byte
//   +0x14 SYN_CNT  (R)   so goi TCP co co SYN
//   +0x18 SRC_IP   (R)   so IP nguon khac nhau
//   +0x1C DST_IP   (R)   so IP dich khac nhau
//   +0x20 DST_PORT (R)   so cong dich khac nhau
//   +0x24 ERR_CNT  (R)   so loi khung SPI (Phan 3 tu dinh nghia, 0 neu khong dung)
//
// Khi feat_core phat win_valid: neu READY = 0 thi chot toan bo gia tri va dat READY;
// neu READY = 1 (CPU chua doc xong cua so truoc) thi bo cua so moi va dat OVERRUN.
// Nho vay CPU luon doc duoc 1 bo so lieu nhat quan.
// =============================================================================
`timescale 1ns / 1ps
module wb_feat_regs (
    input  wire        clk,
    input  wire        rst,
    input  wire        stb,
    input  wire        we,
    input  wire [31:0] adr,
    input  wire [31:0] dat_w,
    output reg  [31:0] dat_r,
    output reg         ack,
    // giao tiep voi feat_core
    output wire        core_enable,
    input  wire        win_valid,
    input  wire [15:0] win_id,
    input  wire [31:0] pkt_cnt,
    input  wire [31:0] byte_sum,
    input  wire [31:0] syn_cnt,
    input  wire [15:0] src_ip_cnt,
    input  wire [15:0] dst_ip_cnt,
    input  wire [15:0] dst_port_cnt,
    input  wire [15:0] err_cnt
);
    reg        ready, overrun, enable;
    reg [15:0] r_win_id, r_src, r_dst, r_port, r_err;
    reg [31:0] r_pkt, r_bytes, r_syn;
    assign core_enable = enable;

    wire wr_ctrl = stb && !ack && we && (adr[5:2] == 4'd1);

    always @(posedge clk) begin
        ack <= 1'b0;
        if (rst) begin
            ready   <= 1'b0;
            overrun <= 1'b0;
            enable  <= 1'b1;
            dat_r   <= 32'd0;
        end else begin
            // ---- chot cua so moi
            if (win_valid) begin
                if (!ready || (wr_ctrl && dat_w[0])) begin
                    r_win_id <= win_id;
                    r_pkt    <= pkt_cnt;
                    r_bytes  <= byte_sum;
                    r_syn    <= syn_cnt;
                    r_src    <= src_ip_cnt;
                    r_dst    <= dst_ip_cnt;
                    r_port   <= dst_port_cnt;
                    r_err    <= err_cnt;
                end else begin
                    overrun  <= 1'b1;
                end
            end
            // ---- bus
            if (stb && !ack) begin
                ack   <= 1'b1;
                dat_r <= 32'd0;
                case (adr[5:2])
                    4'd0: dat_r <= {30'd0, overrun, ready};
                    4'd1: begin
                        if (we) begin
                            enable <= dat_w[8];
                            if (dat_w[1]) overrun <= 1'b0;
                        end
                        dat_r <= {23'd0, enable, 8'd0};
                    end
                    4'd2: dat_r <= {16'd0, r_win_id};
                    4'd3: dat_r <= r_pkt;
                    4'd4: dat_r <= r_bytes;
                    4'd5: dat_r <= r_syn;
                    4'd6: dat_r <= {16'd0, r_src};
                    4'd7: dat_r <= {16'd0, r_dst};
                    4'd8: dat_r <= {16'd0, r_port};
                    4'd9: dat_r <= {16'd0, r_err};
                    default: ;
                endcase
            end
            // ---- READY: dat khi chot duoc cua so, xoa khi CPU ACK
            if (win_valid && (!ready || (wr_ctrl && dat_w[0])))
                ready <= 1'b1;
            else if (wr_ctrl && dat_w[0])
                ready <= 1'b0;
        end
    end
endmodule
