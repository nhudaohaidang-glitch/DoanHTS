// =============================================================================
// tangnano9k_top.v - Top cho kit Sipeed Tang Nano 9K (Gowin GW1NR-LV9QN88PC6/I5)
//
//   Chan   Tin hieu      Huong  Bank/dien ap  Noi voi
//   52     clk_27m       vao    3,3 V         thach anh 27 MHz tren kit
//   4      rst_n         vao    1,8 V         nut S2: nhan = reset CPU
//   3      key_n         vao    1,8 V         nut S1: nhan = tat coi canh bao
//   17     uart_tx       ra     3,3 V         chip USB-UART tren kit -> cong COM (115200 8N1)
//   25     esp_uart_tx   ra     3,3 V         ESP32 chan RX (Phan 4) - cung noi dung voi uart_tx
//   26     buzzer        ra     3,3 V         module coi (muc 1 = keu, doi trong firmware neu can)
//   27     spi_sclk      vao    3,3 V         ESP32 SPI SCK  (Phan 3)
//   28     spi_mosi      vao    3,3 V         ESP32 SPI MOSI (Phan 3)
//   29     spi_cs_n      vao    3,3 V         ESP32 SPI CS   (Phan 3)
//   30     spi_miso      ra     3,3 V         ESP32 SPI MISO (Phan 3, tuy chon)
//   10,11,13-16 led_n    ra     1,8 V         6 LED tren kit, sang khi muc 0
//   Nho noi chung GND giua kit va ESP32.
//
// - Reset: tu dong giu reset ~2,4 ms sau khi nap cau hinh, va khi nhan S2.
// - Neu CPU bi trap (loi), ca 6 LED nhap nhay ~3 Hz.
// =============================================================================
`timescale 1ns / 1ps
module tangnano9k_top #(
    parameter FIRMWARE = "fw/firmware.hex"
) (
    input  wire       clk_27m,
    input  wire       rst_n,
    input  wire       key_n,
    output wire       uart_tx,
    output wire       esp_uart_tx,
    output wire       buzzer,
    input  wire       spi_sclk,
    input  wire       spi_mosi,
    input  wire       spi_cs_n,
    output wire       spi_miso,
    output wire [5:0] led_n
);
    // ---------------------------------------------------------------- Reset
    reg [1:0]  btn_sync = 2'b00;
    reg [15:0] por_cnt  = 16'd0;
    reg        resetn   = 1'b0;

    always @(posedge clk_27m) begin
        btn_sync <= {btn_sync[0], rst_n};
        if (!btn_sync[1]) begin
            por_cnt <= 16'd0;
            resetn  <= 1'b0;
        end else if (por_cnt != 16'hFFFF) begin
            por_cnt <= por_cnt + 16'd1;       // 65535 chu ky ~ 2,4 ms
            resetn  <= 1'b0;
        end else begin
            resetn  <= 1'b1;
        end
    end

    // ---------------------------------------------------------------- He thong
    wire [5:0] led;
    wire       trap, txd;

    soc_top #(
        .CLK_HZ   (27_000_000),
        .BAUD     (115_200),
        .FIRMWARE (FIRMWARE)
    ) u_soc (
        .clk         (clk_27m),
        .resetn      (resetn),
        .uart_txd    (txd),
        .led         (led),
        .buzzer      (buzzer),
        .btn_pressed (!key_n),
        .spi_sclk    (spi_sclk),
        .spi_mosi    (spi_mosi),
        .spi_cs_n    (spi_cs_n),
        .spi_miso    (spi_miso),
        .trap        (trap)
    );

    assign uart_tx     = txd;
    assign esp_uart_tx = txd;

    // ---------------------------------------------------------------- LED
    reg [22:0] blink_cnt = 23'd0;
    always @(posedge clk_27m) blink_cnt <= blink_cnt + 23'd1;

    wire [5:0] led_show = trap ? {6{blink_cnt[22]}} : led;
    assign led_n = ~led_show;                 // LED tren kit sang khi muc 0
endmodule
