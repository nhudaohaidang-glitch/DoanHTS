#!/usr/bin/env sh
# Chay mo phong (Linux/WSL/Git Bash, can Icarus Verilog + Python 3). RTL nam trong sources.f
#   ./run_sim.sh          : toan he thong 40 giay mo phong (~6-10 phut), kiem log bang check_log.py
#   ./run_sim.sh quick    : chay 9 giay de xem log nhanh (khong kiem tra)
#   ./run_sim.sh vcd      : nhu mac dinh, ghi them dang song sim/out/tb_gateway.vcd (file lon)
#   ./run_sim.sh oled     : man OLED (mo hinh SSD1306, doc lai chu tren man)
#   ./run_sim.sh board    : top cua kit voi firmware.hex that (UART 115200, I2C ~90 kHz)
#   ./run_sim.sh mac      : rieng MAC Ethernet Phan 4 (chuyen khung, CRC sai, verdict bo) ~10 giay
#   ./run_sim.sh system   : toan he thong voi MAC THAT, bom khung IPv4/TCP vao cong A (~4 phut)
#   ./run_sim.sh all      : ca 5 bai kiem tra
set -e
cd "$(dirname "$0")"
mkdir -p sim/out
[ -f fw/firmware_sim.hex ] || (cd fw && ./build_fw.sh)

gateway() {
    iverilog -g2012 -o sim/out/tb_gateway.vvp -c sources.f sim/tb_gateway.v
    vvp -n sim/out/tb_gateway.vvp "$@" | tee sim/out/tb_gateway.txt | grep -v '^\[tb\] t='
    python3 tools/check_log.py sim/out/uart.log
}
oled() {
    iverilog -g2012 -o sim/out/tb_oled.vvp -c sources.f sim/ssd1306_model.v sim/tb_oled.v
    vvp -n sim/out/tb_oled.vvp | tee sim/out/tb_oled.txt
}
mac() {
    iverilog -g2012 -o sim/out/tb_eth_mac.vvp rtl/part4_eth/async_fifo.v rtl/part4_eth/rmii_rx.v \
        rtl/part4_eth/rmii_tx.v rtl/part4_eth/eth_mac.v sim/tb_eth_mac.v
    vvp -n sim/out/tb_eth_mac.vvp | tee sim/out/tb_eth_mac.txt
}
system() {
    iverilog -g2012 -o sim/out/tb_system_mac.vvp -c sources.f rtl/board/tangnano9k_top.v sim/tb_system_mac.v
    vvp -n sim/out/tb_system_mac.vvp | tee sim/out/tb_system_mac.txt
}
board() {
    iverilog -g2012 -o sim/out/tb_board.vvp -c sources.f rtl/board/tangnano9k_top.v sim/ssd1306_model.v sim/tb_board.v
    vvp -n sim/out/tb_board.vvp | tee sim/out/tb_board.txt
}
case "$1" in
    quick) iverilog -g2012 -o sim/out/tb_gateway.vvp -c sources.f sim/tb_gateway.v
           vvp -n sim/out/tb_gateway.vvp +stop=9 ;;
    vcd)   gateway +vcd ;;
    oled)  oled ;;
    board) board ;;
    mac)   mac ;;
    system) system ;;
    all)   gateway; oled; board; mac; system ;;
    *)     gateway ;;
esac
