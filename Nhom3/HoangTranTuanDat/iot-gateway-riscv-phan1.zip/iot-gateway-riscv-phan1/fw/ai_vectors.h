/* ai_vectors.h - vector tich hop AI v2 (Phan 2, INTEGRATION_VECTORS.json).
 * Firmware dung luc khoi dong: kiem ai_v2_prepare_window() va AI qua bus.
 * Tu sinh boi tools/gen_tables.py - khong sua tay. */
#ifndef AI_VECTORS_H
#define AI_VECTORS_H
#include <stdint.h>
typedef struct { uint32_t cnt[6]; uint32_t valid; uint32_t feat_lo, feat_hi; int16_t score[3]; uint8_t cls; } ai_vec_t;
#define AI_VEC_N 7
static const ai_vec_t ai_vec[AI_VEC_N] = {
    {{0u, 0u, 0u, 0u, 0u, 0u}, 0, 0x00000000u, 0x0000u, {-1291, -789, 2140}, 2},
    {{16u, 2176u, 2u, 1u, 1u, 1u}, 1, 0x010F4402u, 0x0101u, {5347, -3628, -1545}, 0},
    {{16u, 1040u, 9u, 2u, 1u, 2u}, 1, 0x02472002u, 0x0201u, {547, -189, -227}, 0},
    {{13u, 754u, 6u, 2u, 1u, 6u}, 1, 0x023A1D01u, 0x0601u, {-75, -584, 759}, 2},
    {{28u, 1344u, 21u, 2u, 1u, 1u}, 1, 0x025F1803u, 0x0101u, {-256, 845, -454}, 1},
    {{2000u, 80000u, 1992u, 2u, 1u, 1u}, 1, 0x027E147Fu, 0x0101u, {470, 1802, -2097}, 1},
    {{800u, 32800u, 790u, 2u, 1u, 512u}, 1, 0x027D1464u, 0x7F01u, {-1718, -555, 2332}, 2},
};
#endif
