# Phần 4 – Ethernet MAC RMII và bộ đệm khung: bàn giao cho nhóm
Cập nhật: 01/11/2026.

Phần 4 là cầu nối trong suốt giữa 2 module LAN8720 (RMII 100 Mbps): nhận khung ở cổng A (vùng ngoài) và cổng B (vùng trong), kiểm CRC, giữ trọn khung trong bộ đệm, đưa từng khung lên dòng `frm_*` cho Phần 3 xét, rồi chỉ gửi sang cổng kia những khung được cho qua. Khung giữ nguyên từng byte, kể cả 4 byte FCS. Giao tiếp làm đúng theo tài liệu "Phương án tường lửa Ethernet Tang Nano 9K".

## 1. Đã làm được

| Hạng mục | Trạng thái | Bằng chứng |
| --- | --- | --- |
| Mốc 1: mô hình PHY phát lại file `.pcap` và ghi ra giống hệt | Xong | `tb_phy_loop` PASS 120 khung |
| `rmii_rx`: bỏ preamble, ghép byte, kiểm CRC32, xử lý CRS_DV bật/tắt ở đuôi khung | Xong | `tb_rx` PASS cả cạnh lên và cạnh xuống: 103/103 khung đúng, 17/17 khung sai |
| `rmii_tx` + FIFO bất đồng bộ (Cummings) | Xong | `tb_rxtx` PASS 120/120 khung, 2 clock lệch 100 ppm |
| Bộ đệm khung 4 KB mỗi chiều + bộ quét `frm_*` dùng chung 2 chiều | Xong | `tb_eth_bridge` PASS (xem mục 5) |
| Thử tràn bộ đệm | Xong | `tb_eth_bridge (OVF_TEST)` PASS, 8 lần tràn, khung ra vẫn nguyên vẹn |
| Tổng hợp Gowin EDA (GW1NR-LV9QN88PC6/I5) | Xong, đạt timing | Logic 912/8640 (11%), Register 591 (9%), BSRAM 8/26 (31%); Fmax 65,3 / 88,8 / 91,5 MHz |
| Top thử trên kit `eth_test_top` (cầu nối cho qua hết + 6 LED) | Viết xong, tổng hợp đạt | Chưa nạp vì chưa có module LAN8720 |
| Hình sóng GTKWave cho báo cáo | Xong | Đầu/đuôi khung `rmii_rx`, 4 khung qua cầu nối, chi tiết `frm_eof` → verdict → `b_txen` |
| Nối dây, mốc 2 trên kit | Chưa làm | Đang chờ mua module LAN8720 |

Độ trễ đo trong mô phỏng: từ `frm_eof` tới khi cổng ra bắt đầu phát chỉ khoảng 0,33 µs. Cầu nối "nhận đủ rồi mới chuyển" nên tổng độ trễ một khung bằng thời gian nhận hết khung (5,1 µs với khung 64 byte ở 100 Mbps) cộng khoảng 0,3 µs.

## 2. Bàn giao và việc cần làm theo từng người

### Người 1 – CPU, tích hợp, top, `.cst`, `.sdc`

**Nhận:** 5 file trong `rtl/` (`eth_bridge.v`, `rmii_rx.v`, `rmii_tx.v`, `async_fifo.v`, `frame_buf.v`). Module top là `eth_bridge`. Không cần file nào trong `sim/` để tổng hợp.

**Gắn vào `soc_top`:**

```verilog
eth_bridge #(.RX_EDGE_A(0), .RX_EDGE_B(0)) u_eth (
    .clk(clk_27m), .rst_n(rst_n),
    .a_ref_clk(a_ref_clk), .a_crs_dv(a_crs_dv), .a_rxd(a_rxd), .a_tx_en(a_tx_en), .a_txd(a_txd),
    .b_ref_clk(b_ref_clk), .b_crs_dv(b_crs_dv), .b_rxd(b_rxd), .b_tx_en(b_tx_en), .b_txd(b_txd),
    .frm_valid(frm_valid), .frm_data(frm_data), .frm_sof(frm_sof), .frm_eof(frm_eof),
    .frm_dir(frm_dir), .frm_crc_ok(frm_crc_ok),
    .verdict_valid(verdict_valid), .verdict_drop(verdict_drop),
    .ev_crc_err(ev_crc_err), .ev_overflow(ev_overflow));
```

**Việc cần làm:**

- [ ] Nối bộ đếm: mỗi nhịp `clk_27m`, `CNT_CRC_ERR += ev_crc_err[0] + ev_crc_err[1]`, `CNT_OVERFLOW += ev_overflow[0] + ev_overflow[1]`. Hai tín hiệu này là xung 1 nhịp, bit 0 là khung vào cổng A, bit 1 là cổng B. Tên này tài liệu gốc chưa ghi, Phần 4 tự đặt.
- [ ] Chép phần gán chân RMII từ `board/eth_test.cst` vào `.cst` chung (14 chân, mục 6).
- [ ] Thêm vào `.sdc` chung 2 clock 50 MHz và khai báo 3 clock bất đồng bộ (lấy từ `board/eth_test.sdc`):

  ```
  create_clock -name a_ref_clk -period 20 [get_ports {a_ref_clk}]
  create_clock -name b_ref_clk -period 20 [get_ports {b_ref_clk}]
  set_clock_groups -asynchronous -group [get_clocks {clk_27m}] -group [get_clocks {a_ref_clk}] -group [get_clocks {b_ref_clk}]
  ```

- [ ] Khi tổng hợp sẽ có cảnh báo `PR1014` (REF_CLK cổng B ở chân 63 là chân thường, đi dây thường). Đây là dự kiến; timing riêng Phần 4 vẫn đạt. Kiểm lại timing sau khi ghép cả hệ.
- [ ] Ngân sách tài nguyên: Phần 4 chiếm khoảng 900 logic và **8 BSRAM** (không phải khoảng 4 như tài liệu ước tính, vì mỗi chiều có 2 bản sao bộ đệm để quét và gửi song song).
- [ ] Mốc 3: thay verdict "cho qua hết" của top thử bằng `pkt_filter` của Phần 3.

### Người 3 – `pkt_parser`, `feat_core`, `pkt_filter`

**Nhận:** dòng `frm_*` và yêu cầu trả `verdict_*` (bảng cổng ở mục 4), cùng 2 công cụ dựng testbench: `sim/phy_model.v` và `tools/pcap2hex.py` (mục 5).

**Việc cần làm (cần trả lời Phần 4 trước khi viết code nối vào):**

- [ ] **Mọi khung trên `frm_*` đều cần đúng 1 xung `verdict_valid`**, kể cả khung chiều trong → ngoài (`frm_dir = 1`) và khung không phải IPv4 (ARP...). Khung nào không có verdict trong 4 nhịp sau `frm_eof` bị Phần 4 bỏ. Nếu Phần 3 bỏ qua `frm_dir = 1` thì toàn bộ lưu lượng trả về từ broker sẽ mất. Cách đơn giản: `frm_dir = 1` hoặc không phải IPv4 thì trả `verdict_drop = 0`.
- [ ] `verdict_valid` được đến bất kỳ lúc nào từ `frm_sof` tới 4 nhịp sau `frm_eof` (trả sớm ngay khi đọc xong header cũng được).
- [ ] **Không có `ready`:** trong một khung, byte đến liên tục mỗi nhịp 27 MHz. `pkt_parser` phải nhận được 1 byte mỗi nhịp.
- [ ] `frm_crc_ok` luôn bằng 1 (Phần 4 tự xóa khung CRC sai, Phần 1 đếm qua `ev_crc_err`).
- [ ] `feat_core` đếm trên dòng `frm_*`, tức **trước** `pkt_filter`, để vẫn thấy IP đang bị chặn (yêu cầu trong bàn giao AI v2). Phần 4 đưa mọi khung CRC đúng lên `frm_*` trước khi có verdict nên đáp ứng sẵn.
- [ ] Chốt cách so đặc trưng phần cứng với Python theo cửa sổ 1 giây. Mô hình PHY của Phần 4 phát khung liền nhau, không giữ timestamp của `.pcap`. Chọn một trong hai: (a) Phần 4 thêm vào `pcap2hex.py` tùy chọn tách khung theo `floor(timestamp / 1 s)`; (b) testbench Phần 3 tự kết thúc cửa sổ.

### Người 2 – AI, mốc 0, phần mềm lab

**Nhận:** `tools/pcap2hex.py` chuyển `.pcap` thành dữ liệu mô phỏng cho Phần 1, 3, 4; cách dùng ở mục 5.

**Việc cần làm:**

- [ ] Gửi Phần 4 một file `.pcap` mốc 0 (cả lúc bình thường lẫn lúc thử nghiệm) để chạy mô phỏng cầu nối bằng lưu lượng thật.
- [ ] File phải ghi trên đúng card mạng (không ghi ở giao diện `any`) và **đã tắt gộp gói**: `sudo ethtool -K <card> gro off gso off tso off`. Nếu lúc ghi chưa tắt, `pcap2hex.py` sẽ báo `bo qua N khung > 1518 byte` với N > 0; khi đó số gói và số byte trong dữ liệu huấn luyện AI khác với những gì mạch thật đếm được trên dây.
- [ ] Báo dải IP đã dùng ở mốc 0 để cả nhóm dùng thống nhất ở mốc 2 (hướng dẫn Phần 4 đang dùng 192.168.10.10 / .20 / .50).

### Cả nhóm

- [ ] Xác nhận 3 điểm tài liệu gốc chưa ghi: tên `ev_*` (Người 1), `frm_crc_ok = 1` và quá hạn verdict thì bỏ khung (Người 3), 8 BSRAM (cả nhóm).
- [ ] Tạo kho git chung để Phần 4 đẩy nhánh `phan4` lên.
- [ ] Giữ hạn chốt bước 2c đã ghi ở mốc 1; quá hạn mà chưa đạt thì chuyển sang phương án dự phòng.

## 3. Phần 4 còn làm tiếp

1. Mua 3 module LAN8720 (2 dùng, 1 dự phòng; loại có bộ dao động 50 MHz và chân `nINT/RETCLK`).
2. Nối dây, kiểm liên kết 100 Mbps Full.
3. Nạp `eth_test_top`, làm mốc 2: ping qua cầu nối, iperf3 UDP 80 Mbit/s trong 60 s không mất gói; chọn cạnh lấy mẫu cổng B (`RX_EDGE_B`).
4. Chạy mô phỏng với `.pcap` mốc 0 khi Người 2 gửi.
5. Hỗ trợ Người 1, Người 3 ghép ở mốc 3.

## 4. Giao tiếp của `eth_bridge`

### Tham số

| Tham số | Mặc định | Ý nghĩa |
| --- | --- | --- |
| `RX_EDGE_A` | 0 | Cạnh lấy mẫu RXD/CRS_DV cổng A: 0 = cạnh lên, 1 = cạnh xuống |
| `RX_EDGE_B` | 0 | Như trên, cổng B; chốt bằng thử trên kit |
| `BUF_AW` | 12 | Bộ đệm mỗi chiều 2^BUF_AW byte (12 = 4 KB, giữ được 2 khung 1518 byte) |

### Cổng

| Tín hiệu | Chiều | Rộng | Miền clock | Ý nghĩa |
| --- | --- | --- | --- | --- |
| `clk` | vào | 1 | – | clk_27m của hệ thống |
| `rst_n` | vào | 1 | bất kỳ | Reset mức thấp, đồng bộ bên trong cho cả 3 miền |
| `a_ref_clk`, `a_crs_dv`, `a_rxd[1:0]` | vào | | a_ref_clk | Từ LAN8720 cổng A (vùng ngoài) |
| `a_tx_en`, `a_txd[1:0]` | ra | | a_ref_clk | Tới LAN8720 cổng A |
| `b_ref_clk`, `b_crs_dv`, `b_rxd[1:0]` | vào | | b_ref_clk | Từ LAN8720 cổng B (vùng trong) |
| `b_tx_en`, `b_txd[1:0]` | ra | | b_ref_clk | Tới LAN8720 cổng B |
| `frm_valid` | ra | 1 | clk_27m | Nhịp này có 1 byte |
| `frm_data` | ra | 8 | clk_27m | Từ byte đầu MAC đích tới byte cuối FCS |
| `frm_sof` | ra | 1 | clk_27m | Cùng byte đầu khung |
| `frm_eof` | ra | 1 | clk_27m | Cùng byte cuối khung |
| `frm_dir` | ra | 1 | clk_27m | 0 = ngoài -> trong (A sang B), 1 = trong -> ngoài; giữ nguyên suốt một khung |
| `frm_crc_ok` | ra | 1 | clk_27m | Luôn = 1 |
| `verdict_valid` | vào | 1 | clk_27m | Xung 1 nhịp, đúng 1 lần mỗi khung |
| `verdict_drop` | vào | 1 | clk_27m | 1 = bỏ khung, 0 = cho qua; chỉ đọc tại xung `verdict_valid` |
| `ev_crc_err` | ra | 2 | clk_27m | Xung 1 nhịp mỗi khung CRC sai; bit 0 = cổng A, bit 1 = cổng B |
| `ev_overflow` | ra | 2 | clk_27m | Xung 1 nhịp mỗi khung bị bỏ vì bộ đệm đầy; bit 0 = cổng A, bit 1 = cổng B |

### Đường dữ liệu

```
          a_ref_clk 50 MHz               clk_27m                     b_ref_clk 50 MHz
cổng A -> rmii_rx -> async_fifo -> frame_buf A ------------> async_fifo -> rmii_tx -> cổng B
                                      |    ^
                         frm_* <------+    +------ verdict_*          (Phần 3)
                         ev_*  -> Phần 1 (bộ đếm)
cổng A <- rmii_tx <- async_fifo <------------ frame_buf B <- async_fifo <- rmii_rx <- cổng B
```

Mỗi chiều qua 3 miền clock, chỉ qua FIFO bất đồng bộ. `frame_buf` chỉ gửi khung đã nhận đủ, CRC đúng và có verdict cho qua; khung CRC sai hoặc bị tràn bị xóa bằng cách lùi con trỏ ghi. Hai chiều dùng chung dòng `frm_*`, bộ quét lấy lần lượt từng khung, xen kẽ 2 chiều.

## 5. Mô phỏng và công cụ dùng chung

Cần `iverilog` (đã thử bản 12.0), `python3`, `scapy` (`sudo apt install python3-scapy`).

```bash
cd sim
./run_sim.sh                 # tạo lưu lượng thử rồi chạy 5 test
./run_sim.sh file_that.pcap  # dùng .pcap thật cho cổng A (cắt ngắn trước: editcap -r goc.pcap ngan.pcap 1-2000)
```

Kết quả đúng:

```
PASS tb_phy_loop: 120 khung
PASS tb_rx
PASS tb_rxtx
A->B: vao 120, len frm_* 103/103, ra cong B 61/61 (thieu 0)
B->A: vao 120, len frm_* 110/110, ra cong A 110/110
CRC sai 27/27, tran bo dem 0, loi dong frm_* 0, loi PHY 0
PASS tb_eth_bridge
PASS tb_eth_bridge (OVF_TEST)
```

`tb_eth_bridge` thử khung 64 tới 1522 byte (có VLAN), ARP, khung CRC sai, CRS_DV bật/tắt như LAN8720 thật, cổng B lấy mẫu cạnh xuống với clock chậm hơn 100 ppm, và một Phần 3 giả bỏ khung IPv4 có IP nguồn 192.168.10.50 (`0xC0A80A32`), trả verdict ngẫu nhiên giữa khung hoặc 1–4 nhịp sau `frm_eof`.

**`tools/pcap2hex.py`**: `python3 pcap2hex.py vao.pcap X [--block IP] [--corrupt N]`. Ra `X.hex` (mọi khung), `X_pass.hex` (khung phải qua), `X.lst` (mã từng khung: 0 qua, 1 bị chặn, 2 CRC sai; dòng cuối `f`). Mỗi dòng hex là 1 byte dạng `{eof, byte}`, ví dụ `0ff`, `1ec`; dòng `200` là hết file. Tự đệm khung lên 60 byte và thêm FCS.

**`sim/phy_model.v`**: đặt ở mỗi cổng RMII trong testbench.

| Tham số | Ý nghĩa |
| --- | --- |
| `IN_HEX` | File hex để phát vào FPGA (`crs_dv`, `rxd`) |
| `EXP_HEX` | File hex khung mong đợi; mỗi khung nhận từ `tx_en`/`txd` được so từng byte |
| `OUT_HEX` | Ghi khung nhận được ra file (gọi task `close_out` ở cuối) |
| `REAL` | 1 = giống chip thật (preamble ngắn bớt, CRS_DV bật/tắt ở đuôi khung) |
| `GAP` | Khoảng nghỉ tối thiểu giữa 2 khung phát ra (nhịp), mặc định 48 |
| `ALLOW_SKIP` | 1 = cho phép thiếu khung mong đợi (thử tràn) |

Testbench đọc kết quả qua `ntx`, `nrx`, `nexp`, `nerr`, `tx_done` của mô hình.

## 6. Tổng hợp và thử trên kit

Gowin EDA, chip GW1NR-LV9QN88PC6/I5, top `eth_test_top`, file `rtl/*.v` + `board/*`.

| Tài nguyên | Dùng | Tỉ lệ |
| --- | --- | --- |
| Logic | 912 / 8640 (546 LUT + 246 ALU + 20 RAM16) | 11% |
| Register | 591 / 6693 | 9% |
| BSRAM | 8 / 26 | 31% |

| Clock | Yêu cầu | Fmax sau Place & Route |
| --- | --- | --- |
| clk_27m | 27 MHz | 65,3 MHz |
| a_ref_clk | 50 MHz | 88,8 MHz |
| b_ref_clk | 50 MHz | 91,5 MHz |

Tổng slack âm setup và hold bằng 0 ở cả 3 clock; slack hold nhỏ nhất +0,476 ns. Số trên tính cả top thử có LED, chưa có CPU, Phần 3 và AI.

**Top thử `board/eth_test_top.v`** (verdict luôn cho qua; nút S2 chân 4 là reset):

| LED (chân) | Báo gì | Bình thường |
| --- | --- | --- |
| LED0 (10) | REF_CLK cổng A | Đổi sáng/tắt mỗi giây |
| LED1 (11) | REF_CLK cổng B | Đổi sáng/tắt mỗi giây |
| LED2 (13) | Có khung A -> B | Chớp khi có lưu lượng ngoài -> trong |
| LED3 (14) | Có khung B -> A | Chớp khi có lưu lượng trong -> ngoài |
| LED4 (15) | Đã có khung CRC sai (giữ tới khi nhấn S2) | Tắt; sáng thì đổi `RX_EDGE` của cổng đó |
| LED5 (16) | Bộ đệm đã tràn (giữ tới khi nhấn S2) | Tắt |

**Chân RMII** (theo "Sơ đồ nối dây" của tài liệu nhóm; MDIO/MDC không nối):

| Tín hiệu | Cổng A | Cổng B |
| --- | --- | --- |
| REF_CLK (nINT/RETCLK) | 35 (GCLKT_4) | 63 |
| CRS_DV | 27 | 77 |
| RXD0, RXD1 | 28, 29 | 76, 48 |
| TX_EN | 30 | 49 |
| TXD0, TXD1 | 33, 34 | 31, 32 |

Để laptop tự thỏa thuận tốc độ; không ép 100 Mbps Full chỉ ở phía laptop.

## 7. Giới hạn đã biết

- Chỉ hỗ trợ 100 Mbps; liên kết rơi về 10 Mbps thì MAC nhận sai.
- `.sdc` chưa khai báo độ trễ chân vào/ra RMII, nên báo cáo timing chỉ kiểm đường bên trong chip; cạnh lấy mẫu cổng B chốt bằng thử trên kit (LED4).
- Dòng `frm_*` chung 2 chiều chạy tối đa 27 MB/s; khi cả 2 chiều cùng đầy 100 Mbps (25 MB/s) chỉ còn dư khoảng 8%. Quá tải thì bộ đệm tràn và được đếm qua `ev_overflow`.
- Hai máy gửi/nhận lệch clock tới khoảng 100 ppm, nên chạy kịch trần lâu có thể hiếm khi tràn bộ đệm.
- Mô hình PHY phát khung liền nhau, không giữ timestamp: mô phỏng không có ranh giới cửa sổ 1 giây.

## 8. Cấu trúc thư mục

```
rtl/        eth_bridge.v (top), rmii_rx.v, rmii_tx.v, async_fifo.v, frame_buf.v
board/      eth_test_top.v, eth_test.cst, eth_test.sdc   (top thử trên kit)
sim/        phy_model.v, tb_phy_loop.v, tb_phy_tx.v, tb_rx.v, tb_rxtx.v,
            tb_eth_bridge.v, gen_test_pcap.py, run_sim.sh
tools/      pcap2hex.py
```
