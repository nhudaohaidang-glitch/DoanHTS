// eth_test.sdc - rang buoc clock, chep tu tai lieu nhom (board/tangnano9k.sdc)
create_clock -name clk_27m -period 37.037 [get_ports {clk_27m}]
create_clock -name a_ref_clk -period 20 [get_ports {a_ref_clk}]
create_clock -name b_ref_clk -period 20 [get_ports {b_ref_clk}]
set_clock_groups -asynchronous -group [get_clocks {clk_27m}] -group [get_clocks {a_ref_clk}] -group [get_clocks {b_ref_clk}]
