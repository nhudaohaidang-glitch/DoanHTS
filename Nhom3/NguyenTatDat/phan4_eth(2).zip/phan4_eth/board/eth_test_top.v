// eth_test_top.v - top thu Phan 4 tren kit (buoc 8), chua co CPU va Phan 3:
// cau noi cho qua het (verdict luon = cho qua, ngay o nhip frm_eof), tinh trang hien len 6 LED.
// LED tren kit sang khi chan = 0.
//   LED0, LED1: nhay 1 Hz neu REF_CLK cong A, cong B dung 50 MHz (khong nhay = dut day/nham chan)
//   LED2, LED3: sang 0,1 s moi khi co khung A -> B, B -> A di qua
//   LED4: sang mai khi co khung CRC sai (cong nao cung vay) -> doi RX_EDGE cua cong do
//   LED5: sang mai khi bo dem tran
// Nut S2 (chan 4) = reset, nhan de xoa LED4, LED5.
module eth_test_top #(
    parameter RX_EDGE_A = 0,
    parameter RX_EDGE_B = 0
) (
    input        clk_27m,
    input        rst_n,
    input        a_ref_clk, a_crs_dv,
    input  [1:0] a_rxd,
    output       a_tx_en,
    output [1:0] a_txd,
    input        b_ref_clk, b_crs_dv,
    input  [1:0] b_rxd,
    output       b_tx_en,
    output [1:0] b_txd,
    output [5:0] led
);
    wire       fv, feof, fdir;
    wire [1:0] crc, ovf;
    eth_bridge #(.RX_EDGE_A(RX_EDGE_A), .RX_EDGE_B(RX_EDGE_B)) u_br (
        .clk(clk_27m), .rst_n(rst_n),
        .a_ref_clk(a_ref_clk), .a_crs_dv(a_crs_dv), .a_rxd(a_rxd), .a_tx_en(a_tx_en), .a_txd(a_txd),
        .b_ref_clk(b_ref_clk), .b_crs_dv(b_crs_dv), .b_rxd(b_rxd), .b_tx_en(b_tx_en), .b_txd(b_txd),
        .frm_valid(fv), .frm_data(), .frm_sof(), .frm_eof(feof), .frm_dir(fdir), .frm_crc_ok(),
        .verdict_valid(fv & feof), .verdict_drop(1'b0),
        .ev_crc_err(crc), .ev_overflow(ovf));

    // 1 Hz tu moi REF_CLK: dao trang thai moi 25 000 000 canh
    reg [24:0] ca = 0, cb = 0;
    reg        ba = 0, bb = 0;
    always @(posedge a_ref_clk) if (ca == 25'd24_999_999) begin ca <= 0; ba <= ~ba; end else ca <= ca + 1'b1;
    always @(posedge b_ref_clk) if (cb == 25'd24_999_999) begin cb <= 0; bb <= ~bb; end else cb <= cb + 1'b1;

    // keo dai moi khung thanh 0,1 s (2 700 000 nhip 27 MHz) de mat nhin thay; giu loi den khi reset
    reg [21:0] sa = 0, sb = 0;
    reg        e_crc = 0, e_ovf = 0;
    always @(posedge clk_27m) begin
        if (fv && feof && !fdir) sa <= 22'd2_700_000; else if (sa != 0) sa <= sa - 1'b1;
        if (fv && feof &&  fdir) sb <= 22'd2_700_000; else if (sb != 0) sb <= sb - 1'b1;
        if (!rst_n) begin e_crc <= 0; e_ovf <= 0; end
        else begin
            if (crc != 0) e_crc <= 1;
            if (ovf != 0) e_ovf <= 1;
        end
    end

    assign led = ~{e_ovf, e_crc, sb != 0, sa != 0, bb, ba};
endmodule
