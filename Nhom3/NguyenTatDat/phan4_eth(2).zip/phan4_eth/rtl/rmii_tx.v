// rmii_tx.v - phat RMII 100 Mbps (mien REF_CLK 50 MHz).
// Lay khung tu FIFO ({eof, data}, xem truoc), phat 7 x 0x55 + 0xD5, cac byte (dibit thap truoc),
// roi giu TX_EN = 0 it nhat 48 nhip (96 bit). Khong tinh CRC: khung giu nguyen FCS cu.
module rmii_tx (
    input            ref_clk,
    input            rst_n,         // da dong bo vao ref_clk
    input            fifo_empty,
    input      [8:0] fifo_data,     // {eof, data[7:0]}
    output           fifo_rd,
    output reg       tx_en,
    output reg [1:0] txd
);
    localparam IDLE = 2'd0, PRE = 2'd1, DATA = 2'd2, IFG = 2'd3;
    reg [1:0] st;
    reg [5:0] n;
    reg [7:0] b;
    reg       last;

    assign fifo_rd = (st == DATA) && (n == 0) && !fifo_empty;

    always @(posedge ref_clk) begin
        if (!rst_n) begin
            st <= IDLE; tx_en <= 1'b0; txd <= 2'b00;
        end else case (st)
            IDLE: if (!fifo_empty) begin st <= PRE; n <= 0; end
            PRE: begin
                tx_en <= 1'b1;
                txd   <= (n == 31) ? 2'b11 : 2'b01;
                n     <= (n == 31) ? 6'd0 : n + 1'b1;
                if (n == 31) st <= DATA;
            end
            DATA: if (n == 0) begin
                if (fifo_empty) begin                     // khong xay ra neu phia truoc kip day du lieu
                    tx_en <= 1'b0; st <= IFG; n <= 0;     // cat khung; ben nhan se thay sai CRC
                end else begin
                    {last, b} <= fifo_data;
                    txd <= fifo_data[1:0];
                    n   <= 1;
                end
            end else begin
                txd <= b[2*n[1:0] +: 2];
                n   <= (n == 3) ? 6'd0 : n + 1'b1;
                if (n == 3 && last) st <= IFG;
            end
            IFG: begin
                tx_en <= 1'b0; txd <= 2'b00;
                n <= n + 1'b1;
                if (n == 47) st <= IDLE;
            end
        endcase
    end
endmodule
