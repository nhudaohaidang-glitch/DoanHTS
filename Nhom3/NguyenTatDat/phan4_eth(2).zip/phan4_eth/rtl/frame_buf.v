// frame_buf.v - bo dem khung cho 1 chieu (mien clk_27m).
// Ghi: lay byte tu FIFO nhan; khung CRC sai hoac tran bo dem -> lui con tro ghi (xoa ca khung).
// Quet: dua tung khung da nhan du sang dong frm_* (eth_bridge chon chieu).
// Gui: chi doc khung da co verdict; verdict = bo thi bo qua khung, cho qua thi day sang FIFO gui.
// Hai ban sao giong het (mem_s cho quet, mem_t cho gui) de moi BSRAM chi co 1 ghi + 1 doc.
module frame_buf #(
    parameter AW = 12               // 2^AW byte = 4 KB, giu duoc 2 khung 1518 byte
) (
    input            clk,
    input            rst_n,
    // tu FIFO nhan, xem truoc
    input            rx_empty,
    input      [9:0] rx_word,       // {crc_ok, eof, data}
    output           rx_rd,
    // quet
    output           scan_avail,    // co it nhat 1 khung du, CRC dung, chua quet
    input            scan_en,       // doc 1 byte/nhip; eth_bridge ha ngay khi thay eof o scan_q
    output reg [8:0] scan_q,        // {eof, data}, co sau scan_en 1 nhip
    // verdict cua khung vua quet
    output           vf_full,
    input            vf_push,
    input            vf_drop,
    // sang FIFO gui
    input            tx_full,
    output           tx_wr,
    output     [8:0] tx_word,       // {eof, data}
    // xung dem 1 nhip
    output reg       ev_crc_err,
    output reg       ev_overflow
);
    localparam DEPTH = 1 << AW;
    reg [8:0]  mem_s [0:DEPTH-1];
    reg [8:0]  mem_t [0:DEPTH-1];
    reg [AW:0] wp, wc, sp, tp;      // con tro ghi, ghi da chot, quet, gui
    reg        ovf;                 // khung dang ghi da bi tran

    // ---- ghi ----
    wire eof  = rx_word[8];
    wire ok   = rx_word[9];
    wire [AW:0] used = wp - tp;     // phep tru AW+1 bit; viet thang (wp - tp) != DEPTH se tinh 32 bit, sai khi wp quay vong
    wire room = !used[AW];
    wire wr   = rx_rd && room && !ovf;
    assign rx_rd = !rx_empty;

    always @(posedge clk) if (wr) begin
        mem_s[wp[AW-1:0]] <= rx_word[8:0];
        mem_t[wp[AW-1:0]] <= rx_word[8:0];
    end

    always @(posedge clk) begin
        ev_crc_err <= 1'b0; ev_overflow <= 1'b0;
        if (!rst_n) begin
            wp <= 0; wc <= 0; ovf <= 1'b0;
        end else if (rx_rd) begin
            if (eof) begin
                if (wr && ok) begin wp <= wp + 1'b1; wc <= wp + 1'b1; end
                else wp <= wc;
                ev_crc_err  <= !ok;
                ev_overflow <= !wr;
                ovf <= 1'b0;
            end else if (wr) wp <= wp + 1'b1;
            else ovf <= 1'b1;
        end
    end

    // ---- quet ----
    assign scan_avail = sp != wc;
    always @(posedge clk) begin
        scan_q <= mem_s[sp[AW-1:0]];
        if (!rst_n) sp <= 0;
        else if (scan_en) sp <= sp + 1'b1;
    end

    // ---- hang verdict, 1 bit/khung ----
    reg        vf [0:63];           // mang 64 x 1 -> RAM phan tan (LUT), nho hon thanh ghi 64 bit
    reg [6:0]  vw, vr;
    assign vf_full = (vw - vr) == 7'd64;
    always @(posedge clk)
        if (!rst_n) vw <= 0;
        else if (vf_push) begin vf[vw[5:0]] <= vf_drop; vw <= vw + 1'b1; end

    // ---- gui: 1 byte / 2 nhip = 13,5 MB/s > 12,5 MB/s cua duong truyen ----
    reg [1:0] ts;
    reg       drop;
    reg [8:0] tq;
    always @(posedge clk) tq <= mem_t[tp[AW-1:0]];
    assign tx_wr   = (ts == 2) && !drop;
    assign tx_word = tq;

    always @(posedge clk) begin
        if (!rst_n) begin
            ts <= 0; tp <= 0; vr <= 0;
        end else case (ts)
            0: if (vw != vr) begin drop <= vf[vr[5:0]]; vr <= vr + 1'b1; ts <= 1; end
            1: if (drop || !tx_full) ts <= 2;           // tq = mem_t[tp] o nhip sau
            2: begin tp <= tp + 1'b1; ts <= tq[8] ? 2'd0 : 2'd1; end
            default: ts <= 0;
        endcase
    end
endmodule
