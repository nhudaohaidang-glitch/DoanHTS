// eth_bridge.v - top cua Phan 4: cau noi trong suot 2 cong RMII, dua khung cho Phan 3 xet.
// Giao tiep dung muc "Giao tiep giua cac phan": frm_* va verdict_* o mien clk_27m.
//   frm_*: ca 2 chieu chung 1 dong, tung khung tron ven (khong xen byte 2 khung), frm_dir phan biet.
//   Chi khung CRC dung moi len dong frm_* (khung CRC sai Phan 4 tu xoa), nen frm_crc_ok luon = 1.
//   Phan 4 cho verdict toi 4 nhip sau frm_eof; qua han thi bo khung.
// Duong di: rmii_rx -> async_fifo (50 -> 27) -> frame_buf -> async_fifo (27 -> 50) -> rmii_tx.
module eth_bridge #(
    parameter RX_EDGE_A = 0,        // canh lay mau RX cong A: 0 = len, 1 = xuong
    parameter RX_EDGE_B = 0,
    parameter BUF_AW    = 12        // bo dem moi chieu 2^BUF_AW byte
) (
    input        clk,               // clk_27m
    input        rst_n,
    // cong A (vung ngoai)
    input        a_ref_clk,
    input        a_crs_dv,
    input  [1:0] a_rxd,
    output       a_tx_en,
    output [1:0] a_txd,
    // cong B (vung trong)
    input        b_ref_clk,
    input        b_crs_dv,
    input  [1:0] b_rxd,
    output       b_tx_en,
    output [1:0] b_txd,
    // Phan 4 -> Phan 3
    output       frm_valid,
    output [7:0] frm_data,
    output       frm_sof,
    output       frm_eof,
    output       frm_dir,           // 0 = ngoai -> trong (A sang B), 1 = trong -> ngoai
    output       frm_crc_ok,
    // Phan 3 -> Phan 4
    input        verdict_valid,
    input        verdict_drop,
    // Phan 4 -> Phan 1 (CNT_CRC_ERR, CNT_OVERFLOW): xung 1 nhip, bit 0 = khung vao cong A, bit 1 = cong B
    output [1:0] ev_crc_err,
    output [1:0] ev_overflow
);
    // ---- (1) reset: vao bat dong bo, nha dong bo trong tung mien ----
    reg [1:0] rs, ra, rb;
    always @(posedge clk       or negedge rst_n) if (!rst_n) rs <= 2'b00; else rs <= {rs[0], 1'b1};
    always @(posedge a_ref_clk or negedge rst_n) if (!rst_n) ra <= 2'b00; else ra <= {ra[0], 1'b1};
    always @(posedge b_ref_clk or negedge rst_n) if (!rst_n) rb <= 2'b00; else rb <= {rb[0], 1'b1};
    wire srst_n = rs[1], arst_n = ra[1], brst_n = rb[1];

    // ---- (2) chieu A -> B va B -> A ----
    wire       rxv_a, rxv_b, rxe_a, rxe_b, rxr_a, rxr_b;
    wire [9:0] rxw_a, rxw_b, rxq_a, rxq_b;
    wire       txe_a, txe_b, txr_a, txr_b, txf_a, txf_b, txw_a, txw_b;
    wire [8:0] txq_a, txq_b, txd_a, txd_b;
    wire       av_a, av_b, se_a, se_b, vff_a, vff_b, vp_a, vp_b;
    wire [8:0] sq_a, sq_b;
    reg        vdrop;

    rmii_rx #(.RX_EDGE(RX_EDGE_A)) u_rx_a (.ref_clk(a_ref_clk), .rst_n(arst_n),
        .crs_dv(a_crs_dv), .rxd(a_rxd), .out_valid(rxv_a), .out_word(rxw_a));
    rmii_rx #(.RX_EDGE(RX_EDGE_B)) u_rx_b (.ref_clk(b_ref_clk), .rst_n(brst_n),
        .crs_dv(b_crs_dv), .rxd(b_rxd), .out_valid(rxv_b), .out_word(rxw_b));

    async_fifo #(.DW(10)) u_rf_a (.wclk(a_ref_clk), .wrst_n(arst_n), .winc(rxv_a), .wdata(rxw_a), .wfull(),
        .rclk(clk), .rrst_n(srst_n), .rinc(rxr_a), .rdata(rxq_a), .rempty(rxe_a));
    async_fifo #(.DW(10)) u_rf_b (.wclk(b_ref_clk), .wrst_n(brst_n), .winc(rxv_b), .wdata(rxw_b), .wfull(),
        .rclk(clk), .rrst_n(srst_n), .rinc(rxr_b), .rdata(rxq_b), .rempty(rxe_b));

    frame_buf #(.AW(BUF_AW)) u_buf_a (.clk(clk), .rst_n(srst_n),
        .rx_empty(rxe_a), .rx_word(rxq_a), .rx_rd(rxr_a),
        .scan_avail(av_a), .scan_en(se_a), .scan_q(sq_a),
        .vf_full(vff_a), .vf_push(vp_a), .vf_drop(vdrop),
        .tx_full(txf_b), .tx_wr(txw_b), .tx_word(txd_b),
        .ev_crc_err(ev_crc_err[0]), .ev_overflow(ev_overflow[0]));
    frame_buf #(.AW(BUF_AW)) u_buf_b (.clk(clk), .rst_n(srst_n),
        .rx_empty(rxe_b), .rx_word(rxq_b), .rx_rd(rxr_b),
        .scan_avail(av_b), .scan_en(se_b), .scan_q(sq_b),
        .vf_full(vff_b), .vf_push(vp_b), .vf_drop(vdrop),
        .tx_full(txf_a), .tx_wr(txw_a), .tx_word(txd_a),
        .ev_crc_err(ev_crc_err[1]), .ev_overflow(ev_overflow[1]));

    async_fifo #(.DW(9)) u_tf_b (.wclk(clk), .wrst_n(srst_n), .winc(txw_b), .wdata(txd_b), .wfull(txf_b),
        .rclk(b_ref_clk), .rrst_n(brst_n), .rinc(txr_b), .rdata(txq_b), .rempty(txe_b));
    async_fifo #(.DW(9)) u_tf_a (.wclk(clk), .wrst_n(srst_n), .winc(txw_a), .wdata(txd_a), .wfull(txf_a),
        .rclk(a_ref_clk), .rrst_n(arst_n), .rinc(txr_a), .rdata(txq_a), .rempty(txe_a));

    rmii_tx u_tx_b (.ref_clk(b_ref_clk), .rst_n(brst_n), .fifo_empty(txe_b), .fifo_data(txq_b),
        .fifo_rd(txr_b), .tx_en(b_tx_en), .txd(b_txd));
    rmii_tx u_tx_a (.ref_clk(a_ref_clk), .rst_n(arst_n), .fifo_empty(txe_a), .fifo_data(txq_a),
        .fifo_rd(txr_a), .tx_en(a_tx_en), .txd(a_txd));

    // ---- (3) bo quet: lay tung khung, xen ke 2 chieu, dua len frm_* roi cho verdict ----
    reg       busy, dir, qv, first, waitv, got, gdrop;
    reg [1:0] tmo;
    wire [8:0] q       = dir ? sq_b : sq_a;
    wire       eof_out = qv && q[8];                    // byte cuoi dang o dau ra
    wire       run     = busy && !waitv && !eof_out;    // = scan_en cua chieu dang chon
    wire       ok_a    = av_a && !vff_a, ok_b = av_b && !vff_b;
    wire       done    = waitv && (got || verdict_valid || tmo == 3);
    assign se_a = run && !dir;
    assign se_b = run &&  dir;
    assign vp_a = done && !dir;
    assign vp_b = done &&  dir;

    // ---- (4) dau ra ----
    assign frm_valid  = qv;
    assign frm_data   = q[7:0];
    assign frm_sof    = qv && first;
    assign frm_eof    = eof_out;
    assign frm_dir    = dir;
    assign frm_crc_ok = 1'b1;

    always @(*) vdrop = got ? gdrop : (verdict_valid ? verdict_drop : 1'b1);  // het han = bo

    always @(posedge clk) begin
        if (!srst_n) begin
            busy <= 0; dir <= 1; qv <= 0; waitv <= 0; got <= 0;
        end else if (!busy) begin
            if (ok_a || ok_b) begin
                dir   <= dir ? !ok_a : ok_b;             // uu tien chieu kia neu ca 2 cung co khung
                busy  <= 1; first <= 1; got <= 0;
            end
        end else begin
            qv <= run;
            if (qv) first <= 0;
            if (verdict_valid) begin got <= 1; gdrop <= verdict_drop; end   // verdict den truoc frm_eof
            if (eof_out) begin waitv <= 1; tmo <= 0; end
            if (waitv) tmo <= tmo + 1'b1;
            if (done) begin busy <= 0; waitv <= 0; end
        end
    end
endmodule
