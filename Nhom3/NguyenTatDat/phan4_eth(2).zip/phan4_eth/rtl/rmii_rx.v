// rmii_rx.v - nhan RMII 100 Mbps (mien REF_CLK 50 MHz).
// Bo preamble/SFD, ghep byte (dibit nhan truoc = 2 bit thap), kiem CRC32 tren ca khung ke ca FCS.
// Ra: moi byte 1 tu {crc_ok, eof, data}; crc_ok chi co nghia o tu co eof.
// Cuoi khung LAN8720 co the bat/tat CRS_DV: dibit o nhip CRS_DV = 0 van hop le neu nhip sau
// CRS_DV = 1; hai nhip lien tiep CRS_DV = 0 moi la het khung.
module rmii_rx #(
    parameter RX_EDGE = 0           // 0 = lay mau canh len REF_CLK, 1 = canh xuong
) (
    input            ref_clk,
    input            rst_n,         // da dong bo vao ref_clk
    input            crs_dv,
    input      [1:0] rxd,
    output reg       out_valid,
    output reg [9:0] out_word       // {crc_ok, eof, data[7:0]}
);
    // (1) lay mau chan, roi them 1 tang de nhin truoc 1 nhip
    reg crs_i, crs_q;
    reg [1:0] rxd_i, d_q;
    generate if (RX_EDGE) begin : g_neg
        always @(negedge ref_clk) begin crs_i <= crs_dv; rxd_i <= rxd; end
    end else begin : g_pos
        always @(posedge ref_clk) begin crs_i <= crs_dv; rxd_i <= rxd; end
    end endgenerate
    always @(posedge ref_clk) begin crs_q <= crs_i; d_q <= rxd_i; end

    // (2) het khung: 2 nhip lien tiep CRS_DV = 0
    wire fin = !crs_q && !crs_i;

    // (5) CRC-32 (da thuc dao 0xEDB88320), 2 bit moi lan, bit thap truoc
    function [31:0] crc2(input [31:0] c, input [1:0] d);
        reg [31:0] t;
        begin
            t    = (c >> 1) ^ ((c[0] ^ d[0]) ? 32'hEDB88320 : 32'h0);
            crc2 = (t >> 1) ^ ((t[0] ^ d[1]) ? 32'hEDB88320 : 32'h0);
        end
    endfunction

    // (3) may trang thai
    localparam IDLE = 2'd0, PRE = 2'd1, DATA = 2'd2;
    reg [1:0]  st, cnt;             // cnt: so dibit trong byte dang ghep
    reg [7:0]  sh, held;
    reg        have;                // (4) held la byte da nhan, chua biet co phai byte cuoi
    reg [31:0] crc;

    always @(posedge ref_clk) begin
        out_valid <= 1'b0;
        if (!rst_n) begin
            st <= IDLE;
        end else case (st)
            IDLE: if (crs_q) st <= PRE;
            PRE: if (fin) st <= IDLE;
                 else if (d_q == 2'b11) begin              // dibit cuoi cua SFD
                     st <= DATA; cnt <= 0; have <= 0; crc <= 32'hFFFFFFFF;
                 end
            DATA: if (fin) begin
                      if (have) begin                     // byte dang giu la byte cuoi
                          out_valid <= 1'b1;
                          out_word  <= {crc == 32'hDEBB20E3 && cnt == 0, 1'b1, held};
                      end
                      st <= IDLE;
                  end else begin
                      sh  <= {d_q, sh[7:2]};
                      crc <= crc2(crc, d_q);
                      cnt <= cnt + 1'b1;
                      if (cnt == 3) begin                 // vua du 1 byte
                          if (have) begin out_valid <= 1'b1; out_word <= {2'b00, held}; end
                          held <= {d_q, sh[7:2]};
                          have <= 1'b1;
                      end
                  end
            default: st <= IDLE;
        endcase
    end
endmodule
