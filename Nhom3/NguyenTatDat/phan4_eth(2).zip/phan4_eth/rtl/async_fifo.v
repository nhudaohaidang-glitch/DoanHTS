// async_fifo.v - FIFO bat dong bo, con tro ma Gray, theo dung thiet ke "FIFO1" trong
// C. Cummings, "Simulation and Synthesis Techniques for Asynchronous FIFO Design" (SNUG 2002).
// rdata xem truoc: hop le khi rempty = 0, rinc lay tu do ra.
module async_fifo #(
    parameter DW = 8,
    parameter AW = 4                // sau 2^AW tu, AW >= 2
) (
    input               wclk, wrst_n, winc,
    input      [DW-1:0] wdata,
    output reg          wfull,
    input               rclk, rrst_n, rinc,
    output     [DW-1:0] rdata,
    output reg          rempty
);
    reg [DW-1:0] mem [0:(1<<AW)-1];
    reg [AW:0] wbin, wptr, wq1_rptr, wq2_rptr;
    reg [AW:0] rbin, rptr, rq1_wptr, rq2_wptr;

    // phia ghi
    wire [AW:0] wbinnext  = wbin + (winc & ~wfull);
    wire [AW:0] wgraynext = (wbinnext >> 1) ^ wbinnext;
    always @(posedge wclk) if (winc && !wfull) mem[wbin[AW-1:0]] <= wdata;
    always @(posedge wclk or negedge wrst_n)
        if (!wrst_n) begin
            {wbin, wptr} <= 0; {wq2_rptr, wq1_rptr} <= 0; wfull <= 1'b0;
        end else begin
            {wbin, wptr} <= {wbinnext, wgraynext};
            {wq2_rptr, wq1_rptr} <= {wq1_rptr, rptr};
            wfull <= (wgraynext == {~wq2_rptr[AW:AW-1], wq2_rptr[AW-2:0]});
        end

    // phia doc
    assign rdata = mem[rbin[AW-1:0]];
    wire [AW:0] rbinnext  = rbin + (rinc & ~rempty);
    wire [AW:0] rgraynext = (rbinnext >> 1) ^ rbinnext;
    always @(posedge rclk or negedge rrst_n)
        if (!rrst_n) begin
            {rbin, rptr} <= 0; {rq2_wptr, rq1_wptr} <= 0; rempty <= 1'b1;
        end else begin
            {rbin, rptr} <= {rbinnext, rgraynext};
            {rq2_wptr, rq1_wptr} <= {rq1_wptr, wptr};
            rempty <= (rgraynext == rq2_wptr);
        end
endmodule
