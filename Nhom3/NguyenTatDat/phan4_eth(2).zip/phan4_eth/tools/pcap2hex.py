#!/usr/bin/env python3
"""pcap2hex.py - chuyen .pcap thanh file hex cho phy_model.v
Dung: python3 pcap2hex.py vao.pcap ra [--block IP] [--corrupt N]
Ra: ra.hex (moi khung), ra_pass.hex (khung phai qua),
    ra.lst (ma tung khung: 0 qua, 1 bi chan, 2 CRC sai; dong cuoi = f)"""
import argparse, sys, zlib
from scapy.all import rdpcap, Ether, IP

ap = argparse.ArgumentParser()
ap.add_argument('vao')
ap.add_argument('ra')
ap.add_argument('--block', action='append', default=[], help='IP nguon bi chan, dung nhieu lan duoc')
ap.add_argument('--corrupt', type=int, default=0, help='lam hong FCS cua moi khung thu N')
a = ap.parse_args()

tat_ca, qua, ma, bo_qua = [], [], [], 0
for n, p in enumerate(rdpcap(a.vao)):
    if Ether not in p:
        sys.exit('goi %d khong phai Ethernet (ghi o giao dien "any"?)' % n)
    f = bytes(p).ljust(60, b'\0')
    if len(f) > 1518:                              # goi bi gop (GRO/TSO) hoac jumbo
        bo_qua += 1
        continue
    fcs = zlib.crc32(f).to_bytes(4, 'little')
    m = 0
    if a.corrupt and len(ma) % a.corrupt == a.corrupt - 1:
        fcs, m = bytes([fcs[0] ^ 1]) + fcs[1:], 2   # lat bit 0 cua byte FCS dau
    elif IP in p and p[IP].src in a.block:
        m = 1
    khung = f + fcs
    dong = ['%03x' % (b | (0x100 if i == len(khung) - 1 else 0))
            for i, b in enumerate(khung)]
    tat_ca += dong
    if m == 0:
        qua += dong
    ma.append(m)

if len(tat_ca) >= 1 << 20 or len(ma) >= 65535:    # kich thuoc mang trong phy_model.v va testbench
    sys.exit('%d khung, %d byte: qua lon cho mo phong, cat ngan: '
             'editcap -r goc.pcap ngan.pcap 1-2000' % (len(ma), len(tat_ca)))
for ten, dong in ((a.ra + '.hex', tat_ca), (a.ra + '_pass.hex', qua)):
    open(ten, 'w').write('\n'.join(dong + ['200']) + '\n')
open(a.ra + '.lst', 'w').write('\n'.join([str(x) for x in ma] + ['f']) + '\n')
print('%s: %d khung (qua %d, bo do luat %d, CRC sai %d), bo qua %d khung > 1518 byte'
      % (a.ra, len(ma), ma.count(0), ma.count(1), ma.count(2), bo_qua))
