// eth_mac_wrap.v - boc eth_bridge (Phan 4 chinh thuc) theo dung cong eth_mac cua Phan 1
// Phan 1 thay MAC thu bang file nay ma khong sua tangnano9k_top.v.
// BUF_AW chi giu cho dung cong; eth_bridge luon dung bo dem 4 KB moi chieu.
// mac_crc_err / mac_overflow = OR cua 2 cong; muon dem du thi wb_filter_regs cong ca 2 bit.
`timescale 1ns / 1ps
module eth_mac #(
    parameter integer BUF_AW       = 12,
    parameter         SAMPLE_NEG_A = 1'b0,
    parameter         SAMPLE_NEG_B = 1'b1
) (
    input  wire clk, input wire rst_n,
    input  wire a_ref_clk, input wire a_crs_dv, input wire [1:0] a_rxd,
    output wire a_tx_en, output wire [1:0] a_txd,
    input  wire b_ref_clk, input wire b_crs_dv, input wire [1:0] b_rxd,
    output wire b_tx_en, output wire [1:0] b_txd,
    output wire frm_valid, output wire [7:0] frm_data, output wire frm_sof, output wire frm_eof,
    output wire frm_dir, output wire frm_crc_ok,
    input  wire verdict_valid, input wire verdict_drop,
    output wire mac_crc_err, output wire mac_overflow
);
    wire [1:0] ec, eo;
    eth_bridge #(.RX_EDGE_A(SAMPLE_NEG_A), .RX_EDGE_B(SAMPLE_NEG_B), .BUF_AW(12)) u (
        .clk(clk), .rst_n(rst_n),
        .a_ref_clk(a_ref_clk), .a_crs_dv(a_crs_dv), .a_rxd(a_rxd), .a_tx_en(a_tx_en), .a_txd(a_txd),
        .b_ref_clk(b_ref_clk), .b_crs_dv(b_crs_dv), .b_rxd(b_rxd), .b_tx_en(b_tx_en), .b_txd(b_txd),
        .frm_valid(frm_valid), .frm_data(frm_data), .frm_sof(frm_sof), .frm_eof(frm_eof),
        .frm_dir(frm_dir), .frm_crc_ok(frm_crc_ok),
        .verdict_valid(verdict_valid), .verdict_drop(verdict_drop),
        .ev_crc_err(ec), .ev_overflow(eo));
    assign mac_crc_err  = |ec;
    assign mac_overflow = |eo;
endmodule
