#!/usr/bin/env python3
"""Tao luu luong thu: a.pcap (ngoai -> trong, vao cong A), b.pcap (trong -> ngoai, vao cong B).
Co du: khung ngan nhat, dai nhat 1518, VLAN 1522, ARP, SYN tu IP bi chan, goi MQTT."""
import random, sys
from scapy.all import Ether, ARP, IP, TCP, UDP, Dot1Q, Raw, wrpcap

random.seed(1)                       # co dinh so ngau nhien: chay lai ra dung file cu
N = int(sys.argv[1]) if len(sys.argv) > 1 else 120
BROKER, SENSOR, ATK = '192.168.10.10', '192.168.10.20', '192.168.10.50'
MO, MI = '02:00:00:00:00:01', '02:00:00:00:00:02'   # MAC phia ngoai, phia trong
pad = lambda n: Raw(bytes(random.randrange(256) for _ in range(n)))

a, b = [], []
for _ in range(N):
    r = random.random()
    if r < 0.4:
        a.append(Ether(src=MO, dst=MI) / IP(src=ATK, dst=BROKER) /
                 TCP(sport=random.randrange(1024, 65535), dport=1883, flags='S'))
    elif r < 0.5:
        a.append(Ether(src=MO, dst='ff:ff:ff:ff:ff:ff') / ARP(psrc=SENSOR, pdst=BROKER))
    elif r < 0.6:
        a.append(Ether(src=MO, dst=MI) / Dot1Q(vlan=10) / IP(src=SENSOR, dst=BROKER) / UDP() / pad(1472))
    else:
        a.append(Ether(src=MO, dst=MI) / IP(src=SENSOR, dst=BROKER) /
                 TCP(sport=40000, dport=1883, flags='PA') / pad(random.choice([0, 1, 100, 1460])))
    b.append(Ether(src=MI, dst=MO) / IP(src=BROKER, dst=SENSOR) /
             TCP(sport=1883, dport=40000, flags='A') / pad(random.choice([0, 20, 600, 1460])))

wrpcap('a.pcap', a)
wrpcap('b.pcap', b)
