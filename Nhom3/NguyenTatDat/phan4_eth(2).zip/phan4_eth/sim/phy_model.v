`timescale 1ns/1ps
// phy_model.v - mo hinh LAN8720 cho mo phong (khong tong hop duoc).
// Phat (PHY -> FPGA): doc IN_HEX (dinh dang cua pcap2hex.py), phat ra crs_dv/rxd theo RMII.
//   REAL=1 giong chip that: 0-3 nhip RXD=00 dau khung, preamble ngan bot,
//   CRS_DV bat/tat o 0-2 byte cuoi, khoang nghi GAP + 0..15 nhip (REAL=0: dung GAP nhip).
module phy_model #(
    parameter IN_HEX = "", OUT_HEX = "", EXP_HEX = "",
    parameter REAL = 1, SEED = 1, ALLOW_SKIP = 0,
    parameter GAP = 48              // khoang nghi toi thieu giua 2 khung phat ra (nhip)
) (
    input            ref_clk,
    output reg       crs_dv = 0,
    output reg [1:0] rxd = 0,
    input            tx_en,
    input      [1:0] txd
);
    localparam MAXW = 1 << 20;
    reg [9:0] fin [0:MAXW-1];
    integer seed = SEED, ntx = 0;
    reg tx_done = 0;

    // ---------------- phat ----------------
    task put(input c, input [1:0] d);   // 1 dibit: doi canh len roi 4 ns sau moi doi chan, nhu PHY that
        begin @(posedge ref_clk); #4 crs_dv = c; rxd = d; end
    endtask

    integer i, j, k, s, tog;
    initial begin
        if (IN_HEX != "") begin
            $readmemh(IN_HEX, fin);
            repeat (50) put(0, 2'b00);
            i = 0;
            while (fin[i] !== 10'h200) begin
                if (REAL) repeat ($unsigned($random(seed)) % 4) put(1, 2'b00);
                repeat (REAL ? 23 + $unsigned($random(seed)) % 8 : 31) put(1, 2'b01);
                put(1, 2'b11);
                for (j = i; !fin[j][8]; j = j + 1) ;          // j = byte cuoi khung
                tog = REAL ? $unsigned($random(seed)) % 3 : 0; // so byte cuoi bat/tat CRS_DV
                for (k = i; k <= j; k = k + 1)
                    for (s = 0; s < 4; s = s + 1)
                        put((k > j - tog) ? s[0] : 1'b1, fin[k] >> (2 * s));
                i = j + 1;
                ntx = ntx + 1;
                repeat (GAP + (REAL ? $unsigned($random(seed)) % 16 : 0)) put(0, 2'b00);
            end
        end
        tx_done = 1;
    end
    // ---------------- nhan ----------------
    // Nhan (FPGA -> PHY): kiem preamble 31 x 01 + 11, khoang nghi >= 48 nhip, khung tron byte;
    //   ghi tung khung ra OUT_HEX; co EXP_HEX thi so tung khung voi khung mong doi.
    //   ALLOW_SKIP=1: duoc thieu khung mong doi (thu tran bo dem), khung nhan duoc van phai dung.
    reg [9:0] fexp [0:MAXW-1];
    integer nrx = 0, nerr = 0, nskip = 0, nexp = 0;
    integer fo = 0, ep = 0, gap = 1000, np = 0, nd = 0, st = 0, m, n;
    reg [7:0] sh;
    reg [7:0] fb [0:4095];          // khung dang nhan

    task err(input [8*48:1] msg);
        begin $display("[%m] %0d ns: %0s", $time, msg); nerr = nerr + 1; end
    endtask

    initial begin
        if (OUT_HEX != "") fo = $fopen(OUT_HEX, "w");
        if (EXP_HEX != "") begin
            $readmemh(EXP_HEX, fexp);
            for (m = 0; fexp[m] !== 10'h200; m = m + 1) nexp = nexp + fexp[m][8];
        end
    end

    function match(input integer p, input integer len);   // khung vua nhan == khung mong doi o vi tri p?
        integer q;
        begin
            match = 1;
            for (q = 0; q < len; q = q + 1)
                if (fexp[p + q] !== {q == len - 1, fb[q]}) match = 0;
        end
    endfunction

    task next_exp;                  // ep -> dau khung mong doi tiep theo
        begin while (!fexp[ep][8]) ep = ep + 1; ep = ep + 1; end
    endtask

    task end_frame;
        begin
            nrx = nrx + 1;
            n = nd / 4;
            if (nd % 4) err("khung khong tron byte");
            if (fo) for (m = 0; m < n; m = m + 1)
                $fwrite(fo, "%03x\n", {m == n - 1, fb[m]});
            if (EXP_HEX != "") begin
                while (ALLOW_SKIP && fexp[ep] !== 10'h200 && !match(ep, n)) begin
                    next_exp; nskip = nskip + 1;
                end
                if (fexp[ep] === 10'h200 || !match(ep, n)) err("khung nhan khac khung mong doi");
                else next_exp;
            end
        end
    endtask

    task close_out;                 // testbench goi o cuoi de ghi dong 200 va dong file
        begin if (fo) begin $fwrite(fo, "200\n"); $fclose(fo); fo = 0; end end
    endtask

    always @(posedge ref_clk) begin
        if (tx_en !== 1'b1) begin                // X truoc reset coi nhu nghi
            if (st == 1) err("tx_en tat giua preamble");
            if (st == 2) end_frame;
            st = 0;
            gap = gap + 1;
        end else begin
            if (st == 0) begin
                if (gap < 48) err("khoang nghi giua 2 khung < 48 nhip");
                st = 1; np = 0;
            end
            if (st == 1) begin
                if (txd == 2'b11) begin
                    if (np != 31) err("preamble khong du 31 dibit 01");
                    st = 2; nd = 0;
                end else begin
                    if (txd != 2'b01) err("preamble sai");
                    np = np + 1;
                end
            end else begin
                sh = {txd, sh[7:2]};             // dibit moi vao bit cao, dich xuong
                nd = nd + 1;
                if (nd % 4 == 0) fb[nd / 4 - 1] = sh;
            end
            gap = 0;
        end
    end
endmodule
