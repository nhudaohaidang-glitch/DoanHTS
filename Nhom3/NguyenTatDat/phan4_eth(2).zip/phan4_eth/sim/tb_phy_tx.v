`timescale 1ns/1ps
// Buoc 1c: thu nua phat cua phy_model. Dem so nhip CRS_DV = 1 cua tung khung, ghi dang song ra phy_tx.vcd.
module tb_phy_tx;
    reg clk = 0;
    always #10 clk = ~clk;                 // REF_CLK 50 MHz: chu ky 20 ns
    wire       crs;
    wire [1:0] rxd;
    phy_model #(.IN_HEX("t.hex"), .REAL(0)) phy (.ref_clk(clk), .crs_dv(crs), .rxd(rxd), .tx_en(1'b0), .txd(2'b00));

    integer n = 0, k = 0;
    always @(posedge clk) begin
        if (crs) n = n + 1;
        else if (n) begin $display("khung %0d: %0d nhip CRS_DV = 1", k, n); k = k + 1; n = 0; end
    end
    initial begin
        $dumpfile("phy_tx.vcd");
        $dumpvars(0, tb_phy_tx);
        wait (phy.tx_done);
        repeat (10) @(posedge clk);
        $display("phat %0d khung", phy.ntx);
        $finish;
    end
endmodule
