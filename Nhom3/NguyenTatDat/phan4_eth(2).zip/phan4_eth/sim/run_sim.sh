#!/bin/bash
# Chay toan bo mo phong Phan 4. Can: iverilog, python3, scapy.
#   ./run_sim.sh            tao luu luong thu roi chay 5 test
#   ./run_sim.sh X.pcap     dung file .pcap that cho cong A (vd file ghi o moc 0);
#                           cat ngan truoc: editcap -r goc.pcap X.pcap 1-2000
set -e
PCAP=${1:+$(realpath "$1")}          # doi ra duong dan day du truoc khi cd
cd "$(dirname "$0")"; mkdir -p build; cd build
R=../../rtl
RTL="$R/rmii_rx.v $R/rmii_tx.v $R/async_fifo.v $R/frame_buf.v $R/eth_bridge.v"
run() { rm -f a.out; iverilog -Wall "$@" 2>&1 | grep -v -i "timescale\|inherit" || true; if [ -f a.out ]; then vvp -n a.out | grep -v readmemh; else echo "FAIL: loi bien dich"; fi; }
python3 ../gen_test_pcap.py 120
[ -n "$PCAP" ] && cp "$PCAP" a.pcap
python3 ../../tools/pcap2hex.py a.pcap a --block 192.168.10.50 --corrupt 7
python3 ../../tools/pcap2hex.py b.pcap b --corrupt 11
cp a.hex loop.hex

echo "== Buoc 1 (moc 1): mo hinh PHY phat lai va ghi ra file =="
run ../tb_phy_loop.v ../phy_model.v
cmp loop.hex loop_out.hex && echo "loop_out.hex giong het loop.hex"

echo "== Buoc 2: rmii_rx =="
run ../tb_rx.v ../phy_model.v $R/rmii_rx.v

echo "== Buoc 3: bo lap rmii_rx -> async_fifo -> rmii_tx =="
run ../tb_rxtx.v ../phy_model.v $R/rmii_rx.v $R/async_fifo.v $R/rmii_tx.v

echo "== Buoc 5: cau noi 2 chieu, Phan 3 gia =="
run ../tb_eth_bridge.v ../phy_model.v $RTL

echo "== Buoc 5: tran bo dem (cong B 50 Mbps) =="
run -DOVF_TEST ../tb_eth_bridge.v ../phy_model.v $RTL
