`timescale 1ns/1ps
// Buoc 3: bo lap 1 chieu, chua co bo dem khung:
//   phy_a -> rmii_rx (a_clk) -> async_fifo -> rmii_tx (b_clk, cham 100 ppm) -> phy_b.
// Khung (ke ca khung CRC sai) phai ra nguyen ven, dung thu tu. FIFO chi 16 byte nen
// phy_a de khoang nghi 200 nhip; nghi ngan hon se tran FIFO -> ly do phai co bo dem khung (buoc 4).
module tb_rxtx;
    reg a_clk = 0, b_clk = 0, rst_n = 0;
    always #10 a_clk = ~a_clk;
    initial begin #3; forever #10.001 b_clk = ~b_clk; end

    wire       crs, v, txen, empty, rd;
    wire [1:0] rxd, txd;
    wire [9:0] w;
    wire [8:0] q;
    phy_model #(.IN_HEX("a.hex"), .GAP(200)) phy_a (.ref_clk(a_clk), .crs_dv(crs), .rxd(rxd), .tx_en(1'b0), .txd(2'b00));
    phy_model #(.EXP_HEX("a.hex")) phy_b (.ref_clk(b_clk), .crs_dv(), .rxd(), .tx_en(txen), .txd(txd));

    rmii_rx u_rx (.ref_clk(a_clk), .rst_n(rst_n), .crs_dv(crs), .rxd(rxd), .out_valid(v), .out_word(w));
    async_fifo #(.DW(9)) u_f (.wclk(a_clk), .wrst_n(rst_n), .winc(v), .wdata(w[8:0]), .wfull(),
        .rclk(b_clk), .rrst_n(rst_n), .rinc(rd), .rdata(q), .rempty(empty));
    rmii_tx u_tx (.ref_clk(b_clk), .rst_n(rst_n), .fifo_empty(empty), .fifo_data(q), .fifo_rd(rd), .tx_en(txen), .txd(txd));

    initial begin
        #100 rst_n = 1;
        wait (phy_a.tx_done);
        #20000;
        $display("phat %0d khung, nhan %0d/%0d khung, loi %0d", phy_a.ntx, phy_b.nrx, phy_b.nexp, phy_b.nerr);
        $display("%s tb_rxtx", (phy_b.nerr == 0 && phy_b.nrx == phy_b.nexp) ? "PASS" : "FAIL");
        $finish;
    end
endmodule
