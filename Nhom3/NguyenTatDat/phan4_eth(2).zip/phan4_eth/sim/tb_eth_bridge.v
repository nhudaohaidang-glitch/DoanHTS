`timescale 1ns/1ps
// tb_eth_bridge.v - testbench toan Phan 4, tu kiem tra, in PASS/FAIL.
// Cong A phat a.hex (ngoai -> trong), cong B phat b.hex (trong -> ngoai); Phan 3 gia ra verdict theo a.lst.
// Kiem: cong B ra dung a_pass.hex, cong A ra dung b_pass.hex (tung byte, dung thu tu);
//       dong frm_* tung khung tron ven; so xung CRC sai khop danh sach; khong tran bo dem.
// Clock: 27 MHz, a_ref 50 MHz, b_ref cham hon 100 ppm va lech pha. Cong B lay mau canh xuong.
// OVF_TEST: b_ref 25 MHz (cong B chi 50 Mbps) de bo dem A -> B day; duoc thieu khung, phai co tran.
module tb_eth_bridge;
`ifdef OVF_TEST
    localparam real BH = 20.0;      // nua chu ky b_ref (ns)
    localparam SKIP = 1;
`else
    localparam real BH = 10.001;
    localparam SKIP = 0;
`endif
    reg clk = 0, a_clk = 0, b_clk = 0, rst_n = 0;
    always #18.5185 clk = ~clk;
    always #10 a_clk = ~a_clk;
    initial begin #3; forever #(BH) b_clk = ~b_clk; end

    wire       a_crs, b_crs, a_txen, b_txen;
    wire [1:0] a_rxd, b_rxd, a_txd, b_txd;
    wire       frm_valid, frm_sof, frm_eof, frm_dir, frm_crc_ok;
    wire [7:0] frm_data;
    wire [1:0] ev_crc_err, ev_overflow;
    reg        verdict_valid = 0, verdict_drop = 0;

    phy_model #(.IN_HEX("a.hex"), .EXP_HEX("b_pass.hex"), .SEED(1)) phy_a (
        .ref_clk(a_clk), .crs_dv(a_crs), .rxd(a_rxd), .tx_en(a_txen), .txd(a_txd));
    phy_model #(.IN_HEX("b.hex"), .EXP_HEX("a_pass.hex"), .SEED(7), .ALLOW_SKIP(SKIP)) phy_b (
        .ref_clk(b_clk), .crs_dv(b_crs), .rxd(b_rxd), .tx_en(b_txen), .txd(b_txd));

    eth_bridge #(.RX_EDGE_B(1)) dut (
        .clk(clk), .rst_n(rst_n),
        .a_ref_clk(a_clk), .a_crs_dv(a_crs), .a_rxd(a_rxd), .a_tx_en(a_txen), .a_txd(a_txd),
        .b_ref_clk(b_clk), .b_crs_dv(b_crs), .b_rxd(b_rxd), .b_tx_en(b_txen), .b_txd(b_txd),
        .frm_valid(frm_valid), .frm_data(frm_data), .frm_sof(frm_sof), .frm_eof(frm_eof),
        .frm_dir(frm_dir), .frm_crc_ok(frm_crc_ok),
        .verdict_valid(verdict_valid), .verdict_drop(verdict_drop),
        .ev_crc_err(ev_crc_err), .ev_overflow(ev_overflow));

    // ---- Phan 3 gia: bo khung IPv4 ngoai -> trong co IP nguon 192.168.10.50 (= 0xC0A80A32,
    //      giong --block cua pcap2hex); tra loi ngau nhien: ngay sau byte 30, hoac 1-4 nhip sau frm_eof ----
    reg [3:0] la [0:65535], lb [0:65535];
    reg [7:0] hb [0:29];
    reg       vdir, vd;
    integer   bi = 0, r = 0, cd = -1, vseed = 3, nv = 0;
    initial begin $readmemh("a.lst", la); $readmemh("b.lst", lb); end
    always @(posedge clk) begin
        verdict_valid <= 0;
        if (frm_valid) begin
            if (frm_sof) begin bi = 0; vdir = frm_dir; r = $unsigned($random(vseed)) % 5; end
            if (bi < 30) hb[bi] = frm_data;
            bi = bi + 1;
            vd = !vdir && {hb[12], hb[13]} == 16'h0800 && {hb[26], hb[27], hb[28], hb[29]} == 32'hC0A80A32;
            if (r == 0 && bi == 30) begin verdict_valid <= 1; verdict_drop <= vd; nv = nv + 1; end
            if (frm_eof && r != 0) cd = r - 1;
        end
        if (cd == 0) begin verdict_valid <= 1; verdict_drop <= vd; nv = nv + 1; end
        if (cd >= 0) cd = cd - 1;
    end

    // ---- giam sat dong frm_* va xung dem ----
    integer nf0 = 0, nf1 = 0, serr = 0, ncrc = 0, novf = 0, inf = 0, cdir = 0;
    always @(posedge clk) begin
        if (frm_valid) begin
            if (frm_sof) begin
                if (inf) serr = serr + 1;               // sof khi khung truoc chua het
                inf = 1; cdir = frm_dir;
            end else if (!inf) serr = serr + 1;         // byte ngoai khung
            if (frm_dir != cdir) serr = serr + 1;       // doi chieu giua khung
            if (frm_eof) begin
                if (!frm_crc_ok) serr = serr + 1;
                inf = 0;
                if (cdir) nf1 = nf1 + 1; else nf0 = nf0 + 1;
            end
        end
        if (rst_n) begin
            ncrc = ncrc + ev_crc_err[0] + ev_crc_err[1];
            novf = novf + ev_overflow[0] + ev_overflow[1];
        end
    end

    // ---- ket qua ----
    integer k, ecrc = 0, ef0 = 0, ef1 = 0, ok;
    initial begin
        #200 rst_n = 1;
        wait (phy_a.tx_done && phy_b.tx_done);
        #1000000;                                       // cho bo dem xa het
        for (k = 0; la[k] != 15; k = k + 1) if (la[k] == 2) ecrc = ecrc + 1; else ef0 = ef0 + 1;
        for (k = 0; lb[k] != 15; k = k + 1) if (lb[k] == 2) ecrc = ecrc + 1; else ef1 = ef1 + 1;
        ok = phy_a.nerr == 0 && phy_b.nerr == 0 && serr == 0 && ncrc == ecrc && nf1 == ef1
             && phy_a.nrx == phy_a.nexp && nv == nf0 + nf1
             && (SKIP ? (novf > 0 && phy_b.nrx > 0) : (novf == 0 && nf0 == ef0 && phy_b.nrx == phy_b.nexp));
        $display("A->B: vao %0d, len frm_* %0d/%0d, ra cong B %0d/%0d (thieu %0d)",
                 phy_a.ntx, nf0, ef0, phy_b.nrx, phy_b.nexp, phy_b.nskip);
        $display("B->A: vao %0d, len frm_* %0d/%0d, ra cong A %0d/%0d",
                 phy_b.ntx, nf1, ef1, phy_a.nrx, phy_a.nexp);
        $display("CRC sai %0d/%0d, tran bo dem %0d, loi dong frm_* %0d, loi PHY %0d",
                 ncrc, ecrc, novf, serr, phy_a.nerr + phy_b.nerr);
        $display("%s tb_eth_bridge%s", ok ? "PASS" : "FAIL", SKIP ? " (OVF_TEST)" : "");
        $finish;
    end
`ifndef OVF_TEST
    initial begin $dumpfile("bridge.vcd"); $dumpvars(0, tb_eth_bridge); #26000 $dumpoff; end
`endif
endmodule
