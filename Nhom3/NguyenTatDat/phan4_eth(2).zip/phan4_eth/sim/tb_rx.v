`timescale 1ns/1ps
// Buoc 2: mo hinh PHY phat a.hex vao rmii_rx; dem khung CRC dung/sai, so voi a.lst.
// Doi EDGE thanh 1 (lay mau canh xuong) chay lai cung phai PASS.
module tb_rx;
    localparam EDGE = 0;
    reg clk = 0, rst_n = 0;
    always #10 clk = ~clk;
    wire       crs, v;
    wire [1:0] rxd;
    wire [9:0] w;                    // {crc_ok, eof, data}
    phy_model #(.IN_HEX("a.hex")) phy (.ref_clk(clk), .crs_dv(crs), .rxd(rxd), .tx_en(1'b0), .txd(2'b00));
    rmii_rx #(.RX_EDGE(EDGE)) dut (.ref_clk(clk), .rst_n(rst_n), .crs_dv(crs), .rxd(rxd), .out_valid(v), .out_word(w));

    reg [3:0] la [0:65535];
    integer good = 0, bad = 0, nbyte = 0, eg = 0, eb = 0, k;
    always @(posedge clk) if (v) begin
        nbyte = nbyte + 1;
        if (w[8]) begin if (w[9]) good = good + 1; else bad = bad + 1; end
    end
    initial begin
        $readmemh("a.lst", la);
        for (k = 0; la[k] != 15; k = k + 1) if (la[k] == 2) eb = eb + 1; else eg = eg + 1;
        #100 rst_n = 1;
        wait (phy.tx_done);
        #2000;
        $display("CRC dung %0d/%0d khung, CRC sai %0d/%0d khung, tong %0d byte", good, eg, bad, eb, nbyte);
        $display("%s tb_rx", (good == eg && bad == eb) ? "PASS" : "FAIL");
        $finish;
    end
    initial begin $dumpfile("rx.vcd"); $dumpvars(0, tb_rx); #15000 $dumpoff; end
endmodule
