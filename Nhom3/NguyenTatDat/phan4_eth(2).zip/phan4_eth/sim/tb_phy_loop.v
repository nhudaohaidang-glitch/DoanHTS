`timescale 1ns/1ps
// Moc 1: mo hinh PHY phat lai loop.hex, mo hinh thu 2 nhan va ghi ra loop_out.hex.
// Dat khi in PASS va loop_out.hex giong het loop.hex.
module tb_phy_loop;
    reg clk = 0;
    always #10 clk = ~clk;
    wire c;
    wire [1:0] d;
    phy_model #(.IN_HEX("loop.hex"), .REAL(0)) src (.ref_clk(clk), .crs_dv(c), .rxd(d), .tx_en(1'b0), .txd(2'b00));
    phy_model #(.OUT_HEX("loop_out.hex"), .EXP_HEX("loop.hex")) dst (.ref_clk(clk), .crs_dv(), .rxd(), .tx_en(c), .txd(d));
    initial begin
        wait (src.tx_done);
        repeat (100) @(posedge clk);
        dst.close_out;
        if (dst.nerr == 0 && dst.nrx == src.ntx && dst.nrx == dst.nexp)
            $display("PASS tb_phy_loop: %0d khung", dst.nrx);
        else
            $display("FAIL tb_phy_loop: phat %0d, nhan %0d, mong doi %0d, loi %0d", src.ntx, dst.nrx, dst.nexp, dst.nerr);
        $finish;
    end
endmodule
