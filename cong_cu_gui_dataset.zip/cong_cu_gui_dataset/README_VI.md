# Gửi dataset lớn vào chat

Cách dễ nhất: nén các file dataset và tài liệu liên quan thành ZIP bằng Windows, rồi gửi nếu ZIP nhỏ hơn khoảng 25 MB.

Nếu vẫn lớn, dùng công cụ này. Nó đọc thư mục bạn chọn, giữ nguyên dữ liệu gốc và tạo GUI_001.zip, GUI_002.zip... để đính kèm vào chat. Mỗi ZIP tối đa 20 MiB. Không cần cài thêm thư viện và không tải lên mạng tự động.

Ubuntu có Python sẵn. Tạo thư mục Downloads/dataset_ban_gui và chép vào đó các file muốn gửi. Giải nén gói công cụ này trong Downloads thành cong_cu_gui_dataset, rồi chạy:

```bash
python3 ~/Downloads/cong_cu_gui_dataset/dong_goi.py \
  --input ~/Downloads/dataset_ban_gui \
  --output ~/Downloads/dataset_gui_chatgpt
```

Thư mục đầu ra phải mới và nằm ngoài thư mục đầu vào. Khi xong, đính kèm tất cả GUI_*.zip trong đầu ra vào chat; có thể gửi nhiều tin nhắn và ghi “đã gửi đủ” ở tin cuối. Người nhận cần đủ các phần. Không cần bạn tự ghép các phần.

Nhớ kèm README, code .py/.ipynb xử lý dữ liệu, bảng đổi nhãn và thông số chuẩn hóa nếu có. Nhãn class0/1/2 của file mới chưa được biết; không áp quy ước model cũ khi chưa xác minh mapping.

Xem GUI_DATASET_LON_VI.md để có hướng dẫn Windows/Python và giải thích ảnh dataset.
