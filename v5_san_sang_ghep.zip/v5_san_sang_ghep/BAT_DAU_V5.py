"""Verify the bundle, then prepare the already trained V5; never fit."""
import argparse,hashlib,json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data',default=str(Path.home()/'iot23_da_loc_01'))
parser.add_argument('--output',default=str(Path.home()/'iot23_v5_ghep_01'))
parser.add_argument('--verify-pcaps',action='store_true')
parser.add_argument('--skip-local-data-check',action='store_true',help='Only verify the supplied cache; do not claim the local PCAP files were checked')
args=parser.parse_args()
checks=json.loads((root/'FILE_SHA256.json').read_text())
for name,expected in checks.items():
    path=root/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise SystemExit('Package file changed/missing: '+name)
sys.path[:0]=[str(root/'code'),str(root/'code/tools')]
try:
    from prepare_v5_handoff import prepare
    prepare(root,args.output,None if args.skip_local_data_check else args.data,args.verify_pcaps)
except ImportError as error:
    raise SystemExit('Use the existing ~/ai_part2/.venv/bin/python for this script. Missing dependency: '+str(error))
except (ValueError,OSError,KeyError) as error:
    raise SystemExit('ERROR: '+str(error))
