"""Read-only verification of package files; no extra dependencies."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
checks=json.loads((root/'FILE_SHA256.json').read_text())
bad=[]
for name,expected in checks.items():
    path=root/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        bad.append(name)
if bad:raise SystemExit('CHANGED/MISSING: '+', '.join(bad))
print('OK:',len(checks),'files match. Model weights and original V4 cache preserved.')
