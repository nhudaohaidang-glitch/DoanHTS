# Cập nhật phần người 2

1. Giải nén thư mục này vào Downloads của Ubuntu.
2. Dừng dashboard cũ (Ctrl+C) nếu có.
3. Mở Terminal, chạy KHÔNG sudo:

```bash
python3 ~/Downloads/part2_next_steps/apply_update.py --target ~/ai_part2
python3 ~/Downloads/part2_next_steps/apply_update.py --target ~/ai_part2 --apply
```

Mã cũ sao lưu dưới build/update_backups. data/, .venv/, model và feature trong build được giữ nguyên. Nếu báo ERROR, dừng và gửi nguyên thông báo; không xóa dữ liệu hoặc model để sửa lỗi cập nhật.

Sau đó mở ~/ai_part2/README_NEXT_STEPS_VI.md. Việc đầu tiên:

```bash
cd ~/ai_part2
.venv/bin/python tools/dashboard.py --session data/captures/normal_train03
```

Trong Firefox của Ubuntu nhập địa chỉ HTTP loopback cổng 8765. Dữ liệu MQTT cũ hiển thị FILE HISTORY; FPGA chưa nối sẽ ghi CHƯA KẾT NỐI FPGA. Không cần cài thư viện mới.
