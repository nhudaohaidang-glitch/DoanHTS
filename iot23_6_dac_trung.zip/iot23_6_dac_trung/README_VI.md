# Dataset thật để đọc: IoT-23 và đúng sáu đặc trưng

ZIP này đã chứa dữ liệu, không phải chỉ có chương trình tải. Giải nén rồi mở **MO_DE_DOC.html** bằng Firefox/Edge/Chrome. Có bảng tiếng Việt để đọc ngay, không cần cài thêm phần mềm cho việc xem trang.

## Tệp nào là đầu vào sáu cột?

Trong `du_lieu_6_cot/`:

- `X_6_raw.csv`: đúng sáu cột packet_count, mean_ip_bytes, syn_ratio_q127, src_count, dst_count, dst_port_count; mỗi dòng là một cửa sổ một giây.
- `X_6_fpga.csv`: đúng sáu cột q0..q5 sau chia/clip, chuẩn bị để đóng gói vào feat48 bit của core hiện tại.
- `y.csv`: nhãn, một cột class; dòng i là đáp án của dòng i trong X. **Không đưa y vào sáu đầu vào.**
- `THONG_TIN_DONG.csv`: nguồn và thời gian để kiểm tra; không phải đầu vào AI.

## Những dữ liệu nào đã có?

- 2.880 cửa sổ bình thường từ PCAP Philips Hue4 gốc của IoT-23.
- 21 cửa sổ của đoạn SYN đã xác minh từ capture34. PCAP trích gồm 40.568 gói SYN mở tới71.61.66.148:80, giữ nguyên byte và timestamp của các bản ghi gói được chọn; không phải toàn bộ capture34.
- PCAP bình thường gốc đầy đủ, PCAP SYN trích đoạn và hai conn.log.labeled gốc được đặt trong `raw/`. Log capture34 còn có các luồng khác ngoài đoạn SYN đã chọn.

**Đây là bộ đọc nhỏ từ hai nguồn, không phải toàn bộ IoT-23 hoặc bộ train mới đủ ba lớp.** Nó có nhãn0=Normal và1=đoạn SYN; chưa có2=vertical scan. Lớp2 của dự án đến từ lab có kiểm soát, không đổi quét ngang của IoT-23 thành quét dọc. Hai nguồn này đã dùng phát triển v3 nên không gọi đây là test độc lập mới. Riêng21 cửa sổ SYN cùng một đợt, không phải21tình huống tấn công độc lập.

## Vì sao không lấy sáu cột bất kỳ từ bảng11cột?

Bảng11cột bạn nhận có dấu hiệu là thống kê theo luồng đã chuẩn hóa. Core của nhóm dùng thống kê một giây, có hướng IPv4 và công thức khác. Bảng đó không thấy IP/timestamp/TCP flags để dựng lại chính xác cửa sổ, số IP và tỷ lệ SYN. Vì vậy đi từ PCAP rồi tính đúng sáu đặc trưng; không cắt bớt cột một cách tùy ý.

Việc dùng IoT-23 không buộc core nhận11 đặc trưng. Số đặc trưng phụ thuộc cách ta xử lý PCAP và thiết kế model. Gói này giữ đúng sáu đặc trưng đã chốt, không thay model hoặc core FPGA.

## Muốn tự tạo lại các bảng từ PCAP có sẵn?

Trên Ubuntu, sau khi giải nén trong Downloads, chạy bằng môi trường AI đã có NumPy và Scapy:

```bash
cd ~/Downloads/iot23_6_dac_trung
~/ai_part2/.venv/bin/python TAO_LAI_6_COT.py --output ket_qua_tao_lai
```

Không cần chạy bước này để đọc dữ liệu. Script chỉ đọc hai PCAP đã có, kiểm hash rồi tạo lại CSV vào thư mục mới. Không tải thêm, không huấn luyện hay thay trọng số. Nó dùng đúng mã part2/features.py của bộ AI hiện tại. Gói đã được kiểm tra: sáu giá trị của cả2.901 dòng khớp chính xác các cache native dùng trước đây cho v3.

PCAP và log là hai dạng khác nhau: mỗi bản ghi PCAP là một gói; mỗi dòng log Zeek tóm tắt một luồng có thể kéo dài nhiều giây; mỗi dòng X ở đây là một cửa sổ một giây.

## Nguồn gốc

IoT-23 được công bố bởi Stratosphere Laboratory / CTU: https://www.stratosphereips.org/datasets-iot23 . SOURCES.json ghi URL nguồn, hash PCAP gốc và bản trích, IP được bảo vệ và khoảng thời gian chọn. Nhãn số là quy ước đã kiểm tra của dự án, không áp dụng tự động cho class0/1/2 trong file11cột của người khác.

PCAP Hue4 gốc tải riêng, bản nén xz khoảng0,38 MB:
https://mcfp.felk.cvut.cz/publicDatasets/IoT-23-Dataset/IndividualScenarios/CTU-Honeypot-Capture-4-1/2018-10-25-14-06-32-192.168.1.132.pcap.xz

PCAP capture34 đầy đủ (khoảng126 MB):
https://mcfp.felk.cvut.cz/publicDatasets/IoT-23-Dataset/IndividualScenarios/CTU-IoT-Malware-Capture-34-1/2018-12-21-15-50-14-192.168.1.195.pcap

Toàn bộ IoT-23 gồm PCAP, tệp nén máy chủ hiện báo khoảng21,5 GB:
https://mcfp.felk.cvut.cz/publicDatasets/IoT-23-Dataset/iot_23_datasets_full.tar.gz

Bản chỉ log không đủ để tự tái tạo chính xác sáu đặc trưng theo cửa sổ một giây; cần PCAP hoặc một bảng đã được trích đúng contract này.
