# Tải IoT-23 để đọc

Đây là gói CHƯƠNG TRÌNH TẢI, chưa chứa toàn bộ dữ liệu. Khi chạy, nó tải trực tiếp từ máy chủ công bố khoảng 28 MB, rồi tạo thư mục dataset khoảng 60 MB gồm năm log gốc, CSV, một PCAP bình thường và trang đọc offline. Không thay đổi model AI.

Giải nén ZIP trong Downloads thành iot23_de_doc. Trên Ubuntu chạy:

```bash
cd ~/Downloads/iot23_de_doc
python3 tai_iot23.py --output dataset
firefox dataset/MO_DE_DOC.html
```

Không cần sudo hoặc cài thêm thư viện. Nếu gián đoạn, chạy lại lệnh Python. Đợi dòng DONE trước khi mở trang. Bắt đầu với bảng Philips Hue (452 luồng).

Một dòng conn.log.labeled/CSV là một FLOW, khác một gói và khác cửa sổ một giây của model. Nhãn gốc IoT-23 được giữ nguyên, không đổi sang ba lớp AI. Đây là năm capture được chọn để học đọc, không phải toàn bộ 23 capture.

Đọc DOC_VA_TAI_IOT23_VI.md để biết các cột, ví dụ thật và link tải bộ đầy đủ. Nguồn chính thức: https://www.stratosphereips.org/datasets-iot23
