# Xử lý archive IoT-23 đã tải ở Windows

Đọc HUONG_DAN_VI.md: giữ nguyên archive ở Windows, chia sẻ thư mục cho Ubuntu bằng VirtualBox và chạy bằng môi trường AI đã có. Công cụ đọc archive theo luồng, kiểm kê, chỉ trích PCAP đã xác minh và tạo X sáu cột cùng y riêng. Không giải nén toàn bộ, không train hay đổi model.

Sau giải nén công cụ trong Downloads Ubuntu:

```bash
~/ai_part2/.venv/bin/python ~/Downloads/xu_ly_iot23_full/XU_LY_IOT23.py \
  --archive /media/sf_IoT23/iot_23_datasets_full.tar.gz \
  --output ~/iot23_work_01
```

Cần thấy đúng file qua thư mục chia sẻ trước khi chạy. Đợi DONE; archive gzip lớn có thể cần nhiều phút hoặc lâu hơn để quét hết, có tiến độ. Mở ~/iot23_work_01/MO_KET_QUA.html. Nếu bị lỗi, gửi nguyên thông báo; kèm BAO_CAO.json/KIEM_KE.csv nếu đã có. Không cần gửi archive20GB.

Chỉ Hue4 bình thường và đoạn SYN34 được chọn mặc định; vertical scan lấy từ lab. Các capture khác được kiểm kê, không tự gán ba nhãn. Nếu PCAP không khớp snapshot đã xác minh, chương trình báo để xem xét, không ép nhãn.
