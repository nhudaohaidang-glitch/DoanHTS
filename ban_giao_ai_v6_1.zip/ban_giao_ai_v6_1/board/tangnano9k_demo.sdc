// CPU/AI demo clock only: RMII inputs are tied off and no RMII logic is active.
create_clock -name clk_27m -period 37.037 -waveform {0 18.518} [get_ports {clk_27m}]
