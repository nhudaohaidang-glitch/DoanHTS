# Gói học cách tính model AI v3

1. Đọc GIAI_THICH_MODEL_AI_V3_VI.md.
2. Mở sample_windows.csv để xem dữ liệu cửa sổ thật.
3. Mở packet_excerpt.csv để xem 11 gói của cửa sổ lỗi.
4. Chạy trong Terminal Ubuntu:

```bash
cd ~/Downloads/giai_thich_ai_v3
python3 demo.py
```

Không cần cài thêm thư viện. Đây là gói minh họa với model gốc, không phải bản sửa model. Không dùng các dòng ví dụ làm tập test để công bố accuracy.
