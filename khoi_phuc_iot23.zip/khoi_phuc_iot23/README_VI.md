# Tiếp tục xử lý IoT-23 sau lỗi Hue4

Giữ nguyên ~/iot23_work_01 và archive trên Windows. Giải nén ZIP này trong Downloads của Ubuntu, để có ~/Downloads/khoi_phuc_iot23/RECOVER_IOT23.py.

Chạy bằng môi trường AI đã có:

```bash
~/ai_part2/.venv/bin/python ~/Downloads/khoi_phuc_iot23/RECOVER_IOT23.py --work ~/iot23_work_01 --output ~/iot23_khoi_phuc_01
```

Khi hiện DONE:

```bash
firefox ~/iot23_khoi_phuc_01/MO_KET_QUA.html
```

Công cụ không mở lại archive. Dùng lại Syn34 đã xác minh; tải bản Hue4 riêng chính thức376840 byte nếu cần đối chiếu/bổ sung. Bản Hue4 cũ khác nội dung gói được giữ nguyên và không gán nhãn. Tạo kết quả trong thư mục mới, không ghi đè dữ liệu cũ. Cần Internet cho bước tải bản Hue4.

Dự kiến2880 Normal +21 SYN =2901 dòng. Sáu đặc trưng thô, sáu q và nhãn nằm trong các tệp riêng. Đây là các nguồn development v3 đã dùng; chưa có lớp2=vertical scan, không phải train mới hoặc test độc lập. Không thay model.

Nếu ERROR, gửi nguyên thông báo. Đọc HUONG_DAN_VI.md để xem cách kiểm tra nguồn và giới hạn. Không xóa kết quả cũ hoặc chạy lại full archive chỉ vì Firefox chưa có trang kết quả.
