# Kiểm tra phản ánh ghép nối v2/v3

Đây là gói CHẨN ĐOÁN, không phải bản sửa model. Model và quyết định chặn không được thay đổi. v2_reference chỉ để đối chiếu; v3_candidate cũng còn lỗi một SYN thành flood và lỗi quét chậm trộn MQTT đã biết. Không coi v3 là bộ phát hiện/chặn đã hoàn thiện.

Mở findings.md để đọc kết luận. Mỗi thư mục phiên bản có report.json và cases.csv ghi 36 probe ngoại tuyến: raw, q, packed feat, scores, prediction và nhãn của kịch bản được dựng. Chúng không phải 36 mẫu mạng thực hay tập train/test để công bố accuracy. Thư mục model chỉ có JSON cần cho checker; core ROM đã nhúng đủ weights. Đây không phải toàn bộ project Gowin bàn giao.

Có thể mở cases.csv trên Windows để so với log CPU/RTL. Với raw cảm biến [7,61,18,1,1,1], q đúng là [0,30,18,1,1,1], feat 0x010101121e00; v2 chọn Scan, v3 chọn Normal. Nhớ pack chỉ một lần; header nhận sum_ip_bytes/syn_open, không phải mean/ratio. Không sửa bằng cách đưa raw trực tiếp vào core hoặc bỏ mọi cửa sổ q0=0.

Chạy lại trên Ubuntu có bộ mã ~/ai_part2, dùng Python .venv đã có NumPy/Scapy, GCC và Icarus:

```bash
cd ~/Downloads/ai_integration_feedback_check
PART2_PYTHON="$HOME/ai_part2/.venv/bin/python" bash run_checks.sh run01
```

Đổi run01 thành tên mới nếu đã chạy để giữ kết quả cũ. Kết quả nằm trong build/run01. Checker cố ý KHÔNG sửa model khi không đạt kỳ vọng kịch bản. Dòng RTL PASS chỉ xác nhận score/class RTL khớp mô hình, kể cả những lỗi phân loại về ý nghĩa. Đọc failed_scenario_expectations trong report.json; không gọi RTL PASS là accuracy PASS.

Để bạn ghép nối cung cấp trace thực tế, ghi cùng một cửa sổ: version/hash, packets/sum_ip_bytes/syn_open, sáu raw features, sáu q bytes, packed feat, ba scores và class_id. Một SYN không đủ chứng minh flood; không dùng class_id đơn lẻ làm lệnh chặn IP. Chưa có PCAP của 22 cửa sổ bạn ghép mô tả nên không tuyên bố đã tái lập nguyên trace đó.

Hai model SHA256:

- v2: 57da88b7b596766749034a5bdf72a9a21be82189517260176e4d8ecdc4387a07
- v3: e10f81b3e3ec9b458c4d574ee978cf0f2efa45954b4f8fe0c86fed6a3a26c35d
