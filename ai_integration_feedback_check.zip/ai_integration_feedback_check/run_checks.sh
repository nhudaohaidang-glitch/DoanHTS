#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON_BIN="${PART2_PYTHON:-python3}"
RUN_ID="${1:-run01}"
[[ "$RUN_ID" =~ ^[a-zA-Z0-9_-]+$ ]] || { echo 'Use letters, numbers, underscores or hyphens for run ID'; exit 1; }
for VERSION in v2_reference v3_candidate; do
    OUT="build/$RUN_ID/$VERSION"
    "$PYTHON_BIN" tools/check_edge_cases.py --model "$VERSION/model" --output "$OUT"
    gcc -std=c99 -Wall -Wextra -Werror -I "$VERSION/firmware" "$OUT/check_pack.c" -o "$OUT/check_pack"
    "$OUT/check_pack"
    iverilog -g2012 -Wall -s tb_ai_core -o "$OUT/sim.vvp" "$VERSION/src/ai_core.v" tb_ai_core.v
    vvp "$OUT/sim.vvp" "+vectors=$OUT/vectors.txt" | tee "$OUT/rtl_result.log"
    grep -q '^PASS vectors=' "$OUT/rtl_result.log"
done
echo 'Arithmetic checks completed. Inspect failed_scenario_expectations: RTL PASS does not mean detection accuracy PASS.'
