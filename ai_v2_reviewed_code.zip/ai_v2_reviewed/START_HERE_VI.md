# AI v2 đã kiểm tra — dùng để ghép code

Đọc HANDOFF_V2_VI.md và evidence/CLOUD_REVIEW_V2.md.

Người 1: dùng gowin_ai_v2/src/ai_core_model_v2.v và firmware/ai_v2_integration.h, header này include ai_quant_v2.h cùng thư mục. Kiểm ai_v2_prepare_window(...,&feat) trả1 trước khi gọi AI. Trả0 là mẫu rỗng/không hợp lệ, không phải class normal; không tạo luật chặn mới từ mẫu rỗng, vẫn xử lý TTL riêng. Không bỏ 1..7 gói chỉ vì q0=0.

Người 3: giữ sáu raw features theo spec; divisors v2 [8,2,1,1,1,1]. Chốt distinct exact/bitmap và mốc cửa sổ, so raw->q->feat trước khi đánh giá phần cứng.

Verilog/model vẫn cùng hash57da88b7b596766749034a5bdf72a9a21be82189517260176e4d8ecdc4387a07. Không huấn luyện lại/sửa trọng số. Chỉ thêm guard/tài liệu/bằng chứng kiểm tra. Model vẫn cho class2 ở vector toàn0 khi test số học; đường xử lý mạng phải skip theo RAW packet_count==0.

Mở project Gowin gowin_ai_v2/ai_core_v2.gprj để xem core; khi tích hợp chỉ dùng một ai_core, không gán 103 tín hiệu core thành chân bo. Chưa có timing sau route hoặc đo chặn mạng thật.

Gói này chứa code/model/vector cần ghép và số liệu tổng hợp. Bộ CSV/metadata/record thu đầy đủ vẫn ở ban_giao_ai_v2.zip gốc của người dùng. Không dùng gói code rút gọn này thay bộ dữ liệu train/eval; giữ nguyên bản gốc làm bằng chứng.


CẬP NHẬT 30/10/2026: V2 chỉ đã đạt kết quả tốt trong lab đã kiểm. Thử ngoại miền trên capture Philips Hue4 của IoT-23: 896/2880 cửa sổ có gói đúng normal,1984nhầm scan (FPR68,89%). Dùng gói này để ghép/kiểm số học; model chưa đủ tin cậy để dùng chặn ngoài lab. Giữ nguyên trọng số để làm mốc đối chứng; cần dữ liệu/huấn luyện và đánh giá mới. Xem evidence/IOT23_EXTERNAL_CHECK_2026_10_30.md.
