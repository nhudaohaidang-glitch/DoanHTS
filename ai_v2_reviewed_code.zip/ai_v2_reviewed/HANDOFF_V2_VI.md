# Bàn giao AI v2 cho người 1 và 3

Model SHA256: 57da88b7b596766749034a5bdf72a9a21be82189517260176e4d8ecdc4387a07

Kiến trúc: 6–8–3. Divisors: [8, 2, 1, 1, 1, 1]. shift1=6, shift2=1.
hidden_scale=16; score_scale=128. Dùng đúng một module ai_core.

## Kết quả đã kiểm tra khi đóng gói

Holdout mới sau freeze: 210 cửa sổ, 10 capture, AI accuracy=100.00%, FPR=0.00%, macro-F1=1.0000.
Baseline accuracy=100.00%; kết quả ngang nhau không chứng minh AI tốt hơn baseline.
RTL số học khớp 424 vector, 84 chu kỳ. Không có phép đo chặn Ethernet hoặc thời gian thực trên bo.

## Người 1: CPU và driver

Thêm gowin_ai_v2/src/ai_core_model_v2.v; firmware include gowin_ai_v2/firmware/ai_v2_integration.h (header này include ai_quant_v2.h cùng thư mục).
Verilog này đã nhúng ROM, không cần readmemh/file HEX lúc chạy; HEX trong model/ dùng đối chiếu, không thêm generic ai_core lần nữa.
Hàm ai_v2_pack(packets, ip_byte_sum, syn_open, src_count, dst_count, port_count) trả uint64 chứa 48 bit feat.
feat[7:0]=q0, ..., feat[47:40]=q5. Ghi phần thấp/cao theo driver thực của nhóm, không tạo địa chỉ thanh ghi mới theo tài liệu này.
q=clamp(raw//divisor,0,127). Empty window cả sáu số 0. Kiểm tra helper uint64 chia số nguyên được toolchain RISC-V liên kết đầy đủ.

QUAN TRỌNG: model này trả class_id=2 khi feat toàn 0. Đây là kết quả số học trên đầu vào rỗng, không phải bằng chứng có tấn công.
Gọi ai_v2_prepare_window(..., &feat); chỉ gọi driver AI khi hàm trả 1. Khi trả 0, ghi mẫu không hợp lệ/rỗng, không START và không tạo luật chặn mới từ mẫu đó.
Giá trị trả về của hàm là sample-valid, không phải class_id=0/1. Không ép kết quả model thành normal giả.
Guard kiểm RAW packet_count==0; không kiểm q0==0 vì 1..7 gói hợp lệ cũng lượng tử q0=0. Không bỏ mẫu ít gói: điều đó có thể làm bỏ sót quét chậm.
TTL/expiry của luật chặn hiện có và việc hoàn tất giao dịch AI cũ vẫn được xử lý độc lập; cửa sổ rỗng không tự gỡ chặn.
Giữ nguyên trọng số/model/hash và các vector số học, bao gồm vector toàn 0; đây là guard ở điều khiển đầu vào, không phải huấn luyện/sửa nhãn.

clk/rst_n/start/feat/busy/done/class_id/scores theo spec/AI_INTERFACE.md.
Reset đồng bộ mức thấp, bỏ phép tính đang chạy. start chỉ nhận khi busy=0, chốt feat tại cạnh nhận; start lúc busy bị bỏ qua.
done xung một chu kỳ. Score0/1/2 signed int16 nằm lần lượt ở bits 15:0 / 31:16 / 47:32. Điểm không phải xác suất.
Class 0 bình thường; 1 SYN; 2 vertical scan. Hòa điểm chọn lớp nhỏ hơn. Dùng INTEGRATION_VECTORS.json để kiểm cả score và class.

## Người 3: thống kê đầu vào

Giữ ngữ nghĩa sáu raw features trong spec/FEATURES_V0.md: ingress IPv4 tới đích bảo vệ, cửa sổ 1 giây, distinct exact.
Thứ tự: packets; floor(ip_byte_sum/packets); floor(127*syn_open/packets); số IP nguồn; số IP đích; số cổng đích TCP/UDP.
SYN mở kết nối là SYN=1, ACK=0; mẫu số gồm toàn bộ ingress IPv4 hợp lệ, không chỉ TCP.
Phần lượng tử hóa v2 dùng DIVISORS CỐ ĐỊNH ở trên; mục divisor học từ train trong spec cũ mô tả v1, không áp dụng thay cho model v2.
Nếu RTL đã lượng tử thì cập nhật divisor đồng bộ; không chia hai lần. Nếu dùng bitmap thay exact, cần đối chiếu lại Python và đánh giá lại.
Căn mốc cửa sổ/reset khi so PCAP. Đếm overflow/CRC lỗi và có chính sách gói không hỗ trợ rõ ràng.

## Kiểm ghép

1. Kiểm guard: 0 gói không gọi START/không tạo luật mới; 1 và 7 gói vẫn valid dù q0=0. CPU nạp các vector feat, đối chiếu score/class và số chu kỳ, rồi kiểm reset/start khi busy. Vector toàn0 chỉ dùng kiểm số học; đường xử lý mạng phải skip theo raw count.
2. Chạy cùng luồng header có mốc cửa sổ xác định: so raw -> quantized -> packed giữa Python và RTL.
3. Xác minh bridge chuyển hai chiều, ARP, lọc luật cố định và counters trước khi dùng AI ra quyết định.
4. Gắn model vào chính sách chọn IP/chặn: kiểm nguồn bình thường vẫn qua, nguồn thử nghiệm bị chặn, số gói lọt và chặn nhầm.
5. Kiểm timing sau ghép và routing, xác nhận clock thật, nạp bo rồi đo từ lúc bắt đầu tấn công tới phát hiện/chặn và tác dụng lên MQTT.

AI chỉ phân loại cửa sổ; không giữ IP và không tự drop gói. Chọn IP nghi vấn, whitelist/TTL, xác nhận nhiều cửa sổ thuộc CPU/bộ lọc.
84 chu kỳ chỉ là suy luận lõi, không gồm cửa sổ 1 giây, truyền bus và chính sách xác nhận.
103 I/O trong tổng hợp core là tín hiệu giao diện; khi ghép là dây nội bộ, không phải 103 chân kit.
Gowin screenshots: logic445, FF246, DSP1, BSRAM0, latch0; synthesis Fmax ước tính56.4MHz ở clock50MHz.
Project SDC mục tiêu27MHz; clock/constraints thực khi ghép phải chốt. Chưa có routed timing hay đo bo.
Ở 27MHz, 84 chu kỳ tương ứng khoảng3.11us NẾU clock/timing thực đạt; không gọi đó là thời gian phát hiện/chặn toàn hệ thống.
Kết quả holdout giới hạn trong các phiên lab; chưa xác minh IoT-23, mạng khác hoặc mọi tình huống retry/quét cực chậm.
