`define SHIFT1 6
`define SHIFT2 1
